package Entities;



public class VueSurOcean extends SectionAvecCabine {
	
	public VueSurOcean(Disposition disposition, int n) {
		super(disposition, n);
		this.ratio = 0.75;
		this.type = 'O';
		this.CAPACITE = 2;
	}

}