package Entities;


public class Affaire extends SectionAvecSiege {

	public Affaire(Disposition disposition, int nbRang) {
		super(disposition, nbRang);
		this.ratio = 0.75;
		this.type = 'A';
	}
	
	@Override
	public double calculerPrix() {
		return ratio*pleinTarif;
	}


}