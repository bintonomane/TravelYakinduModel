package Entities;


public class Confort extends Disposition {
	
	public Confort() {
		this.nbCol = 4;
		this.type = 'C';
	}
}