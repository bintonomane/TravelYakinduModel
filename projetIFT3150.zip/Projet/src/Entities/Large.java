package Entities;


public class Large extends Disposition {
	
	public Large() {
		this.nbCol = 10;
		this.type = 'L';
	}
}