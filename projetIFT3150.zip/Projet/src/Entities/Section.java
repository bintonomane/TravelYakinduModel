package Entities;
import visitor.IVisitable;
import visitor.Visiteur;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import reservation.ObjetAReserver;


public abstract class Section implements IVisitable {

	protected double ratio;
	protected double pleinTarif;
	protected Map<String, reservation.ObjetAReserver> objets;	
	protected char type;
	protected Disposition disposition;
	
	public Section(Disposition disposition, int n) {
		this.disposition = disposition;
		this.objets = new HashMap<String, reservation.ObjetAReserver>();
		this.pleinTarif = -1;
	}
	
	public abstract void creerObjets(Disposition disposition, int n);

	public reservation.ObjetAReserver getObjet(String objetID) {
		return objets.get(objetID);
	}
	
	public Map<String, reservation.ObjetAReserver> getObjets() {
		return objets;
	}
	
	public double calculerPrix() {
		return ratio*pleinTarif;
	}
	
	public char getType() {
		return type;
	}
	
	public int getSize() {
		return objets.size();
	}
	
	public char getDispositionType() {
		if (this.disposition != null) {
			return this.disposition.getType();
		} else {
			return ' ';
		}
	}
	
	public int getNbObjetsDisponibles() {
		return getObjetsDisponibles().size();
	}
	
	public ArrayList<ObjetAReserver> getObjetsDisponibles() {
		ArrayList<ObjetAReserver> list = new ArrayList<ObjetAReserver>();
		for (ObjetAReserver o: objets.values()) {
			if (o.getEtat().isDispo()) {
				list.add(o);
			}
		}
		return list;
	}
	
	public void setPleinTarif(double pleinTarif) {
		this.pleinTarif = pleinTarif;
	}

	public void accepte(Visiteur v) {
		v.visiteSection(this);
	}

}