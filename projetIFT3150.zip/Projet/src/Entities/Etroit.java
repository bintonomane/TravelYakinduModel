package Entities;


public class Etroit extends Disposition {

	public Etroit(){
		this.nbCol = 3;
		this.type = 'S';
	}

}