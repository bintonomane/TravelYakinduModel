package Entities;


public class CompagnieTrain extends Compagnie {

	public CompagnieTrain(String compagnieID, String nomCompagnie) {
		super(compagnieID, nomCompagnie);
	}

}