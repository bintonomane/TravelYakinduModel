package Entities;


public class Premiere extends SectionAvecSiege {

	public Premiere(Disposition disposition, int nbRang) {
		super(disposition, nbRang);
		this.ratio = 1.0;
		this.type = 'F';
	}

}