package Entities;



public class Interieure extends SectionAvecCabine {
	
	public Interieure(Disposition disposition, int n) {
		super(disposition, n);
		this.ratio = 0.5;
		this.type = 'I';
		this.CAPACITE = 4;
	}

}