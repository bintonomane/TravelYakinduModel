package Entities;


public class Moyen extends Disposition {
	
	public Moyen() {
		this.nbCol = 6;
		this.type = 'M';
	}
}