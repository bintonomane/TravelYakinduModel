package Entities;


public class Aeroport extends Port {

	public Aeroport(String portID, String nomPort, String ville) {
		super(portID, nomPort, ville);
	}
}