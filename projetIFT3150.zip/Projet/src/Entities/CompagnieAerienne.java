package Entities;


public class CompagnieAerienne extends Compagnie {
	
	public CompagnieAerienne(String compagnieID, String nomCompagnie) {
		super(compagnieID, nomCompagnie);
		this.type = "Aerienne";
	}


}