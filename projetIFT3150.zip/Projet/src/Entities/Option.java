package Entities;

public enum Option {
	Aile, Fenetre, Aucune, Aile_Fenetre
}
