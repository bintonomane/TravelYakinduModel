package Entities;


public class EconomiquePremium extends SectionAvecSiege {

	public EconomiquePremium(Disposition disposition, int nbRang) {
		super(disposition, nbRang);
		this.ratio = 0.6;
		this.type = 'P';
	}
	
	@Override
	public double calculerPrix() {
		return ratio*pleinTarif;
	}

}