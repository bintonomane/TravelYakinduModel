package Entities;

import java.util.ArrayList;

import Entities.Siege;

public abstract class SectionAvecSiege extends Section {
	
	private int nbRang;

	public SectionAvecSiege(Disposition disposition, int nbRang) {
		super(disposition, nbRang);
		this.disposition = disposition;
		this.nbRang = nbRang;
		this.creerObjets(disposition, nbRang);
	}
	
	public char getDispositionType() {
		return disposition.getType();
	}
	
	public void creerObjets(Disposition disposition, int nbRang) {
		Siege siege = null;
		char col = 'A';
		ArrayList<Integer> aile = new ArrayList<Integer>();
		Option option = Option.Aucune;
		
		int nbCol = disposition.getNbColonnes();;
		
		switch(disposition.getType()) {
		case 'S':
			aile.add(1);
			aile.add(2);
			break;
		case 'C':
			aile.add(2);
			aile.add(3);
			break;
		case 'M':
			aile.add(3);
			aile.add(4);
			break;
		case 'L':
			aile.add(3);
			aile.add(4);
			aile.add(7);
			aile.add(8);
			break;
		default:
			throw new UnsupportedOperationException();
		}
		
		for (int i=1; i<=nbCol; i++) {
			if (aile.contains(i)) {
				if ((i==1) || (i==nbCol)) {
					option = Option.Aile_Fenetre;
				} else {
					option = Option.Aile;
				}
			} else {
				if ((i==1) || (i==nbCol)) {
					option = Option.Fenetre;
				} else {
					option = Option.Aucune;
				}
			}
			
			for (int j=1; j<=nbRang; j++) {
				siege = new Siege(j, col, option);
				objets.put(siege.getObjetID(), siege);
			}
			
			col++;
		}
	}
	
	public int getNbRang() {
		return nbRang;
	}
	
	public void setNbRang(int nbRang) {
		this.nbRang = nbRang;
	}

}