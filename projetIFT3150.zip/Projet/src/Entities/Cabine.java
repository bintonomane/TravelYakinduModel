package Entities;

import reservation.ObjetAReserver;

public class Cabine extends ObjetAReserver {

	private static int lastID = 0;
	private int capacite;
	
	public Cabine(int capacite) {
		this.capacite = capacite;
		this.setEtat(new reservation.EtatDisponible());
		lastID++;
		objetID = "CAB"+lastID;
	}
	
	public int getCapacite() {
		return capacite;
	}

}