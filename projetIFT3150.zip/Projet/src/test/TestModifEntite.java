package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import Entities.Compagnie;
import Entities.MoyenTransport;
import Entities.Port;
import Entities.Voyage;
import commande.Commande;
import fabrique.FabriqueAerienne;
import fabrique.FabriqueCroisiere;
import fabrique.FabriqueTrain;
import invocator.Invocateur;
import methode.ModifierCompagnie;
import methode.ModifierMoyenTransport;

class TestModifEntite {
	
	Compagnie compagnie1, compagnie2, compagnie3;
	MoyenTransport vehicule1, vehicule2, vehicule3;
	Port port1,port2, port3,port4, port5,port6;
	Voyage voyage1, voyage2, voyage3;
	 FabriqueAerienne fabriqueAerienne;
	 FabriqueCroisiere fabriqueCroisiere;
	 Invocateur invocateur;
	 FabriqueTrain fabriqueTrain;
		Date d1=null, d2=null, d3=null, d4=null, d5=null, d6=null;
		private String newVehiculeID;
		
		// create  compagnie, vehicule, port and voage that will be added

		@Before
		void setUp()  {
			invocateur = Invocateur.getInstance();

			SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd:HH.mm");
			// 6 Dates
			try {
				d1 = df.parse("2016.12.24:23.30");
				d2 = df.parse("2017.01.05:11.30");
				d3 = df.parse("2017.02.28:10.00");
				d4 = df.parse("2017.03.05:20.00");
				d5 = df.parse("2017.03.10:14.00");
				d6 = df.parse("2017.03.15:08.00");
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			fabriqueAerienne = FabriqueAerienne.getInstance();
			fabriqueCroisiere = FabriqueCroisiere.getInstance();
			fabriqueTrain = FabriqueTrain.getInstance();
			
			compagnie1 = fabriqueAerienne.creerCompagnie("AIR01", "Nom compagnie aerienne");
			compagnie2 = fabriqueTrain.creerCompagnie("TRAIN01", "Nom compagnie train");
			compagnie3 = fabriqueCroisiere.creerCompagnie("CROIS01", "Nom compagnie croisiere");
			
			vehicule1 = fabriqueAerienne.creerTransport("AVIONID01", compagnie1);
			vehicule2 = fabriqueCroisiere.creerTransport("PAQUID01", compagnie2);
			vehicule3 = fabriqueTrain.creerTransport("TRAINID01", compagnie3);
			 
			
			
			port1 = fabriqueAerienne.creerPort("AEROID00", "Aeroport 0", "Montreal");
			port2 = fabriqueAerienne.creerPort("AEROID01", "Aeroport 1", "Tokyo");
			port3 = fabriqueTrain.creerPort("GAREIndsèLNÈD01", "Gare 1", "Seoul");
			port4 = fabriqueTrain.creerPort("GARELNsdèlnID02", "Gare 2", "Tokyo");
			port5 = fabriqueCroisiere.creerPort("POlnslNRTID01", "Port Croisiere 1", "New York");
			port6 = fabriqueCroisiere.creerPort("POlnslNRTID02", "Port Croisiere 2", "Amsterdam");
			
			
			voyage1 = fabriqueAerienne.creerVoyage(compagnie1, vehicule1, "VOLID01", d1, d2, port1, port2);
			voyage2 = fabriqueTrain.creerVoyage(compagnie2, vehicule3, "TRAJ;JLKSNLDKNNNFID01", d3, d4, port3, port4);
			voyage3 = fabriqueCroisiere.creerVoyage(compagnie3, vehicule2, "ITILDS;NN;JNFJNID01", d5, d6, port5, port6);
		}
		

	@Test
	void test() {
		setUp();
		
		// vérifier la modification des entités
			
			//Compagnie
			String oldCompagnieID = compagnie1.getCompagnieID();			
			String oldCompagnieName = compagnie1.getNomCompagnie();
			String newCompagnieID = "AIR01";			
			String newCompagnieName = "Ma compagnie";
			
			new ModifierCompagnie(fabriqueAerienne, compagnie1, newCompagnieID, newCompagnieName);

			assertFalse(!compagnie1.getCompagnieID().equals(oldCompagnieID));
			
			assertTrue(compagnie1.getCompagnieID().equals(newCompagnieID));
			
			
			
			//Vehicule

			String oldVehiculeID = vehicule1.getTransportID();
			Compagnie oldVehCompName = vehicule1.getCompagnie();
			
			String	newVehiculeID = "Avion01";		
			newCompagnieID = "AIR0)";		
			String newCompagnieTName = "Ma compagnie";

			Commande commande = new ModifierMoyenTransport(fabriqueAerienne, vehicule1, "Avion 01", fabriqueAerienne.creerCompagnie(newCompagnieID, newCompagnieTName));
			invocateur.setCommande(commande);
			invocateur.pressExecuteButton(commande);
			

			



			assertFalse(!vehicule1.getTransportID().equals(oldVehiculeID));
			
			
			assertTrue(!vehicule1.getTransportID().equals(newVehiculeID));
			
			
			// vérifier l'annulation de la modification
			
			// Compagnie
			int sizeOldFabrique = fabriqueAerienne.getListeCompagnies().size();
			
			fabriqueAerienne.supprimerCompagnie(newCompagnieID);
			int sizeNewFabrique = fabriqueAerienne.getListeCompagnies().size();
			
			
			assertTrue(sizeNewFabrique == sizeOldFabrique -1 );
			
			fabriqueAerienne.creerCompagnie(oldCompagnieID, oldCompagnieName);
			assertTrue(fabriqueAerienne.getListeCompagnies().size() == sizeNewFabrique  );
			
			assertTrue(fabriqueAerienne.getListeCompagnies().size() != sizeOldFabrique );
			
			
			//Vehicule
			int sizeOldVehicule = fabriqueAerienne.getListeTransports().size();
			Compagnie comp = vehicule1.getCompagnie();
			fabriqueAerienne.supprimerTransport(newVehiculeID);
			sizeNewFabrique = fabriqueAerienne.getListeTransports().size();
			
			
			assertTrue(sizeNewFabrique == sizeOldFabrique -1 );
			
			fabriqueAerienne.creerTransport(oldCompagnieID, comp);
			assertTrue(fabriqueAerienne.getListeTransports().size() == sizeNewFabrique +1 );
			
			
			

			

		
	}

}
