package test;

	import static org.junit.jupiter.api.Assertions.*;

	import java.text.ParseException;
	import java.text.SimpleDateFormat;
	import java.util.Date;

	import org.junit.Before;
	import org.junit.jupiter.api.Test;

	import Entities.Compagnie;
	import Entities.MoyenTransport;
	import Entities.Port;
	import Entities.Voyage;
	import fabrique.FabriqueAerienne;
	import fabrique.FabriqueCroisiere;
	import fabrique.FabriqueTrain;

	class TestAjoutEntites {

		Compagnie compagnie1, compagnie2, compagnie3;
		MoyenTransport vehicule1, vehicule2, vehicule3;
		Port port1,port2, port3,port4, port5,port6;
		Voyage voyage1, voyage2, voyage3;
		 FabriqueAerienne fabriqueAerienne;
		 FabriqueCroisiere fabriqueCroisiere;
		 FabriqueTrain fabriqueTrain;
			Date d1=null, d2=null, d3=null, d4=null, d5=null, d6=null;

		
		
		@Before
		// create  compagnie, vehicule, port and voage that will be added
		void setUp()  {
			SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd:HH.mm");
			// 6 Dates
			try {
				d1 = df.parse("2016.12.24:23.30");
				d2 = df.parse("2017.01.05:11.30");
				d3 = df.parse("2017.02.28:10.00");
				d4 = df.parse("2017.03.05:20.00");
				d5 = df.parse("2017.03.10:14.00");
				d6 = df.parse("2017.03.15:08.00");
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			fabriqueAerienne = FabriqueAerienne.getInstance();
			fabriqueCroisiere = FabriqueCroisiere.getInstance();
			fabriqueTrain = FabriqueTrain.getInstance();
			
			compagnie1 = fabriqueAerienne.creerCompagnie("AIR01", "Nom compagnie aerienne");
			compagnie2 = fabriqueTrain.creerCompagnie("TRAIN01", "Nom compagnie train");
			compagnie3 = fabriqueCroisiere.creerCompagnie("CROIS01", "Nom compagnie croisiere");
			
			vehicule1 = fabriqueAerienne.creerTransport("AVIONID01", compagnie1);
			vehicule2 = fabriqueCroisiere.creerTransport("PAQUID01", compagnie2);
			vehicule3 = fabriqueTrain.creerTransport("TRAINID01", compagnie3);
			 
			
			
			port1 = fabriqueAerienne.creerPort("AEROID00", "Aeroport 0", "Montreal");
			port2 = fabriqueAerienne.creerPort("AEROID01", "Aeroport 1", "Tokyo");
			port3 = fabriqueTrain.creerPort("GAREIndsèLNÈD01", "Gare 1", "Seoul");
			port4 = fabriqueTrain.creerPort("GARELNsdèlnID02", "Gare 2", "Tokyo");
			port5 = fabriqueCroisiere.creerPort("POlnslNRTID01", "Port Croisiere 1", "New York");
			port6 = fabriqueCroisiere.creerPort("POlnslNRTID02", "Port Croisiere 2", "Amsterdam");
			
			
			voyage1 = fabriqueAerienne.creerVoyage(compagnie1, vehicule1, "VOLID01", d1, d2, port1, port2);
			voyage2 = fabriqueTrain.creerVoyage(compagnie2, vehicule3, "TRAJ;JLKSNLDKNNNFID01", d3, d4, port3, port4);
			voyage3 = fabriqueCroisiere.creerVoyage(compagnie3, vehicule2, "ITILDS;NN;JNFJNID01", d5, d6, port5, port6);
		}
		

		
		@Test
		void testEntities() {
			setUp();
		// veriier que la la liste n'est pas vide	
			assertTrue(fabriqueAerienne.getListeCompagnies().size()>=0);
			assertTrue(fabriqueCroisiere.getListeCompagnies().size()>=0);
			assertTrue(fabriqueTrain.getListeCompagnies().size()>=0);


		// verifier que les retour des methode donne des entites sont de la meme classe
			
			assertNotSame(compagnie1.getClass(),compagnie2.getClass());		
			assertNotSame(compagnie2.getClass(),compagnie3.getClass());
			assertNotSame(compagnie1.getClass(),compagnie3.getClass());
		
			assertNotSame(vehicule1.getClass(),vehicule2.getClass());
			assertNotSame(vehicule2.getClass(),vehicule3.getClass());
			assertNotSame(vehicule1.getClass(),vehicule3.getClass());
			
			assertSame(port1.getClass(),port2.getClass());
			assertSame(port3.getClass(),port4.getClass());
			assertSame(port5.getClass(),port6.getClass());
			
			assertNotSame(voyage1.getClass(),voyage2.getClass());
			assertNotSame(voyage2.getClass(),voyage3.getClass());
			assertNotSame(voyage1.getClass(),voyage3.getClass());
		}
		
		
	

}

