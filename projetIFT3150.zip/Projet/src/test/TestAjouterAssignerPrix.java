package test;

import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.jupiter.api.Test;

import Entities.Compagnie;
import Entities.MoyenTransport;
import Entities.Port;
import Entities.Voyage;
import commande.Commande;
import fabrique.FabriqueAerienne;
import fabrique.FabriqueCroisiere;
import fabrique.FabriqueTrain;
import invocator.Invocateur;
import methode.AssignerPrix;

public class TestAjouterAssignerPrix {
	Compagnie compagnie1, compagnie2, compagnie3;
	MoyenTransport vehicule1, vehicule2, vehicule3;
	Port port1,port2, port3,port4, port5,port6;
	Voyage voyage1, voyage2, voyage3;
	 FabriqueAerienne fabriqueAerienne;
	 FabriqueCroisiere fabriqueCroisiere;
	 FabriqueTrain fabriqueTrain;
	 Invocateur invocateur;

		Date d1=null, d2=null, d3=null, d4=null, d5=null, d6=null;

	
	
	@Before
	// create  compagnie, vehicule, port and voage that will be added
	
	void setUp()  {
		
		invocateur = Invocateur.getInstance();

		SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd:HH.mm");
		// 6 Dates
		try {
			d1 = df.parse("2016.12.24:23.30");
			d2 = df.parse("2017.01.05:11.30");
			d3 = df.parse("2017.02.28:10.00");
			d4 = df.parse("2017.03.05:20.00");
			d5 = df.parse("2017.03.10:14.00");
			d6 = df.parse("2017.03.15:08.00");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fabriqueAerienne = FabriqueAerienne.getInstance();
		fabriqueCroisiere = FabriqueCroisiere.getInstance();
		fabriqueTrain = FabriqueTrain.getInstance();
		
		compagnie1 = fabriqueAerienne.creerCompagnie("AIR01", "Nom compagnie aerienne");
		compagnie2 = fabriqueTrain.creerCompagnie("TRAIN01", "Nom compagnie train");
		compagnie3 = fabriqueCroisiere.creerCompagnie("CROIS01", "Nom compagnie croisiere");
		
		vehicule1 = fabriqueAerienne.creerTransport("AVIONID01", compagnie1);
		vehicule2 = fabriqueCroisiere.creerTransport("PAQUID01", compagnie2);
		vehicule3 = fabriqueTrain.creerTransport("TRAINID01", compagnie3);
		 
		fabriqueAerienne.assignerPrix(compagnie1, 342);
		fabriqueTrain.assignerPrix(compagnie2, 151);
		fabriqueCroisiere.assignerPrix(compagnie3, 1352);
		
		port1 = fabriqueAerienne.creerPort("AEROID00", "Aeroport 0", "Montreal");
		port2 = fabriqueAerienne.creerPort("AEROID01", "Aeroport 1", "Tokyo");
		port3 = fabriqueTrain.creerPort("GAREIndsèLNÈD01", "Gare 1", "Seoul");
		port4 = fabriqueTrain.creerPort("GARELNsdèlnID02", "Gare 2", "Tokyo");
		port5 = fabriqueCroisiere.creerPort("POlnslNRTID01", "Port Croisiere 1", "New York");
		port6 = fabriqueCroisiere.creerPort("POlnslNRTID02", "Port Croisiere 2", "Amsterdam");
		
		
		voyage1 = fabriqueAerienne.creerVoyage(compagnie1, vehicule1, "VOLID01", d1, d2, port1, port2);
		voyage2 = fabriqueTrain.creerVoyage(compagnie2, vehicule3, "TRAJ;JLKSNLDKNNNFID01", d3, d4, port3, port4);
		voyage3 = fabriqueCroisiere.creerVoyage(compagnie3, vehicule2, "ITILDS;NN;JNFJNID01", d5, d6, port5, port6);
	}
	
	@Test
	void test() {
		setUp();
		double oldTarifCompAer = compagnie1.getPleinTarif();
		double oldTarifCompCr = compagnie3.getPleinTarif();
		double oldTarifCompTr = compagnie2.getPleinTarif();
		

		Commande commande1 = new AssignerPrix(fabriqueAerienne, compagnie1, 897.9898);
		Commande commande2 = new AssignerPrix(fabriqueCroisiere, compagnie3, 632.99);
		
		Commande commande3 = new AssignerPrix(fabriqueTrain, compagnie2, 77.9);


		invocateur.setCommande(commande1);
		invocateur.pressExecuteButton(commande1);
		
		invocateur.setCommande(commande3);
		invocateur.pressExecuteButton(commande3);
		
		invocateur.setCommande(commande2);
		invocateur.pressExecuteButton(commande2);
		
		
	// veriier que la la les tarif ont changé	
		assertTrue(compagnie1.getPleinTarif() != oldTarifCompAer);
		assertTrue(compagnie3.getPleinTarif() != oldTarifCompCr);
		assertTrue(compagnie2.getPleinTarif() != oldTarifCompTr);

		
	}
	
}
