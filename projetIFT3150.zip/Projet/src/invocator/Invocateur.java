package invocator;

import java.util.ArrayList;

import commande.Commande;
import observer.Observateur;
import observer.Sujet;

public class Invocateur implements Sujet {

	private Commande commande;
	private ArrayList<Observateur> frames = new ArrayList<Observateur>();
	
	private static Invocateur instance;
	
	private Invocateur() {}

	public static Invocateur getInstance() {
		if (instance==null) {
			instance = new Invocateur();
		}
		return instance;
	}
	
	public void setCommande(Commande commande) {
		this.commande = commande;
	}
	
	public Commande getCommande() {
		return this.commande;
	}

	public void pressExecuteButton(Commande commande) {
		System.out.println(commande);

		commande.execute();

		notifier();
	}

	public void pressUnexecuteButton() {
		commande.unexecute();
		notifier();
	}

	@Override
	public void attacher(Observateur obs) {
		if (obs==null) throw new NullPointerException("Observateur nul");
		if (!frames.contains(obs)) {
			frames.add(obs);
		}
	}

	@Override
	public void detacher(Observateur obs) {
		frames.remove(obs);
	}
	
	@Override
	public void notifier() {
		for (Observateur f: frames) {
			f.update();
		}
	}

}