package fabrique;
import java.util.Date;

import Entities.Compagnie;
import Entities.CompagnieCroisiere;
import Entities.Itineraire;
import Entities.MoyenTransport;
import Entities.Paquebot;
import Entities.Port;
import Entities.PortCroisiere;
import Entities.Voyage;
import methode.AssignerPrix;
import methode.CreerCompagnie;
import methode.ModifierCompagnie;
import methode.SupprimerCompagnie;

public class FabriqueCroisiere extends FabriqueEntiteVoyage {

	private static FabriqueCroisiere instance;

	public FabriqueCroisiere() {
		super();
	}

	public static FabriqueCroisiere getInstance() {
		if (instance==null) {
			instance = new FabriqueCroisiere();
		}
		return instance;
	}

	@Override
	public Compagnie creerCompagnie(String compagnieID, String nomCompagnie) {
		CompagnieCroisiere compagnie = new CompagnieCroisiere(compagnieID, nomCompagnie);
		listeCompagnies.put(compagnieID, compagnie);
		
		/*this.creation = true;
		this.newObjet = compagnie;
		this.notifier("Compagnie");*/
		
		return compagnie;
	}
	
	@Override
	public MoyenTransport creerTransport(String transportID, Compagnie compagnie) {
		Paquebot paquebot = new Paquebot(transportID, compagnie);
		listeTransports.put(transportID, paquebot);
		
		/*this.creation = true;
		this.newObjet = paquebot;
		this.notifier("Transport");*/
		
		return paquebot;
	}

	@Override
	public Voyage creerVoyage(Compagnie compagnie,  MoyenTransport transport, String voyageID, Date dateHeureDepart, Date dateHeureArrivee, Port portDepart, Port portArrivee) {
		Itineraire voyage = new Itineraire(compagnie, transport, voyageID, dateHeureDepart, dateHeureArrivee, portDepart, portArrivee);
		listeVoyages.put(voyageID, voyage);
		
		/*this.creation = true;
		this.newObjet = voyage;
		this.notifier("Voyage");*/
		
		return voyage;
	}

	@Override
	public Port creerPort(String portID, String nomPort, String ville) {
		PortCroisiere port = new PortCroisiere(portID, nomPort, ville);
		listePorts.put(portID, port);
		
		/*this.creation = true;
		this.newObjet = port;
		this.notifier("Port");*/
		
		return port;
	}

}