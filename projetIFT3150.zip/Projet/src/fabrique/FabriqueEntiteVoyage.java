package fabrique;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.swing.DefaultListModel;

import Entities.Compagnie;
import Entities.MoyenTransport;
import Entities.Port;
import Entities.Voyage;
import Entities.Section;

public abstract class FabriqueEntiteVoyage{
	
	protected Map<String, Compagnie> listeCompagnies;
	protected Map<String, MoyenTransport> listeTransports;
	protected Map<String, Voyage> listeVoyages;
	protected Map<String, Port> listePorts;
	
	
	private String texte = "";
	
	public FabriqueEntiteVoyage() {
		
		listeCompagnies = new HashMap<String, Compagnie>();
		listeTransports = new HashMap<String, MoyenTransport>();
		listeVoyages = new HashMap<String, Voyage>();
		listePorts = new HashMap<String, Port>();
	}
	
	public abstract Compagnie creerCompagnie(String compagnieID, String nomCompagnie);
	public abstract MoyenTransport creerTransport(String transportID, Compagnie compagnie);
	public abstract Voyage creerVoyage(Compagnie compagnie, MoyenTransport transport, String voyageID, Date dateHeureDepart, Date dateHeureArrivee, Port portDepart, Port portArrivee);
	public abstract Port creerPort(String portID, String nomPort, String ville);

	public void supprimerCompagnie(String compagnieID) {
		if (listeCompagnies.remove(compagnieID) == null) {
			System.out.println("Aucune compagnie ne porte cet ID.");
		}
	}
	
	public void supprimerTransport(String transportID) {
		if (listeTransports.remove(transportID) == null) {
			System.out.println("Aucun vehicule ne porte cet ID.");
		}
	}

	public void supprimerVoyage(String voyageID) {
		if (listeVoyages.remove(voyageID) == null) {
			System.out.println("Aucun voyage ne porte cet ID.");
		}
	}

	public void supprimerPort(String portID) {
		if (listePorts.remove(portID) == null) {
			System.out.println("Aucun port ne porte cet ID.");
		}
	}
	
	public void assignerPrix(Compagnie compagnie, double prix) {
		compagnie.setPleinTarif(prix);
		notifierAssignation(prix);
	}
	
	public Map<String, Compagnie> getListeCompagnies() {
		return listeCompagnies;
	}
	
	public Map<String, MoyenTransport> getListeTransports() {
		return listeTransports;
	}
	
	public Map<String, Voyage> getListeVoyages() {
		return listeVoyages;
	}
	
	public Map<String, Port> getListePorts() {
		return listePorts;
	}
	
	public int getIndexObjet(String objetID, Map<String, ?> map) {
		ArrayList<String> keys = new ArrayList<String>(map.keySet());
		for (String s: keys) {
			if (s == objetID) {
				return keys.indexOf(s);
			}
		}
		throw new NullPointerException();
	}
	
	public Object getObjetParIndex(int i, Map<String, ?> map) {
		ArrayList<String> keys = new ArrayList<String>(map.keySet());
		return map.get(keys.get(i));
	}
	
	public void notifierAssignation(Double prix) {
		for (MoyenTransport t: listeTransports.values()) {
			for (Section s: t.getSections().values()) {
				s.setPleinTarif(prix);
			}
		}
	}
	
	public ArrayList<Voyage> rechercheVoyage(Port portDepart, Port portArrive, Date dateDepart, char sectionType) {
		ArrayList<Voyage> voyages = new ArrayList<Voyage>();
		for (Voyage v: this.getListeVoyages().values()) {
			if ((v.getPortDepart() == portDepart) && (v.getPortArrivee() == portArrive) && (v.getDateHeureDepart() == dateDepart)) {
				if(v.getTransport().getSections().containsKey(sectionType)) {
					Section section = v.getTransport().getSections().get(sectionType);
					if (section.getNbObjetsDisponibles() > 0) {
						voyages.add(v);
					}
				}
			}
		}
		return voyages;
	}
	
	public DefaultListModel<String> rechercheVoyageToString(ArrayList<Voyage> voyages, char sectionType) {
		DefaultListModel<String> voyagesToString = new DefaultListModel<String>();
		for (Voyage v: voyages) {
			Section section = v.getTransport().getSections().get(sectionType);
			this.visiteVoyage(v);
			this.visiteSection(section);
			voyagesToString.addElement(texte);
		}
		if (voyages.isEmpty()) {
			voyagesToString.addElement("Aucun voyage ne correspond aux criteres de recherche entres");
		}
		return voyagesToString;
	}
	
	public void visiteVoyage(Voyage v) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd:HH.mm");
		texte = "";
		texte += v.getPortDepart().getNomPort() + " - " + v.getPortArrivee().getNomPort();
		texte += " : [ " + v.getCompagnie().getNomCompagnie() + " ] " + v.getVoyageID();
		texte += " ( " + df.format(v.getDateHeureDepart()) + " - " + df.format(v.getDateHeureArrivee()) + " )";
	}
	
	public void visiteSection(Section s) {
		texte += " | " + s.calculerPrix() + " | " + s.getType() + s.getNbObjetsDisponibles();
	}

}