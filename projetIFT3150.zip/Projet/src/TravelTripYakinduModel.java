/**
 * Projet dans le cadre du cours IFT3150
 * @author Réaliser par Hanifa Mallek
 * Sujet : Gestion des Voyages par machine d'états
 * 
 * Cette classe représnte le controleur, la classe principale 
 * qui permet de faire le lien entre la machine d'état et le monde extérieur.
 */


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;

import Entities.Avion;
import Entities.Compagnie;
import Entities.Etroit;
import Entities.MoyenTransport;
import Entities.Paquebot;
import Entities.Port;
import Entities.Section;
import Entities.Train;
import Entities.Voyage;
import commande.Commande;
import fabrique.FabriqueAerienne;
import fabrique.FabriqueCroisiere;
import fabrique.FabriqueEntiteVoyage;
import fabrique.FabriqueTrain;
import gui.AdminCompagniePanel;
import gui.AdminFrameAddButtonAssignerPrix;
import gui.AdminFrameAddButtonCreerSection;
import gui.AdminFrameAssignerPrixCompagnie;
import gui.AdminFrameCompagnie;
import gui.AdminFramePort;
import gui.AdminFrameSectionAvion;
import gui.AdminFrameSectionPaquebot;
import gui.AdminFrameSectionTrain;
import gui.AdminFrameTransport;
import gui.AdminFrameVoyage;
import gui.AdminGUI;
import gui.AdminPanelTripSelected;
import invocator.Invocateur;
import lists.JListAerienne;
import lists.JListCroisiere;
import lists.JListGeneral;
import lists.JListTrain;
import methode.AssignerPrix;
import methode.CreerCompagnie;
import methode.CreerMoyenTransport;
import methode.CreerPort;
import methode.CreerSection;
import methode.CreerVoyage;
import methode.ModifierCompagnie;
import methode.ModifierMoyenTransport;
import methode.ModifierPort;
import methode.ModifierVoyage;
import methode.SupprimerCompagnie;
import methode.SupprimerMoyenTransport;
import methode.SupprimerPort;
import methode.SupprimerVoyage;
import observer.Observateur;
import traveltripmodel.ITravelTripModelStatemachine.SCInterfaceOperationCallback;
import traveltripmodel.TravelTripModelStatemachine.State;
import traveltripmodel.TravelTripModelStatemachine;


public class TravelTripYakinduModel implements Observateur{
	
	FabriqueEntiteVoyage fabrique;
	JListGeneral jlist;
	private FabriqueEntiteVoyage fabriqueAerienne;
	private FabriqueEntiteVoyage fabriqueTrain;
	private FabriqueEntiteVoyage fabriqueCroisiere;
	JListTrain listTrain = new JListTrain();
	JListCroisiere listCroisiere = new JListCroisiere();
	JListAerienne listAerienne = new JListAerienne();
	
	String title, subTitle, portTitle, voyageTitle;
	private static TravelTripModelStatemachine stateMachine;
	private AdminGUI gui;
	AdminFrameCompagnie compagnieFrame;
	protected Commande commande;
	Invocateur invocateur;
	AdminFrameAddButtonAssignerPrix panelAddButtonAssigner;
	AdminCompagniePanel compagniePanel, voyagePanel, vehiculePanel, portPanel;
	private Compagnie comp;
	protected AdminFrameAddButtonCreerSection panelAddButtonCreerSec;
	private AdminFramePort portFrame;
	private Port port;
	protected int index;
	protected AdminFrameAssignerPrixCompagnie assignPricePanel;
	protected AdminFrameTransport vehiculeFrame;
	protected MoyenTransport transp;
	protected AdminFrameSectionAvion sectionAvionFrame;
	protected AdminFrameSectionPaquebot sectionPaquebot;
	protected AdminFrameSectionTrain sectionTrain;
	protected AdminFrameVoyage voyageFrame;
	protected Voyage voyage;
	private SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd:HH.mm");
	protected AdminPanelTripSelected paquebotVoyPanel, trainVoyPanel, avionVoyPanel;

 
	public static void main(String[] args) {
		TravelTripYakinduModel travelTripYakinduModel = new TravelTripYakinduModel();
		travelTripYakinduModel.createContents();
		travelTripYakinduModel.setupStatemachine();
		travelTripYakinduModel.run();
		
	}
	
	
	/* Execution de la machine d'états
	 * 
	 */
	private void run() {
		stateMachine.enter();
		stateMachine.runCycle();
	}
	
	/*Mise en place du contenu de la GUI
	 * 
	 */
	private void createContents() {
		 initialValues();
		 update();
		 gui = new AdminGUI();
		 gui.setVisible(true);

	 	gui.getBtnVoyageAvion().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				stateMachine.getSCInterface().raiseVoyageAvionClicked();
				
				stateMachine.getSCInterface().raiseOperations();
				stateMachine.runCycle();
											
			}
		});
		gui.getBtnVoyageBateau().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
						stateMachine.getSCInterface().raiseVoyageBateauClicked();
						stateMachine.getSCInterface().raiseOperations();

						stateMachine.runCycle();
						
			}
		});	
		gui.getBtnVoyageTrain().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

						stateMachine.getSCInterface().raiseVoyageTrainClicked();
						stateMachine.getSCInterface().raiseOperations();
						stateMachine.runCycle();
			}
		});
			
		
	}
	
	/* Mise en place de la machine d'états
	 * 
	 */
	void setupStatemachine() {
		stateMachine = new TravelTripModelStatemachine();
		stateMachine.getSCInterface().setSCInterfaceOperationCallback(new SCInterfaceOperationCallback() {

			
			public void assignPrice() {
				commande = new AssignerPrix(fabrique, comp, assignPricePanel.getPleinTarif());
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
				assignPricePanel.getBtn().setEnabled(true);
				assignPricePanel.dispose();
				assignPriceCompagnieEnd();
			}


			public void createCompagnie() {
				
				commande = new CreerCompagnie(fabrique, compagnieFrame.getTxtCompagnieID().getText(), compagnieFrame.getTxtNomCompagnie().getText());
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
				
				createCompagnieEnd();
			}

			@Override
			public void modifyCompagnie() {
								
				commande = new ModifierCompagnie(fabrique, comp, compagnieFrame.getTxtCompagnieID().getText(), compagnieFrame.getTxtNomCompagnie().getText());				
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
				panelAddButtonAssigner.getBtnAnnuler().setEnabled(true);
				compagnieFrame.dispose();
				modifyCompagnieEnd();
			}

			@Override
			public void deleteCompagnie() {
				
				commande = new SupprimerCompagnie(fabrique, compagnieFrame.getTxtCompagnieID().getText());
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
				panelAddButtonAssigner.getBtnAnnuler().setEnabled(true);
				compagnieFrame.dispose();	
				deleteCompagnieEnd();
			}

			@Override
			public void selectCompModification() {
			}

			@Override
			public void selectCompDeletion() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void selectItemAssignPrice() {
				// TODO Auto-generated method stub
				
			}

			

			@Override
			public void createVehicule() {
								
				comp = (Compagnie)fabrique.getObjetParIndex(vehiculeFrame.getComboBoxCompagnie().getSelectedIndex(), fabrique.getListeCompagnies());
				commande = new CreerMoyenTransport(fabrique, vehiculeFrame.getTxtTransportID().getText(), comp);
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
				panelAddButtonCreerSec.getBtnAnnuler().setEnabled(true);
				vehiculeFrame.dispose();
				createVehiculeEnd();
			}
			@Override
			public void modifyVehicule() {
				
				vehiculeFrame.setVisible(true);
				Compagnie c = (Compagnie)fabrique.getObjetParIndex(vehiculeFrame.getComboBoxCompagnie().getSelectedIndex(), fabrique.getListeCompagnies());
				commande = new ModifierMoyenTransport(fabrique, transp, vehiculeFrame.getTxtTransportID().getText(), c);
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
				panelAddButtonCreerSec.getBtnAnnuler().setEnabled(true);
				vehiculeFrame.dispose();
				modifyVehiculeEnd();
			}

			@Override
			public void deleteVehicule() {
				
				commande = new SupprimerMoyenTransport(fabrique, transp.getTransportID());
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
				panelAddButtonCreerSec.getBtnAnnuler().setEnabled(true);
				deleteVehiculeEnd();
			}

			@Override
			public void selectVehicModification() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void selectVehicDeletion() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void selectItemCreateSection() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void createSection() {
				
				if(stateMachine.getVoyageAvionTrigger()==true) {
					commande = new CreerSection(transp, sectionAvionFrame.getSectionType(), sectionAvionFrame.getDisposition(), sectionAvionFrame.getNbRangees());
					invocateur.setCommande(commande);
					invocateur.pressExecuteButton(commande);
					panelAddButtonCreerSec.getBtnAnnuler().setEnabled(true);
					sectionAvionFrame.dispose();
					createSectionEnd();
				}
				if(stateMachine.getVoyagePaquebotTrigger()==true) {
					commande = new CreerSection(transp, sectionPaquebot.getNbCabinesI(), sectionPaquebot.getNbCabinesO(), sectionPaquebot.getNbCabinesS(), sectionPaquebot.getNbCabinesF(), sectionPaquebot.getNbCabinesD());
					invocateur.setCommande(commande);
					invocateur.pressExecuteButton(commande);
					panelAddButtonCreerSec.getBtnAnnuler().setEnabled(true);
					sectionPaquebot.dispose();
					createSectionEnd();
				}
				if(stateMachine.getVoyageTrainTrigger()==true) {
					commande = new CreerSection(transp, sectionTrain.getNbRangeesP(), sectionTrain.getNbRangeesE());										invocateur.setCommande(commande);
					invocateur.pressExecuteButton(commande);
					panelAddButtonCreerSec.getBtnAnnuler().setEnabled(true);
					sectionTrain.dispose();
					createSectionEnd();
				}
			}

			@Override
			public void createPort() {
				
				commande = new CreerPort(fabrique, portFrame.getTxtPortID().getText(), 
				portFrame.getTxtNomPort().getText(), portFrame.getTxtVille().getText());
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
							
				 createPortEnd();
			}

			@Override
			public void modifyPort() {

				commande = new ModifierPort(fabrique, port, portFrame.getTxtPortID().getText(), portFrame.getTxtNomPort().getText(), portFrame.getTxtVille().getText());
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
				portPanel.getBtnAnnuler().setEnabled(true);
				portFrame.dispose();				
				modifyPortEnd();
			}

			@Override
			public void deletePort() {
				
				commande = new SupprimerPort(fabrique, port.getPortID());
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
				portPanel.getBtnAnnuler().setEnabled(true);
				deletePortEnd() ;
			}

			@Override
			public void createVoyage() {

				transp = (MoyenTransport)fabrique.getObjetParIndex(voyageFrame.getComboBoxTransport().getSelectedIndex(), fabrique.getListeTransports());
				Port pd = (Port)fabrique.getObjetParIndex(voyageFrame.getComboBoxPortDepart().getSelectedIndex(), fabrique.getListePorts());
				Port pa = (Port)fabrique.getObjetParIndex(voyageFrame.getComboBoxPortArrive().getSelectedIndex(), fabrique.getListePorts());
				
				commande = new CreerVoyage(fabrique, transp.getCompagnie(), transp, voyageFrame.getTxtVoyageID().getText(), voyageFrame.getDateHeureDepart(), voyageFrame.getDateHeureArrivee(), pd, pa);
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
				voyagePanel.getBtnAnnuler().setEnabled(true);

				voyageFrame.dispose();
				createVoyageEnd();
				
			}

			@Override
			public void modifyVoyage() {
				
			    transp = (MoyenTransport)fabrique.getObjetParIndex(voyageFrame.getComboBoxTransport().getSelectedIndex(), fabrique.getListeTransports());
				Port pd = (Port)fabrique.getObjetParIndex(voyageFrame.getComboBoxPortDepart().getSelectedIndex(), fabrique.getListePorts());
				Port pa = (Port)fabrique.getObjetParIndex(voyageFrame.getComboBoxPortArrive().getSelectedIndex(), fabrique.getListePorts());
				
				commande = new ModifierVoyage(fabrique,transp.getCompagnie(), transp, voyage, voyageFrame.getTxtVoyageID().getText(), voyageFrame.getDateHeureDepart(), voyageFrame.getDateHeureArrivee(), pd, pa);
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
				voyagePanel.getBtnAnnuler().setEnabled(true);
			
				voyageFrame.dispose();
				modifyVoyageEnd();
			}

			@Override
			public void deleteVoyage() {

				commande = new SupprimerVoyage(fabrique, voyage.getVoyageID());
				invocateur.setCommande(commande);
				invocateur.pressExecuteButton(commande);
				voyagePanel.getBtnAnnuler().setEnabled(true);	
				deleteVoyageEnd();

			}	
			
			
			public void avionVoyPanelAdmin() {
				avionVoyPanel =  new AdminPanelTripSelected("Compagnie Aérienne","Avion", "Aéroport", "Vol");
				choix();
				
				avionVoyPanel.getBtnCompagnie().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						
						
						compagniePanel = new AdminCompagniePanel(title, jlist, FabriqueAerienne.getInstance());		 		 		 

						panelAddButtonAssigner = new AdminFrameAddButtonAssignerPrix(compagniePanel);
						
						popupPanelCompagnie();
					}
				});
				
				avionVoyPanel.getBtnVehicule().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						
						vehiculePanel= new AdminCompagniePanel(subTitle, jlist, FabriqueAerienne.getInstance());		 		 		 

						panelAddButtonCreerSec = new AdminFrameAddButtonCreerSection(vehiculePanel);
						
						popupPanelTransport();				
					}
				});
				avionVoyPanel.getBtnPort().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						
						portPanel =new AdminCompagniePanel(portTitle, jlist, FabriqueAerienne.getInstance()); 
						
						popupPanelPort();				

					}
				});
				avionVoyPanel.getBtnVoyage().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						voyagePanel =new AdminCompagniePanel(voyageTitle, jlist, FabriqueAerienne.getInstance()); 
						
						popupPanelVoyage();	
					}
				});
			}

			public void paquebotVoyPanelAdmin() {
				paquebotVoyPanel =  new AdminPanelTripSelected("Compagnie Croisiere","Paquebot", "Port", "Itinraire");
				choix();
				paquebotVoyPanel.getBtnCompagnie().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						choix();
						
						compagniePanel = new AdminCompagniePanel(title, jlist, FabriqueAerienne.getInstance());		 		 		 

						panelAddButtonAssigner = new AdminFrameAddButtonAssignerPrix(compagniePanel);
						
						popupPanelCompagnie();
					}
				});
				
				paquebotVoyPanel.getBtnVehicule().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						vehiculePanel= new AdminCompagniePanel(subTitle, jlist, FabriqueAerienne.getInstance());		 		 		 

						panelAddButtonCreerSec = new AdminFrameAddButtonCreerSection(vehiculePanel);
						
						popupPanelTransport();				
					}
				});
				paquebotVoyPanel.getBtnPort().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						portPanel =new AdminCompagniePanel(portTitle, jlist, FabriqueAerienne.getInstance()); 
						
						popupPanelPort();				

					}
				});
				paquebotVoyPanel.getBtnVoyage().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						voyagePanel =new AdminCompagniePanel(voyageTitle, jlist, FabriqueAerienne.getInstance()); 
						
						popupPanelVoyage();	
					}
				});				
			}

			public void trainVoyPanelAdmin() {
				trainVoyPanel =  new AdminPanelTripSelected("Compagnie Croisiere","Paquebot", "Port", "Itinraire");
				choix();
				trainVoyPanel.getBtnCompagnie().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
					
						
						compagniePanel = new AdminCompagniePanel(title, jlist, FabriqueAerienne.getInstance());		 		 		 

						panelAddButtonAssigner = new AdminFrameAddButtonAssignerPrix(compagniePanel);
						
						popupPanelCompagnie();
					}
				});
				
				trainVoyPanel.getBtnVehicule().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						
						vehiculePanel= new AdminCompagniePanel(subTitle, jlist, FabriqueAerienne.getInstance());		 		 		 

						panelAddButtonCreerSec = new AdminFrameAddButtonCreerSection(vehiculePanel);
						
						popupPanelTransport();				
					}
				});
				trainVoyPanel.getBtnPort().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
					
						portPanel =new AdminCompagniePanel(portTitle, jlist, FabriqueAerienne.getInstance()); 
						
						popupPanelPort();				

					}
				});
				trainVoyPanel.getBtnVoyage().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						voyagePanel =new AdminCompagniePanel(voyageTitle, jlist, FabriqueAerienne.getInstance()); 
						
						popupPanelVoyage();	
					}
				});								
			}



			@Override
			public void selectPortModification() {
				// TODO Auto-generated method stub
				
			}



			@Override
			public void selectPortDeletion() {
				// TODO Auto-generated method stub
				
			}



			@Override
			public void selectVoyageModification() {
				// TODO Auto-generated method stub
				
			}



			@Override
			public void selectVoyageDeletion() {
				// TODO Auto-generated method stub
				
			}

			
		});
		stateMachine.init();
}
	

	
	/*Gestion des boutons du panel de compagnie avec les machines d'états
	 * 
	 */
	
	public void popupPanelCompagnie() {
	
		panelAddButtonAssigner.getBtnAjouter().addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
//				stateMachine.runCycle();
				compagnieFrame = new AdminFrameCompagnie();
				compagnieFrame.setTitle("Création de compagnie");
				compagnieFrame.getBtnCreer().setText("Créer");
//				compagnieFrame.setVisible(true);
				
				compagnieFrame.getBtnCreer().addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						
						
						stateMachine.getSCInterface().raiseAddClickedCompagnie();
						stateMachine.runCycle();
					
					}
					
				});
				
			}
			
		}); 
		
		panelAddButtonAssigner.getBtnModifier().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					stateMachine.setIndexList(jlist.getSelectedIndex());
					stateMachine.getSCInterface().raiseSelectModifyCompagnie();
					stateMachine.runCycle();
					if (stateMachine.getIndexList() == -1) {
						JOptionPane.showMessageDialog(compagnieFrame, "Veuillez sélectionner une "+title+" à modifier.");
						stateMachine.runCycle();
					}else {
					
						compagnieFrame = new AdminFrameCompagnie();
						compagnieFrame.setTitle("Modification de la compagnie");
						compagnieFrame.getBtnCreer().setText("Modifier");
//						compagnieFrame.setVisible(true);
						index = jlist.getSelectedIndex();
						comp = (Compagnie)fabrique.getObjetParIndex(index, fabrique.getListeCompagnies());
						compagnieFrame.getTxtCompagnieID().setText(comp.getCompagnieID());
						compagnieFrame.getTxtNomCompagnie().setText(comp.getNomCompagnie());

						compagnieFrame.getBtnCreer().addActionListener(new ActionListener() {				
							@Override
							public void actionPerformed(ActionEvent e) {

								stateMachine.getSCInterface().raiseModifyClickedCompagnie();
								stateMachine.runCycle();
							
													
							}
						
						});
					}
					
				}
				
			}); 
		
		panelAddButtonAssigner.getBtnSupprimer().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				
					stateMachine.setIndexList(jlist.getSelectedIndex());
					stateMachine.getSCInterface().raiseSelectDeleteCompagnie();
					stateMachine.runCycle();
					
					index = (int) stateMachine.getIndexList() ;
					if (stateMachine.getIndexList() == -1) {
						JOptionPane.showMessageDialog(compagnieFrame, "Veuillez sélectionner une "+title+" à supprimer.");
						stateMachine.runCycle();
					}else {		
						
						compagnieFrame = new AdminFrameCompagnie();
						compagnieFrame.setVisible(false);
						comp = (Compagnie)fabrique.getObjetParIndex(index, fabrique.getListeCompagnies());
						compagnieFrame.getTxtCompagnieID().setText(comp.getCompagnieID());
						compagnieFrame.getTxtNomCompagnie().setText(comp.getNomCompagnie());

						compagnieFrame.getBtnCreer().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {

							stateMachine.getSCInterface().raiseDeleteClickedCompagnie();
							stateMachine.runCycle();
							
						}
						
					});
				 }
					
				}
				
			});
		
		    panelAddButtonAssigner.getBtnAssigner().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					stateMachine.setIndexList(jlist.getSelectedIndex());
					stateMachine.getSCInterface().raiseSelectPriceAssign();
					stateMachine.runCycle();
					if (stateMachine.getIndexList() == -1) {
						JOptionPane.showMessageDialog(compagnieFrame, "Veuillez sélectionner une "+title+ " pour assigner un prix.");
						stateMachine.runCycle();
					}else {
						
					
						assignPricePanel = new AdminFrameAssignerPrixCompagnie();
						assignPricePanel.setVisible(true);
						index = jlist.getSelectedIndex();
						comp = (Compagnie)fabrique.getObjetParIndex(index, fabrique.getListeCompagnies());
						assignPricePanel.getLblCompagnieID().setText("CompagnieID: " + comp.getCompagnieID());
						assignPricePanel.getLblNomCompagnie().setText("Nom de la compagnie: " + comp.getNomCompagnie());
						
						
						
						assignPricePanel.getBtn().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							

							stateMachine.getSCInterface().raiseAssignPriceClicked();
							stateMachine.runCycle();
												
							
						}
						
					});
				 }
					
				}
				
			});
		    
		    panelAddButtonAssigner.getBtnAnnuler().addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
						stateMachine.getSCInterface().raiseCancelOperationCompagnie();
						if (invocateur.getCommande() == null) {
							JOptionPane.showMessageDialog(null, "Aucune action a ete effectuee precedement.");
						} else {
							
							invocateur.pressUnexecuteButton();
							panelAddButtonAssigner.getBtnAnnuler().setEnabled(false);
						}
						stateMachine.runCycle();		
				}
				
			});
		
	}
	

	/*
	 * Gestion des boutons du panel des vehicules avec les machines d'états
	 */
	
	public void popupPanelTransport() {
			panelAddButtonCreerSec.getBtnAjouter().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
					vehiculeFrame = new AdminFrameTransport();
					vehiculeFrame.setTitle("Création de "+subTitle);
					vehiculeFrame.getBtn().setText("Créer");
//					vehiculeFrame.setVisible(true);
 
					for (Compagnie c: fabrique.getListeCompagnies().values()) {
						vehiculeFrame.getComboBoxCompagnie().addItem(c.getNomCompagnie());
					}
					vehiculeFrame.getBtn().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							stateMachine.getSCInterface().raiseAddClickedVehicule();
							stateMachine.runCycle();					
						}
						
					});
					
				}
				
			}); 
			
			panelAddButtonCreerSec.getBtnModifier().addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
						stateMachine.setIndexList(jlist.getSelectedIndex());
						stateMachine.getSCInterface().raiseSelectModifyVehicule();
						stateMachine.runCycle();
						if (stateMachine.getIndexList() == -1) {
							JOptionPane.showMessageDialog(vehiculeFrame, "Veuillez sélectionner un "+subTitle +" à modifier.");
							stateMachine.runCycle();
						}else {
							
							vehiculeFrame = new AdminFrameTransport();
							vehiculeFrame.setTitle("Modification du véhicule");
							vehiculeFrame.getBtn().setText("Modifier");
							vehiculeFrame.setVisible(true);
							index = jlist.getSelectedIndex();
							for (Compagnie comp: fabrique.getListeCompagnies().values()) {
								vehiculeFrame.getComboBoxCompagnie().addItem(comp.getNomCompagnie());
							}
							
							transp = (MoyenTransport)fabrique.getObjetParIndex(index, fabrique.getListeTransports());
							vehiculeFrame.getTxtTransportID().setText(transp.getTransportID());
							vehiculeFrame.getComboBoxCompagnie().setSelectedItem(transp.getCompagnie().getNomCompagnie());
							
		
							vehiculeFrame.getBtn().addActionListener(new ActionListener() {

							@Override
							public void actionPerformed(ActionEvent e) {
								stateMachine.getSCInterface().raiseModifyClickedVehicule();
								stateMachine.runCycle();
								
							}
							
						});
						}
						
					}
					
				}); 
			
			panelAddButtonCreerSec.getBtnSupprimer().addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
						stateMachine.setIndexList(jlist.getSelectedIndex());
						stateMachine.getSCInterface().raiseSelectDeleteVehicule();
						stateMachine.runCycle();
						if (stateMachine.getIndexList() == -1) {
							JOptionPane.showMessageDialog(vehiculeFrame, "Veuillez sélectionner un " + subTitle +" à supprimer.");
							stateMachine.runCycle();
						}else {
							
						
							index = ((int)stateMachine.getIndexList());
							transp = (MoyenTransport)fabrique.getObjetParIndex(index, fabrique.getListeTransports());
							int answer = JOptionPane.showConfirmDialog(panelAddButtonCreerSec, "Etes-vous sur de vouloir supprimer le vehicule " + transp.getTransportID() + "de la compagnie " + transp.getCompagnie().getNomCompagnie() + " ?");
							
							if (answer == JOptionPane.YES_OPTION) {
								stateMachine.getSCInterface().raiseDeleteClickedVehicule();
								stateMachine.runCycle();
								
							}
							
					 }
						
					}
					
				});
			
			panelAddButtonCreerSec.getBtnCreerSection().addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
						stateMachine.setIndexList(jlist.getSelectedIndex());
						stateMachine.getSCInterface().raiseSelectVehicule();
						stateMachine.runCycle();
						index = (int) (stateMachine.getIndexList());
						if (index == -1) {
							JOptionPane.showMessageDialog(vehiculeFrame, "Veuillez sélectionner une compagnie pour assigner un prix.");
							stateMachine.runCycle();
						}else {
							if(stateMachine.getVoyageAvionTrigger()==true) {
								sectionAvionFrame = new AdminFrameSectionAvion();
								sectionAvionFrame.setVisible(true);
    							transp = (MoyenTransport)fabrique.getObjetParIndex(index, fabrique.getListeTransports());
								for (Section s: transp.getSections().values()) {
									sectionAvionFrame.enleverSection(s.getType());
								}
								sectionAvionFrame.getBtn().addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										stateMachine.getSCInterface().raiseCreateSectionClicked();
										stateMachine.runCycle();
										
									}
								});
								
							}
							if(stateMachine.getVoyagePaquebotTrigger()==true) {
								sectionPaquebot = new AdminFrameSectionPaquebot();
								sectionPaquebot.setVisible(true);
								sectionPaquebot.getBtn().addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										stateMachine.getSCInterface().raiseCreateSectionClicked();
										stateMachine.runCycle();
										
									}
								});
							}
							
							if(stateMachine.getVoyageTrainTrigger()==true) {
								sectionTrain = new AdminFrameSectionTrain();
								sectionTrain.setVisible(true);
								sectionTrain.getBtn().addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										stateMachine.getSCInterface().raiseCreateSectionClicked();
										stateMachine.runCycle();
										
									}
								});
							}			
						}
				}
								
			}	
				
		);
			panelAddButtonCreerSec.getBtnAnnuler().addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
							stateMachine.getSCInterface().raiseCancelOperationVehicule();
							if (invocateur.getCommande() == null) {
								JOptionPane.showMessageDialog(null, "Aucune action a ete effectuee precedement.");
							} else {
								invocateur.pressUnexecuteButton();
								panelAddButtonAssigner.getBtnAnnuler().setEnabled(false);
							}
							stateMachine.runCycle();		
					}
					
			});
			
	}
	
	
	/*
	 * Gestion des boutons du panel des ports avec les machines d'états
	 */

		public void popupPanelPort() {
			portPanel.getBtnAjouter().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					
					portFrame = new AdminFramePort();
					portFrame.setTitle("Création d'un port");
					portFrame.getBtn().setText("Créer");
					portFrame.setVisible(true);
					
					portFrame.getBtn().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							stateMachine.getSCInterface().raiseAddClickedPort();
							stateMachine.runCycle();
						}
						
					});
					
				}
				
			}); 
			
			portPanel.getBtnModifier().addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
						stateMachine.setIndexList(jlist.getSelectedIndex());
						stateMachine.getSCInterface().raiseSelectModifyPort();
						stateMachine.runCycle();
						index = ((int)stateMachine.getIndexList());
						if (stateMachine.getIndexList() == -1) {
							JOptionPane.showMessageDialog(portFrame, "Veuillez sélectionner une "+portTitle+" à modifier.");
							stateMachine.runCycle();
						}else {
						
							portFrame = new AdminFramePort();
							portFrame.setTitle("Modification du port");
							portFrame.getBtn().setText("Modifier");
							portFrame.setVisible(true);
							
							port = (Port)fabrique.getObjetParIndex(index, fabrique.getListePorts());							
							portFrame.getTxtPortID().setText(port.getPortID());
							portFrame.getTxtNomPort().setText(port.getNomPort());
							portFrame.getTxtVille().setText(port.getVille());							

							portFrame.getBtn().addActionListener(new ActionListener() {				
								@Override
								public void actionPerformed(ActionEvent e) {
									stateMachine.getSCInterface().raiseModifyClickedPort();
									stateMachine.runCycle();
								
														
								}
							
							});
						}
						
					}
					
				}); 
			
			portPanel.getBtnSupprimer().addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
						stateMachine.setIndexList(jlist.getSelectedIndex());
						stateMachine.getSCInterface().raiseSelectDeletePort();
						stateMachine.runCycle();
						if (stateMachine.getIndexList() == -1) {
							JOptionPane.showMessageDialog(portFrame, "Veuillez sélectionner un "
										+portTitle+" à supprimer.");
							stateMachine.runCycle();
						}else {
							
							 port = (Port)fabrique.getObjetParIndex(index, fabrique.getListePorts());
							 int answer = JOptionPane.showConfirmDialog(portPanel, 
									 "Etes-vous sur de vouloir supprimer le port " + port.getNomPort() 
									 + "(" + port.getPortID() +") ?");
							 if (answer == JOptionPane.YES_OPTION) {
								stateMachine.getSCInterface().raiseDeleteClickedPort();
								stateMachine.runCycle();
							}
							
					
						}	
					}
					
				});
			
			portPanel.getBtnAnnuler().addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
							stateMachine.getSCInterface().raiseCancelOperationCompagnie();
							if (invocateur.getCommande() == null) {
								JOptionPane.showMessageDialog(null, "Aucune action a ete effectuee precedement.");
							} else {
								invocateur.pressUnexecuteButton();
								portPanel.getBtnAnnuler().setEnabled(false);
							}
							stateMachine.runCycle();		
					}
					
				});
			
		}

		
		/*
		 * Gestion des boutons du panel des voyage avec les machines d'états
		 */

				public void popupPanelVoyage() {
					voyagePanel.getBtnAjouter().addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
							
							voyageFrame = new AdminFrameVoyage();
							voyageFrame.setTitle("Création d'un voyage");
							voyageFrame.getBtn().setText("Créer");
							voyageFrame.setVisible(true);

							for (MoyenTransport transp: fabrique.getListeTransports().values()) {
								voyageFrame.getComboBoxTransport().addItem(transp.getTransportID());
							}
							for (Port port: fabrique.getListePorts().values()) {
								voyageFrame.getComboBoxPortDepart().addItem(port.getNomPort());
								voyageFrame.getComboBoxPortArrive().addItem(port.getNomPort());
							}
							if (fabrique instanceof FabriqueCroisiere) {
								voyageFrame.getComboBoxPortArrive().setEnabled(false);
							}
							voyageFrame.getBtn().addActionListener(new ActionListener() {

								@Override
								public void actionPerformed(ActionEvent e) {
									stateMachine.getSCInterface().raiseAddClickedVoyage();
									stateMachine.runCycle();
								}
								
							});
							
						}
						
					}); 
					
					voyagePanel.getBtnModifier().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
								stateMachine.setIndexList(jlist.getSelectedIndex());
								stateMachine.getSCInterface().raiseSelectModifyPort();
								stateMachine.runCycle();
								index = ((int)stateMachine.getIndexList());
								if (stateMachine.getIndexList() == -1) {
									JOptionPane.showMessageDialog(portFrame, "Veuillez sélectionner une "+voyageTitle+" à modifier.");
									stateMachine.runCycle();
								}else {
								
									voyageFrame = new AdminFrameVoyage();
									voyageFrame.setTitle("Modification du voyage");
									voyageFrame.getBtn().setText("Modifier");
									voyageFrame.setVisible(true);
									for (MoyenTransport t: fabrique.getListeTransports().values()) {
										voyageFrame.getComboBoxTransport().addItem(t.getTransportID());
									}
									for (Port p: fabrique.getListePorts().values()) {
										voyageFrame.getComboBoxPortDepart().addItem(p.getNomPort());
										voyageFrame.getComboBoxPortArrive().addItem(p.getNomPort());
									}
									if (fabrique instanceof FabriqueCroisiere) {
										voyageFrame.getComboBoxPortArrive().setEnabled(false);
									}
								
									voyage = (Voyage)fabrique.getObjetParIndex(index, fabrique.getListeVoyages());
									voyageFrame.getComboBoxTransport().setSelectedItem(voyage.getTransport().getTransportID());
									voyageFrame.getTxtVoyageID().setText(voyage.getVoyageID());
									
									voyageFrame.getTxtDateHeureDepart().setText(df.format(voyage.getDateHeureDepart()));
									
									voyageFrame.getTxtDateHeureArrivee().setText(df.format(voyage.getDateHeureArrivee()));
								
									voyageFrame.getBtn().addActionListener(new ActionListener() {				
										@Override
										public void actionPerformed(ActionEvent e) {
											stateMachine.getSCInterface().raiseModifyClickedVoyage();
											stateMachine.runCycle();
										
																
										}
									
									});
								}
								
							}
							
						}); 
					
					voyagePanel.getBtnSupprimer().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
								stateMachine.setIndexList(jlist.getSelectedIndex());
								stateMachine.getSCInterface().raiseSelectDeletePort();
								stateMachine.runCycle();
								if (stateMachine.getIndexList() == -1) {
									JOptionPane.showMessageDialog(portFrame, "Veuillez sélectionner un "+voyageTitle+" à supprimer.");
									stateMachine.runCycle();
								}else {
									
									comp = (Compagnie)fabrique.getObjetParIndex(index, fabrique.getListeCompagnies());
									int answer = JOptionPane.showConfirmDialog(voyagePanel, "Etes-vous sur de vouloir supprimer la compagnie " + comp.getNomCompagnie() + "(" + comp.getCompagnieID() +") ?");
									if (answer == JOptionPane.YES_OPTION) {
										stateMachine.getSCInterface().raiseDeleteClickedVoyage();
										stateMachine.runCycle();
									}
								
							}
						}	
					});
					
					voyagePanel.getBtnAnnuler().addActionListener(new ActionListener() {

							@Override
							public void actionPerformed(ActionEvent e) {
									stateMachine.getSCInterface().raiseCancelOperationVoyage();
									if (invocateur.getCommande() == null) {
										JOptionPane.showMessageDialog(null, "Aucune action a ete effectuee precedement.");
									} else {
										invocateur.pressUnexecuteButton();
										voyagePanel.getBtnAnnuler().setEnabled(false);
									}
									stateMachine.runCycle();		
							}
							
						});
					
				}

		/*
		 *  raiser la derniere de la création du vehicule
		 */
	private void createVehiculeEnd() {
		panelAddButtonAssigner.getBtnAnnuler().setEnabled(true);
		stateMachine.getSCInterface().raiseVehiculeCreated();
		stateMachine.runCycle();	
		vehiculeFrame.dispose();
	}
	/*
	 *  raiser la derniere de la création du compagnie
	 */
	
	private void createCompagnieEnd() {
		panelAddButtonAssigner.getBtnAnnuler().setEnabled(true);
		compagnieFrame.dispose();
		stateMachine.getSCInterface().raiseCompagnyCreated();
		stateMachine.runCycle();
	}
	
	/*
	 *  raiser la derniere de la création du port
	 */
	
	private void createPortEnd() {
		portPanel.getBtnAnnuler().setEnabled(true);	
		portFrame.dispose();	
		stateMachine.getSCInterface().raisePortCreated();
		stateMachine.runCycle();
	}
	
	/*
	 *  raiser la derniere de la création du voyage
	 */
	
	private void createVoyageEnd() {
		stateMachine.getSCInterface().raiseVoyageCreated();
		stateMachine.runCycle();
	}
	
	/*
	 *  raiser la derniere de la modification du compagnie
	 */
	private void modifyCompagnieEnd() {
		stateMachine.getSCInterface().raiseCompagnieModified();
		stateMachine.runCycle();
	}
	
	/*
	 *  raiser la derniere de la modification du véhicule
	 */
	private void modifyVehiculeEnd() {
		stateMachine.getSCInterface().raiseVehiculeModified();
		stateMachine.runCycle();
	}
	
	/*
	 *  raiser la derniere de la modification du port
	 */
	
	private void modifyPortEnd() {
		stateMachine.getSCInterface().raisePortModified();
		stateMachine.runCycle();
	}
	
	/*
	 *  raiser la derniere de la modification du voyage
	 */
	
	private void modifyVoyageEnd() {
		stateMachine.getSCInterface().raiseVoyageModified();
		stateMachine.runCycle();
	}
	
	/*
	 *  raiser la derniere de la suppression de la compagnie
	 */
	
	private void deleteCompagnieEnd() {
		stateMachine.getSCInterface().raiseCompagnieDeleted();
		stateMachine.runCycle();
	}
	
	/*
	 *  raiser la derniere de la suppression du vehicule
	 */ 
	
	private void deleteVehiculeEnd() {
		stateMachine.getSCInterface().raiseVehiculeDeleted();
		stateMachine.runCycle();
	}
	
	/*
	 *  raiser la derniere de la suppression du port
	 */
	
	private void deletePortEnd() {
		stateMachine.getSCInterface().raisePortDeleted();
		stateMachine.runCycle();
	}
	
	/*
	 *  raiser la derniere de la suppression du port
	 */
	private void deleteVoyageEnd() {
		stateMachine.getSCInterface().raiseVoyageDeleted();
		stateMachine.runCycle();
	}
	
	/*
	 * raiser la derniere de la assignation des prix
	 */
	private void assignPriceCompagnieEnd() {
		stateMachine.getSCInterface().raisePriceAssigned();
		stateMachine.runCycle();	
	}
	
	/*
	 * raiser la derniere de la création de section 
	 */
	
	private void createSectionEnd() {
		stateMachine.getSCInterface().raiseCreateSectionClicked();
		stateMachine.runCycle();
	}

	/*
	 *  update de l'observeur
	 */
	@Override
	public void update() {
		FabriqueEntiteVoyage fabriques[] = {fabriqueAerienne, fabriqueTrain, fabriqueCroisiere};

		JListGeneral jlistsC[] = {listAerienne, listTrain, listCroisiere};
		for (int i=0; i<3; i++) {
			jlistsC[i].getDefaultListe().clear();
			for (Compagnie c: fabriques[i].getListeCompagnies().values()) {
				c.accepte(jlistsC[i]);
				jlistsC[i].getDefaultListe().addElement(jlistsC[i].getTexte());
				jlistsC[i].getDefaultListe().addElement(jlistsC[i].getTexte());
				jlistsC[i].setModel(jlistsC[i].getDefaultListe());
				jlistsC[i].repaint();
			}

		}

		JListGeneral jlistsT[] = {listAerienne, listTrain, listCroisiere};
		
		for (int i=0; i<3; i++) {
			jlistsT[i].getDefaultListe().clear();
			for (MoyenTransport t: fabriques[i].getListeTransports().values()) {
				t.accepte(jlistsT[i]);
				jlistsT[i].getDefaultListe().addElement(jlistsT[i].getTexte());
				jlistsT[i].setModel(jlistsT[i].getDefaultListe());
			}
		}
	
		JListGeneral jlistsP[] = {listAerienne, listTrain, listCroisiere};
		for (int i=0; i<3; i++) {
			jlistsP[i].getDefaultListe().clear();
			for (Port p: fabriques[i].getListePorts().values()) {
				p.accepte(jlistsP[i]);
				jlistsP[i].getDefaultListe().addElement(jlistsP[i].getTexte());
				jlistsP[i].setModel(jlistsP[i].getDefaultListe());
			}
		}
	

		JListGeneral jlistsV[] = {listAerienne, listTrain, listCroisiere};
		for (int i=0; i<3; i++) {
			jlistsV[i].getDefaultListe().clear();
			for (Voyage v: fabriques[i].getListeVoyages().values()) {
				v.accepte(jlistsV[i]);
				jlistsV[i].getDefaultListe().addElement(jlistsV[i].getTexte());
				jlistsV[i].setModel(jlistsV[i].getDefaultListe());
			}
		}		
		
	}
	
	/*
	 * initialisation des entités
	 */
	protected void initialValues() {
		
		invocateur  = Invocateur.getInstance();
		fabriqueAerienne = FabriqueAerienne.getInstance();
		fabriqueTrain = FabriqueTrain.getInstance();
		fabriqueCroisiere = FabriqueCroisiere.getInstance();
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd:HH.mm");
		// 6 Dates
		Date d1=null, d2=null, d3=null, d4=null, d5=null, d6=null;
		try {
			d1 = df.parse("2016.12.24:23.30");
			d2 = df.parse("2017.01.05:11.30");
			d3 = df.parse("2017.02.28:10.00");
			d4 = df.parse("2017.03.05:20.00");
			d5 = df.parse("2017.03.10:14.00");
			d6 = df.parse("2017.03.15:08.00");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// 6 compagnies
		Compagnie c1 = fabriqueAerienne.creerCompagnie("AIR01", "Nom compagnie aerienne");
		Compagnie c2 = fabriqueTrain.creerCompagnie("TRAIN01", "Nom compagnie train");
		Compagnie c3 = fabriqueCroisiere.creerCompagnie("CROIS01", "Nom compagnie croisiere");
		Compagnie c4 = fabriqueAerienne.creerCompagnie("AIRNDSlnf01", "Nom compagnie aerienne1");
		Compagnie c5 = fabriqueTrain.creerCompagnie("TRAIjndsNN01", "Nom compagnie train1");
		Compagnie c6 = fabriqueCroisiere.creerCompagnie("CRNsèlkndOIS01", "Nom compagnie croisiere1");
		
		// Assignation de prix aux 6 compagnies
		fabriqueAerienne.assignerPrix(c1, 342);
		fabriqueTrain.assignerPrix(c2, 151);
		fabriqueCroisiere.assignerPrix(c3, 1352);
		fabriqueAerienne.assignerPrix(c4, 342);
		fabriqueTrain.assignerPrix(c5, 151);
		fabriqueCroisiere.assignerPrix(c6, 1352);
		
		// 6 vehicules
		MoyenTransport t1 = fabriqueAerienne.creerTransport("AVIONID01", c1);
		MoyenTransport t2 = fabriqueTrain.creerTransport("TRAINID01", c2);
		MoyenTransport t3 = fabriqueCroisiere.creerTransport("PAQUID01", c3);
		MoyenTransport t4 = fabriqueAerienne.creerTransport("AVIOtnèdlksnfèyD01", c4);
		MoyenTransport t5 = fabriqueTrain.creerTransport("TRAINjndsJFNhdoh1", c5);
		MoyenTransport t6 = fabriqueCroisiere.creerTransport("PAQkln;fNVUID01", c6);
		
		// Creation de section pour les 6 types de vehicules
		((Avion)t1).creerSection('F', new Etroit(), 15);
		((Train)t2).creerSection(12, 42);
		((Paquebot)t3).creerSection(2, 5, 10, 3, 20);
		((Avion)t4).creerSection('F', new Etroit(), 15);
		((Train)t5).creerSection(12, 42);
		((Paquebot)t6).creerSection(2, 5, 10, 3, 20);
		
		// 5 Ports
		Port p0 = fabriqueAerienne.creerPort("AEROID00", "Aeroport 0", "Montreal");
		Port p1 = fabriqueAerienne.creerPort("AEROID01", "Aeroport 1", "Tokyo");
		Port p2 = fabriqueTrain.creerPort("GAREIndsèLNÈD01", "Gare 1", "Seoul");
		Port p3 = fabriqueTrain.creerPort("GARELNsdèlnID02", "Gare 2", "Tokyo");
		Port p4 = fabriqueCroisiere.creerPort("POlnslNRTID01", "Port Croisiere 1", "New York");
		Port p5 = fabriqueCroisiere.creerPort("POlnslNRTID02", "Port Croisiere 2", "Amsterdam");
		
		fabriqueAerienne.creerVoyage(c1, t1, "VOLID01", d1, d2, p0, p1);
		fabriqueTrain.creerVoyage(c2, t2, "TRAJID01", d3, d4, p2, p3);
		fabriqueCroisiere.creerVoyage(c3, t3, "ITINID01", d5, d6, p4, p4);		
		fabriqueAerienne.creerVoyage(c4, t4, "VOLIJNFÉ,DNÉNS;JND01", d1, d2, p0, p1);
		fabriqueTrain.creerVoyage(c5, t5, "TRAJ;JLKSNLDKNNNFID01", d3, d4, p2, p3);
		fabriqueCroisiere.creerVoyage(c6, t6, "ITILDS;NN;JNFJNID01", d5, d6, p4, p4);
		
		
	}

private void choix() {
	if(stateMachine.getVoyageAvionTrigger()== true) {
		title = "Compagnie aérienne";
		subTitle = "Avion";
		portTitle = "Aéroport";
		voyageTitle = "Vol";
		jlist = this.listAerienne;
		
	
//		System.out.println(listAerienne);

		
		fabrique = FabriqueAerienne.getInstance();

		
	}

	if(stateMachine.getVoyagePaquebotTrigger()==true) {
		title = "Compagnie de Croisière";
		subTitle = "Paquebot";
		jlist = listCroisiere;
		portTitle = "Port";
		voyageTitle = "Itinéraire";
//		System.out.println(listCroisiere.getDefaultListe());

		fabrique = FabriqueCroisiere.getInstance();
	}
	
	if(stateMachine.getVoyageTrainTrigger()==true) {
		title = "Compagnie de Train";
		subTitle = "Train";
		jlist = listTrain;
		portTitle = "Train";
		voyageTitle = "Trajet";
//		System.out.println(listTrain);

		fabrique = FabriqueTrain.getInstance();
	}	
}
	
}
