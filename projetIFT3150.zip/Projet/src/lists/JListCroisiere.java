package lists;

import javax.swing.DefaultListModel;

import fabrique.FabriqueCroisiere;

public class JListCroisiere extends JListGeneral {
	
	public JListCroisiere() {
		this.fabrique = FabriqueCroisiere.getInstance();
		this.defaultListe = new DefaultListModel<String>();
	}
	
}