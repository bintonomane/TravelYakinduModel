package gui;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class AdminFrameSectionPaquebot extends JFrame {

	private JPanel contentPane;
	private JButton btn;
	private JTextField txtNbCabinesI;
	private JTextField txtNbCabinesO;
	private JTextField txtNbCabinesS;
	private JTextField txtNbCabinesF;
	private JTextField txtNbCabinesD;

	public AdminFrameSectionPaquebot() {
		
		setTitle("Creation de sections de paquebot");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(400, 320);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panelNbCabinesI = new JPanel();
		contentPane.add(panelNbCabinesI);
		
		JLabel lblNbCabinesI = new JLabel("Nombre de cabines INTERIEURE");
		panelNbCabinesI.add(lblNbCabinesI);
		
		txtNbCabinesI = new JTextField();
		panelNbCabinesI.add(txtNbCabinesI);
		txtNbCabinesI.setColumns(10);
		
		JPanel panelNbCabinesO = new JPanel();
		contentPane.add(panelNbCabinesO);
		
		JLabel lblNbCabinesO = new JLabel("Nombre de cabines VUE OCEAN");
		panelNbCabinesO.add(lblNbCabinesO);
		
		txtNbCabinesO = new JTextField();
		txtNbCabinesO.setColumns(10);
		panelNbCabinesO.add(txtNbCabinesO);
		
		JPanel panelNbCabinesS = new JPanel();
		contentPane.add(panelNbCabinesS);
		
		JLabel lblNbCabinesS = new JLabel("Nombre de cabines SUITE");
		panelNbCabinesS.add(lblNbCabinesS);
		
		txtNbCabinesS = new JTextField();
		txtNbCabinesS.setColumns(10);
		panelNbCabinesS.add(txtNbCabinesS);
		
		JPanel panelNbCabinesF = new JPanel();
		contentPane.add(panelNbCabinesF);
		
		JLabel lblNbCabinesF = new JLabel("Nombre de cabines FAMILLE");
		panelNbCabinesF.add(lblNbCabinesF);
		
		txtNbCabinesF = new JTextField();
		txtNbCabinesF.setColumns(10);
		panelNbCabinesF.add(txtNbCabinesF);
		
		JPanel panelNbCabinesD = new JPanel();
		contentPane.add(panelNbCabinesD);
		
		JLabel lblNbCabinesD = new JLabel("Nombre de cabines DELUXE");
		panelNbCabinesD.add(lblNbCabinesD);
		
		txtNbCabinesD = new JTextField();
		txtNbCabinesD.setColumns(10);
		panelNbCabinesD.add(txtNbCabinesD);
		
		JPanel panelBoutton = new JPanel();
		contentPane.add(panelBoutton);
		
		btn = new JButton("Creer");
		btn.setBounds(95, 11, 59, 23);
		panelBoutton.add(btn);
	}
	
	public JButton getBtn() {
		return this.btn;
	}

	public int getNbCabinesI() {
		return Integer.parseInt(this.txtNbCabinesI.getText());
	}
	
	public int getNbCabinesO() {
		return Integer.parseInt(this.txtNbCabinesO.getText());
	}
	
	public int getNbCabinesS() {
		return Integer.parseInt(this.txtNbCabinesS.getText());
	}
	
	public int getNbCabinesF() {
		return Integer.parseInt(this.txtNbCabinesF.getText());
	}
	
	public int getNbCabinesD() {
		return Integer.parseInt(this.txtNbCabinesD.getText());
	}
	
	
}
