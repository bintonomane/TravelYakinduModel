package gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;

import fabrique.FabriqueEntiteVoyage;
import lists.JListGeneral;

public class AdminCompagniePanel extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2005542927834985739L;
	private JPanel panel;
	private JPanel panelAssign;
	

	private int x, y, w, h;
	
	private JButton btnAjouter;
	private JButton btnModifier;
	private JButton btnSupprimer;
	private JButton btnAnnuler;
	private JListGeneral list;
	private FabriqueEntiteVoyage fabriqueObjet;
	
	
	public  AdminCompagniePanel(String title, JListGeneral jlist, FabriqueEntiteVoyage fabrique) {
	
		setLayout(new BorderLayout(0, 0));
		
        setBounds(100, 100, 1000, 600);
                
		panelAssign = new JPanel();
		
		JPanel panelBoutons = new JPanel();
		panelBoutons.setLayout(new BoxLayout(panelBoutons, BoxLayout.Y_AXIS));
       
		panel = new JPanel();

		JPanel panelVoyageAvion = new JPanel();
		panelVoyageAvion.setLayout( new BorderLayout() );

        setPreferredSize(new Dimension(600, 400));
	   
		panel.setLayout(new BorderLayout(0, 0));
	    
	    Border border = BorderFactory.createTitledBorder(title);
		panel.setBorder(border);

		panel.add(jlist);


		btnAjouter = new JButton("Ajouter");
		btnModifier = new JButton("Modifier");
		btnSupprimer = new JButton("Supprimer");
		btnAnnuler = new JButton("Annuler");
		panelAssign.setLayout(new BorderLayout());

		addAButton(btnAjouter, panelBoutons);
        addAButton(btnModifier, panelBoutons);
        addAButton(btnSupprimer, panelBoutons);
        addAButton(btnAnnuler, panelBoutons);
        

		btnAnnuler.setEnabled(false);
		

		panelVoyageAvion.add(panel, BorderLayout.CENTER);	        		        		
		panelVoyageAvion.add(panelAssign, BorderLayout.PAGE_END);	        		        		
		panelVoyageAvion.add(panelBoutons, BorderLayout.EAST);
		add(panelVoyageAvion);
		setSize(800, 500); 
        setVisible(true);
    
	}
	
	public JListGeneral getList() {
		return this.list;
	}

	public FabriqueEntiteVoyage getFabriqueObjet() {
		return this.fabriqueObjet;
	}

	private static void addAButton(JButton button, Container container) {
        button.setAlignmentY(Component.CENTER_ALIGNMENT);
        container.add(button);
    }
	
	public JButton getBtnAjouter() {
		return btnAjouter;
	}
	
	public JButton getBtnModifier() {
		return btnModifier;
	}
	
	public JButton getBtnAnnuler() {
		return btnAnnuler;
	}

	
	
	public JButton getBtnSupprimer() {
	return btnSupprimer;
	}
	
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getW() {
		return w;
	}

	public int getH() {
		return h;
	}
}
