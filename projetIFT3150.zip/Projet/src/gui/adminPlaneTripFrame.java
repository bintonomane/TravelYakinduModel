package gui;

//public class adminPlaneTripFrame extends JFrame{
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

@SuppressWarnings("serial")
public class adminPlaneTripFrame extends JFrame {
	
	private int event = 0;
	
    private JTabbedPane jtp = new JTabbedPane(JTabbedPane.LEFT);
    
	private JPanel panelAerienne = new JPanel();
	private JPanel panelAvion = new JPanel();
	private JPanel panelAeroport = new JPanel();
	private JPanel panelVol = new JPanel();
	
	@SuppressWarnings("rawtypes")
	ListModel modelAerien, modelAvion, modelAeroport, modelVol;
	
	private Container panelBoutons;
	private JButton btnAjouter;
	
	private JButton btnModifier;
	private JButton btnSupprimer;
	private JButton btnAnnuler;


    @SuppressWarnings({ "rawtypes", "unchecked" })
	public  adminPlaneTripFrame() {
    	
    			super("Voyage par avion");
    			panelBoutons = new Container();
                setBounds(100, 100, 1000, 600);

                
    			JPanel panelVoyageAvion = new JPanel();
        		
                jtp.setPreferredSize(new Dimension(800, 400));
        		panelBoutons.setLayout(new BorderLayout(1, 4 ));
        		panelBoutons.setPreferredSize(new Dimension(300, 50));
        		
    			panelAerienne.setLayout(new BorderLayout(0, 0));
        		panelAeroport.setLayout(new BorderLayout(0, 0));
        		panelAvion.setLayout(new BorderLayout(0, 0));
        		panelVol.setLayout(new BorderLayout(0, 0));
        		
        		modelAerien = new DefaultListModel();
        		modelAvion = new DefaultListModel();
        		modelAeroport = new DefaultListModel();
        		modelVol = new DefaultListModel();
        		
        		panelAerienne.add(new JScrollPane(new JList(modelAerien)));
        		panelAeroport.add(new JScrollPane(new JList(modelAeroport)));
        		panelAvion.add(new JScrollPane(new JList(modelAvion)));
        		panelVol.add(new JScrollPane(new JList(modelVol)));


                jtp.add("CompagnieAerienne", panelAerienne);
                jtp.add("Aeroport", panelAeroport);
                jtp.add("Avion", panelAvion);
                jtp.add("Vol", panelVol);
                

        		btnAjouter = new JButton("Ajouter");
        		btnModifier = new JButton("Modifier");
        		btnSupprimer = new JButton("Supprimer");
        		btnAnnuler = new JButton("Annuler");
        		
        		panelBoutons.add(btnAjouter, BorderLayout.LINE_START);
        		panelBoutons.add(btnModifier, BorderLayout.CENTER);
        		panelBoutons.add(btnSupprimer, BorderLayout.LINE_END);
        		
        		panelVoyageAvion.setLayout(new BorderLayout(2, 0));
        		
    			panelVoyageAvion.add(jtp, BorderLayout.NORTH);	        		        		

        		panelVoyageAvion.add(panelBoutons, BorderLayout.LINE_END );
    			
        		add(panelVoyageAvion);
        		setSize(800, 500); 
                setVisible(true);
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
       
    }
    
    public JButton getBtnAjouter() {
		return btnAjouter;
	}

	public JButton getBtnModifier() {
		return btnModifier;
	}

	public JButton getBtnAnnuler() {
		return btnAnnuler;
	}
	
	public JButton getBtnSupprimer() {
		return btnSupprimer;
	}

	public JTabbedPane getJtp() {
		return jtp;
	}

	public int getEvent() {
		return event;
	}
	public void setEvent(int e) {
		 this.event = e;
	}
	public int getSelectedIndexPlaneFrame() {
		return this.jtp.getSelectedIndex();
	}
	

}