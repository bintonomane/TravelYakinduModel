package gui;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

@SuppressWarnings("serial")
public class AdminGUI extends JFrame {

    //create objects to add to JPanel
    private JButton btnVoyageAvion = new JButton("Voyage par avion");
    private JButton btnVoyageBateau = new JButton("Voyage par bateau");
    private JButton btnVoyageTrain = new JButton("Voyage par train");

    public AdminGUI() {
        super("Administrateur");
        setLayout(new GridLayout(3,0));  
        setBounds(450, 200, 400, 400);
        setPreferredSize(new Dimension(300, 200));
        add(btnVoyageAvion);
        add(btnVoyageBateau);
        add(btnVoyageTrain);
        setSize(300,200);
        setVisible(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
  }
    public JButton getBtnVoyageAvion() {
		return btnVoyageAvion;
	}
	public JButton getBtnVoyageBateau() {
		return btnVoyageBateau;
	}
	public JButton getBtnVoyageTrain() {
		return btnVoyageTrain;
	}
	
	
	
	

	
}