package gui;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


@SuppressWarnings("serial")
public class AdminFrameAssignerPrixCompagnie extends JFrame {

	private JPanel contentPane;
	private JTextField txtPleinTarif;
	private ButtonPanel btnAssigner;
	private JLabel lblCompagnieID;
	private JLabel lblNomCompagnie;

	public AdminFrameAssignerPrixCompagnie() {
		
		setTitle("Assignation de prix");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(300, 180);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panelCompagnieID = new JPanel();
		contentPane.add(panelCompagnieID);
		panelCompagnieID.setLayout(new GridLayout(0, 1, 0, 0));
		
		lblCompagnieID = new JLabel("Compagnie ID : ");
		panelCompagnieID.add(lblCompagnieID);
		lblCompagnieID.setHorizontalAlignment(SwingConstants.CENTER);
		
		lblNomCompagnie = new JLabel("Nom de la compagnie : ");
		panelCompagnieID.add(lblNomCompagnie);
		lblNomCompagnie.setHorizontalAlignment(SwingConstants.CENTER);
		
		JPanel panelNomCompagnie = new JPanel();
		contentPane.add(panelNomCompagnie);
		
		JLabel lblPleinTarif = new JLabel("Plein tarif");
		panelNomCompagnie.add(lblPleinTarif);
		
		txtPleinTarif = new JTextField();
		panelNomCompagnie.add(txtPleinTarif);
		txtPleinTarif.setColumns(10);
		
		JPanel panelBoutton = new JPanel();
		contentPane.add(panelBoutton);
		
		btnAssigner = new ButtonPanel();
		panelBoutton.add(btnAssigner.getBtnAssigner());
	}
	
	public JLabel getLblCompagnieID() {
		return this.lblCompagnieID;
	}
	
	public JLabel getLblNomCompagnie() {
		return this.lblNomCompagnie;
	}
	
	public Double getPleinTarif() {
		return Double.parseDouble(this.txtPleinTarif.getText());
	}
	
	public JButton getBtn() {
		return this.btnAssigner.getBtnAssigner();
	}
	
}
