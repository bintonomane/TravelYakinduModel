package gui;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class AdminFrameTransport extends JFrame {

	private JPanel contentPane;
	private JTextField txtTransportID;
	private JButton btn;
	private JComboBox<String> comboBoxCompagnie;

	public AdminFrameTransport() {
		
		setTitle("Creation de vehicule");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(300, 180);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panelTransportID = new JPanel();
		contentPane.add(panelTransportID);
		
		JLabel lblTransportID = new JLabel("Transport ID");
		panelTransportID.add(lblTransportID);
		lblTransportID.setHorizontalAlignment(SwingConstants.CENTER);
		
		txtTransportID = new JTextField();
		panelTransportID.add(txtTransportID);
		txtTransportID.setColumns(10);
		
		JPanel panelNomCompagnie = new JPanel();
		contentPane.add(panelNomCompagnie);
		
		JLabel lblCompagnie = new JLabel("Compagnie");
		panelNomCompagnie.add(lblCompagnie);
		lblCompagnie.setHorizontalAlignment(SwingConstants.CENTER);

		comboBoxCompagnie = new JComboBox<String>();
		panelNomCompagnie.add(comboBoxCompagnie);
		
		JPanel panelBoutton = new JPanel();
		contentPane.add(panelBoutton);
		
		btn = new JButton("Creer");
		btn.setBounds(95, 11, 59, 23);
		panelBoutton.add(btn);
		
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("je suis la la la ");

			//	e->raiseSectionCreated());
			}
		});
		
	}
	
	public JTextField getTxtTransportID() {
		return this.txtTransportID;
	}
	
	public JButton getBtn() {
		System.out.println("je suis dans le getbtn du frametransport");
		return this.btn;
	}
	
	public JComboBox<String> getComboBoxCompagnie() {
		return this.comboBoxCompagnie;
	}
	
}
