package methode;
import Entities.Compagnie;
import commande.Commande;
import fabrique.FabriqueEntiteVoyage;

public class SupprimerCompagnie implements Commande {
	
	FabriqueEntiteVoyage fabrique;
	String compagnieID;
	Compagnie compagnie;
	
	public SupprimerCompagnie(FabriqueEntiteVoyage fabrique, String compagnieID) {
		this.fabrique = fabrique;
		this.compagnieID = compagnieID;
		this.compagnie = fabrique.getListeCompagnies().get(compagnieID);
	}

	public SupprimerCompagnie() {
		// TODO Auto-generated constructor stub
	}


	public void execute() {
		fabrique.supprimerCompagnie(compagnieID);
	}

	public void unexecute() {
		Compagnie c = fabrique.creerCompagnie(compagnie.getCompagnieID(), compagnie.getNomCompagnie());
		if (compagnie.getPleinTarif() != -1.0) {
			fabrique.assignerPrix(c, compagnie.getPleinTarif());
		}
	}

	

}