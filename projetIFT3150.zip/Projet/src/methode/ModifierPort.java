package methode;

import Entities.Port;
import commande.Commande;
import fabrique.FabriqueEntiteVoyage;

public class ModifierPort implements Commande {
	
	FabriqueEntiteVoyage fabrique;
	String portID, nomPort, ville;
	String oldPortID, oldNomPort, oldVille;
	Port port;
	
	public ModifierPort(FabriqueEntiteVoyage fabrique, Port port, String portID, String nomPort, String ville) {
		this.fabrique = fabrique;
		this.port = port;
		this.portID = portID;
		this.nomPort = nomPort;
		this.ville = ville;
	}

	public void execute() {
		oldPortID = port.getPortID();
		oldNomPort = port.getNomPort();
		oldVille = port.getVille();
		
		fabrique.supprimerPort(oldPortID);
		fabrique.creerPort(portID, nomPort, ville);
	}

	public void unexecute() {
		fabrique.supprimerPort(portID);
		fabrique.creerPort(oldPortID, oldNomPort, oldVille);
	}


}