package methode;

import commande.Commande;
import fabrique.FabriqueEntiteVoyage;


public class CreerPort implements Commande  {
	
	FabriqueEntiteVoyage fabrique;
	String portID, nomPort, ville;
	
	public CreerPort(FabriqueEntiteVoyage fabrique, String portID, String nomPort, String ville) {
		this.fabrique = fabrique;
		this.portID = portID;
		this.nomPort = nomPort;
		this.ville = ville;
	}

	public void execute() {
		fabrique.creerPort(portID, nomPort, ville);
	}

	public void unexecute() {
		fabrique.supprimerPort(portID);
	}

	


}