package methode;

import Entities.Port;
import commande.Commande;
import fabrique.FabriqueEntiteVoyage;

public class SupprimerPort implements Commande {
	
	FabriqueEntiteVoyage fabrique;
	String portID;
	Port port;
	
	public SupprimerPort(FabriqueEntiteVoyage fabrique, String portID) {
		this.fabrique = fabrique;
		this.portID = portID;
		this.port = fabrique.getListePorts().get(portID);
	}

	public void execute() {
		fabrique.supprimerPort(portID);
	}

	public void unexecute() {
		fabrique.creerPort(port.getPortID(), port.getNomPort(), port.getVille());
	}

	

}