package methode;

import commande.Commande;
import fabrique.FabriqueEntiteVoyage;


public class CreerCompagnie implements Commande {
	
	FabriqueEntiteVoyage fabrique;
	String compagnieID, nomCompagnie;
	String type;
	double pleinTarif;
	
	public CreerCompagnie(FabriqueEntiteVoyage fabrique, String compagnieID, String nomCompagnie) {
		this.fabrique = fabrique;
		this.compagnieID = compagnieID;
		this.nomCompagnie = nomCompagnie;
	}

	public CreerCompagnie() {
		// TODO Auto-generated constructor stub
	}

	public void execute() {
		fabrique.creerCompagnie(compagnieID, nomCompagnie);
	}

	public void unexecute() {
		fabrique.supprimerCompagnie(compagnieID);
	}

	

}