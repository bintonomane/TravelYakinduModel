package methode;

import Entities.Compagnie;
import Entities.MoyenTransport;
import commande.Commande;
import fabrique.FabriqueEntiteVoyage;

public class ModifierMoyenTransport implements Commande {
	
	FabriqueEntiteVoyage fabrique;
	MoyenTransport transport;
	String transportID, oldTransportID;
	Compagnie compagnie, oldCompagnie;
	
	public ModifierMoyenTransport(FabriqueEntiteVoyage fabrique, MoyenTransport transport, String transportID, Compagnie compagnie) {
		this.fabrique = fabrique;
		this.transport = transport;
		this.transportID = transportID;
		this.compagnie = compagnie;
	}

	public void execute() {
		oldTransportID = transport.getTransportID();
		oldCompagnie = transport.getCompagnie();
		
		fabrique.supprimerTransport(oldTransportID);
		fabrique.creerTransport(transportID, compagnie);		
	}

	public void unexecute() {
		fabrique.supprimerTransport(transportID);
		fabrique.creerTransport(oldTransportID, oldCompagnie);
	}


}