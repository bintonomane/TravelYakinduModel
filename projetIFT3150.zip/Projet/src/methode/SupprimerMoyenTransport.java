package methode;
import Entities.MoyenTransport;
import commande.Commande;
import fabrique.FabriqueEntiteVoyage;

public class SupprimerMoyenTransport implements Commande {
	
	FabriqueEntiteVoyage fabrique;
	String transportID;
	MoyenTransport transport;
	
	public SupprimerMoyenTransport(FabriqueEntiteVoyage fabrique, String transportID) {
		this.fabrique = fabrique;
		this.transportID = transportID;
		this.transport = fabrique.getListeTransports().get(transportID);
	}

	public void execute() {
		fabrique.supprimerTransport(transportID);
	}

	public void unexecute() {
		fabrique.getListeTransports().put(transport.getTransportID(), transport);
	}

	

}