package methode;

import Entities.Compagnie;
import commande.Commande;
import fabrique.FabriqueEntiteVoyage;

public class AssignerPrix implements Commande {
	
	FabriqueEntiteVoyage fabrique;
	Compagnie compagnie;
	double prix, oldPrix;
	
	public AssignerPrix(FabriqueEntiteVoyage fabrique, Compagnie compagnie, double prix) {
		this.fabrique = fabrique;
		this.compagnie = compagnie;
		this.prix = prix;
	}

	public AssignerPrix() {
		// TODO Auto-generated constructor stub
	}

	public void execute() {
		oldPrix = compagnie.getPleinTarif();
		fabrique.assignerPrix(compagnie, prix);
	}

	public void unexecute() {
		fabrique.assignerPrix(compagnie, oldPrix);
	}

	
}