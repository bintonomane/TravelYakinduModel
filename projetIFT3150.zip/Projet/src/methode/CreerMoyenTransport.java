package methode;

import Entities.Compagnie;
import commande.Commande;
import fabrique.FabriqueEntiteVoyage;

public class CreerMoyenTransport implements Commande  {
	
	FabriqueEntiteVoyage fabrique;
	String transportID;
	Compagnie compagnie;
	
	public CreerMoyenTransport(FabriqueEntiteVoyage fabrique, String transportID, Compagnie compagnie) {
		this.fabrique = fabrique;
		this.transportID = transportID;
		this.compagnie = compagnie;
	}

	public void execute() {
		fabrique.creerTransport(transportID, compagnie);
	}

	public void unexecute() {
		fabrique.supprimerTransport(transportID);
	}

}