package observer;


public interface Observateur {
	
	public void update();
	
	
}