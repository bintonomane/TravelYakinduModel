package observer;

public interface Sujet {

	public void attacher(Observateur obs);
	
	public void detacher(Observateur obs);
	
	public void notifier();

}