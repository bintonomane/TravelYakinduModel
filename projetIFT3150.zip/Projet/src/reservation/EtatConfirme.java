package reservation;


public class EtatConfirme implements Etat {

	@Override
	public boolean isDispo() {
		return false;
	}

	@Override
	public boolean isConfirme() {
		return true;
	}

	@Override
	public void next(ObjetAReserver context) {
		System.out.println("Cet objet est confirme et ne peut donc pas avoir d'ete suivant.");
	}

	@Override
	public void prev(ObjetAReserver context) {
		context.setEtat(new EtatReserve());
	}

}