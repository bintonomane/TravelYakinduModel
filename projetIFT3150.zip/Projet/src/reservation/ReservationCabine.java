package reservation;

import client.Client;

public class ReservationCabine extends Reservation {

	public ReservationCabine(Client client, ObjetAReserver objet) {
		super(client, objet);
		this.conditionModif = 72;
	}

}