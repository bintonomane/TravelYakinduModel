package reservation;


public class EtatDisponible implements Etat {

	@Override
	public boolean isDispo() {
		return true;
	}

	@Override
	public boolean isConfirme() {
		return false;
	}

	@Override
	public void next(ObjetAReserver context) {
		context.setEtat(new EtatReserve());
	}

	@Override
	public void prev(ObjetAReserver context) {
		System.out.println("Cet objet est disponible et n'a donc pas d'etat precedent.");
	}

}