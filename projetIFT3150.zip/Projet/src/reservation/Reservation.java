package reservation;
import java.util.Date;

import client.Client;

public abstract class Reservation {

	Paiement paiement;
	ObjetAReserver objet;
	Client client;
	ObjetAReserver sujet;
	private String reservationID;
	private Date date;
	private static int lastID = 0;
	
	protected int conditionModif;
	
	public Reservation(Client client, ObjetAReserver objet) {
		lastID++;
		this.reservationID = client.getClientID() + objet.getObjetID() + lastID;
		this.date = new Date();
		this.objet = objet;
		this.paiement = null;
	}

	public ObjetAReserver getObjet() {
		return this.objet;
	}

	public boolean isConfirme() {
		return objet.getEtat().isConfirme();
	}

	public double calculerFraisAnnulation() {
		return 0.9*objet.getPrix();
	}

	// Remboursement si la valeur retourner est positive. Montant a paye sinon.
	public double calculerFraisModification(ObjetAReserver newObjet) {
		return 0.9*(objet.getPrix() - newObjet.getPrix());
	}

	public void modifierObjet(Date dateHeureDepart, char sectionType) {
		if (objet.getEtat().isConfirme()) {
			
		}
	}

	public Paiement getPaiement() {
		return this.paiement;
	}
	
	public void setPaiement(Paiement paiement) {
		this.paiement = paiement;
	}

	public int getConditionModif() {
		return this.conditionModif;
	}
	
	public String getReservationID() {
		return this.reservationID;
	}
	
	public Date getDate() {
		return this.date;
	}
	
	public Etat getEtat() {
		return objet.getEtat();
	}

}