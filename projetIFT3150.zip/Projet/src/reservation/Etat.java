package reservation;


public interface Etat {
	
	boolean isDispo();
	
	boolean isConfirme();

	void next(ObjetAReserver context);

	void prev(ObjetAReserver context);
	

}