package reservation;
import Entities.Section;

public abstract class ObjetAReserver {

	protected Section section;
	protected String objetID;
	private Etat etat;

	
	public String getObjetID() {
		return objetID;
	}

	public double getPrix() {
		return section.calculerPrix();
	}

	public Section getSection() {
		return this.section;
	}

	public Etat getEtat() {
		return etat;
	}
	
	public void setEtat(Etat etat) {
		this.etat = etat;
	}

}