package reservation;

import client.CarteCredit;

public class Paiement {

	Reservation reservation;
	CarteCredit carte;
	Annulation annulation;
	private double montant;
	private String etat;

	public Paiement(Reservation reservation, double montant, CarteCredit carte) {
		this.reservation = reservation;
		this.montant = montant;
		this.carte = carte;
		this.annulation = null;
	}

	public void transaction(float montant, CarteCredit carte) {
		
	}

	public void setEtat(String etat) {
		this.etat = etat;
	}

	public void setMontant(float montant) {
		this.montant = montant;
	}
	
	public void setAnnulation(Annulation annulation) {
		this.annulation = annulation;
	}

}