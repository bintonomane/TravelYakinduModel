package fabrique;
import java.util.Date;

import Entities.Aeroport;
import Entities.Avion;
import Entities.Compagnie;
import Entities.CompagnieAerienne;
import Entities.MoyenTransport;
import Entities.Port;
import Entities.Vol;
import Entities.Voyage;
import methode.AssignerPrix;
import methode.CreerCompagnie;
import methode.ModifierCompagnie;
import methode.SupprimerCompagnie;

public class FabriqueAerienne extends FabriqueEntiteVoyage {

	private static FabriqueAerienne instance;
	
	
	private FabriqueAerienne() {
		super();
	}

	public static FabriqueAerienne getInstance() {
		if (instance==null) {
			instance = new FabriqueAerienne();
		}
		return instance;
	}
	
	
	@Override
	public Compagnie creerCompagnie(String compagnieID, String nomCompagnie) {
		CompagnieAerienne compagnie = new CompagnieAerienne(compagnieID, nomCompagnie);
		listeCompagnies.put(compagnieID, compagnie);
		
		return compagnie;
	}
	
	@Override
	public MoyenTransport creerTransport(String transportID, Compagnie compagnie) {
		Avion avion = new Avion(transportID, compagnie);
		listeTransports.put(transportID, avion);
		
		return avion;
	}

	@Override
	public Voyage creerVoyage(Compagnie compagnie, MoyenTransport transport, String voyageID, Date dateHeureDepart, Date dateHeureArrivee, Port portDepart, Port portArrivee) {
		Vol voyage = new Vol(compagnie, transport, voyageID, dateHeureDepart, dateHeureArrivee, portDepart, portArrivee);
		listeVoyages.put(voyageID, voyage);
		
		return voyage;
	}
	
	@Override
	public Port creerPort(String portID, String nomPort, String ville) {
		Aeroport port = new Aeroport(portID, nomPort, ville);
		listePorts.put(portID, port);
		
		return port;
	}




}