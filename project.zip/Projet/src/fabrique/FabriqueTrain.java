package fabrique;
import java.util.Date;

import Entities.Compagnie;
import Entities.CompagnieTrain;
import Entities.Gare;
import Entities.MoyenTransport;
import Entities.Port;
import Entities.Train;
import Entities.Trajet;
import Entities.Voyage;
import methode.AssignerPrix;
import methode.CreerCompagnie;
import methode.ModifierCompagnie;
import methode.SupprimerCompagnie;

public class FabriqueTrain extends FabriqueEntiteVoyage {

	private static FabriqueTrain instance;

	private FabriqueTrain() {
		super();
		
	}

	public static FabriqueTrain getInstance() {
		if (instance==null) {
			instance = new FabriqueTrain();
		}
		return instance;
	}

	@Override
	public Compagnie creerCompagnie(String compagnieID, String nomCompagnie) {
		CompagnieTrain compagnie = new CompagnieTrain(compagnieID, nomCompagnie);
		listeCompagnies.put(compagnieID, compagnie);
		
		return compagnie;
	}
	
	@Override
	public MoyenTransport creerTransport(String transportID, Compagnie compagnie) {
		Train train = new Train(transportID, compagnie);
		listeTransports.put(transportID, train);
		
		return train;
	}

	@Override
	public Voyage creerVoyage(Compagnie compagnie, MoyenTransport transport, String voyageID, Date dateHeureDepart, Date dateHeureArrivee, Port portDepart, Port portArrivee) {
		Trajet voyage = new Trajet(compagnie, transport, voyageID, dateHeureDepart, dateHeureArrivee, portDepart, portArrivee);
		listeVoyages.put(voyageID, voyage);
		
		return voyage;
	}

	@Override
	public Port creerPort(String portID, String nomPort, String ville) {
		Gare port = new Gare(portID, nomPort, ville);
		listePorts.put(portID, port);
		
		return port;
	}

}