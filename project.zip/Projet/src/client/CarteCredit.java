package client;
import java.util.Date;

public class CarteCredit {

	private String numero;
	private Date dateExpiration;
	
	public CarteCredit(String numero, Date dateExpiration) {
		this.numero = numero;
		this.dateExpiration = dateExpiration;
	}

}