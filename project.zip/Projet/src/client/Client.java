package client;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import Entities.Cabine;
import reservations.Annulation;
import reservations.ObjetAReserver;
import reservations.Paiement;
import reservations.Reservation;
import reservations.ReservationCabine;
import reservations.ReservationSiege;

public class Client {

	private String clientID;
	private String nom;
	private String adresse;
	private String email;
	private String telephone;
	private Date dateNaissance;
	private String numeroPassport;
	private Date dateExpirationPassport;
	private Map<String, Reservation> monPanier;
	private static int lastID = 0;
	
	public Client() {
		lastID++;
		this.clientID = "CLIENT" + lastID;
		this.nom = null;
		this.adresse = null;
		this.email = null;
		this.telephone = null;
		this.dateNaissance = null;
		this.numeroPassport = null;
		this.dateExpirationPassport = null;
	}
	
	public void creerDossier(String clientID, String nom, String adresse, String email, String telephone, Date dateNaissance, String numeroPassport, Date dateExpirationPassport) {
		this.nom = nom;
		this.adresse = adresse;
		this.email = email;
		this.telephone = telephone;
		this.dateNaissance = dateNaissance;
		this.numeroPassport = numeroPassport;
		this.dateExpirationPassport = dateExpirationPassport;
		this.monPanier = new HashMap<String, Reservation>();
	}
	
	public void reserver(ObjetAReserver objet){
		
		if (objet.getEtat().isDispo()) {
			objet.getEtat().next(objet);
		}
		
		Reservation r;
		if (objet instanceof Cabine) {
			r = new ReservationCabine(this, objet);
		} else {
			r = new ReservationSiege(this, objet);
		}
		monPanier.put(r.getReservationID(), r);
	}
	
	public void confirmer(Reservation reservation, String numeroCarte, Date dateExpirationCarte) {
		ObjetAReserver objet = reservation.getObjet();
		objet.getEtat().next(objet);
		Paiement paiement = new Paiement(reservation, objet.getPrix(), new CarteCredit(numeroCarte, dateExpirationCarte));
		reservation.setPaiement(paiement);
	}
	
	public void annuler(Reservation reservation) {
		if(reservation.getObjet().getEtat().isConfirme()) {
			double frais = reservation.calculerFraisAnnulation();
			reservation.getPaiement().setAnnulation(new Annulation(frais));
		}
		monPanier.remove(reservation).getReservationID();
	}

	public String getClientID() {
		return clientID;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public Date getDateNaissance() {
		return dateNaissance;
	}

	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}

	public String getNumeroPassport() {
		return numeroPassport;
	}

	public void setNumeroPassport(String numeroPassport) {
		this.numeroPassport = numeroPassport;
	}

	public Date getDateExpirationPassport() {
		return dateExpirationPassport;
	}

	public void setDateExpirationPassport(Date dateExpirationPassport) {
		this.dateExpirationPassport = dateExpirationPassport;
	}

	public Map<String, Reservation> getMonPanier() {
		return monPanier;
	}

	public void setMonPanier(Map<String, Reservation> monPanier) {
		this.monPanier = monPanier;
	}

}