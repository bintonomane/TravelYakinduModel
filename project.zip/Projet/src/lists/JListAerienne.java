package lists;

import javax.swing.DefaultListModel;

import fabrique.FabriqueAerienne;

@SuppressWarnings("serial")
public class JListAerienne extends JListGeneral {
	
	public JListAerienne() {
		this.fabrique = FabriqueAerienne.getInstance();
		this.defaultListe = new DefaultListModel<String>();
	}
	
}