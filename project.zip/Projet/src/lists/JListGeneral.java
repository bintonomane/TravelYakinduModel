package lists;

import java.text.SimpleDateFormat;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;

import Entities.Compagnie;
import Entities.MoyenTransport;
import Entities.Port;
import Entities.Voyage;
import fabrique.FabriqueEntiteVoyage;
import visitor.Visiteur;
import Entities.Section;

public abstract class JListGeneral extends JList<String> implements Visiteur {
	
	protected DefaultListModel<String> defaultListe;
	protected FabriqueEntiteVoyage fabrique;
	
	protected String texte = "";
	protected SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd:HH.mm");
	public JPanel panel;
	
	
	public DefaultListModel<String> getDefaultListe() {
		return this.defaultListe;
	}
	
	public void setDefaultListe(DefaultListModel<String> defaultListe) {
		this.defaultListe = defaultListe;
		this.setModel(defaultListe);
	}

	@Override
	public void visiteCompagnie(Compagnie c) {
		texte = c.getCompagnieID() + " ; " + c.getNomCompagnie() + " ; " + c.getPleinTarif();
	}
	
	@Override
	public void visiteVoyage(Voyage v) {
		texte = "";
		texte += v.getPortDepart().getNomPort() + " - " + v.getPortArrivee().getNomPort();
		texte += " : [ " + v.getCompagnie().getNomCompagnie() + " ] " + v.getVoyageID();
		texte += " ( " + df.format(v.getDateHeureDepart()) + " - " + df.format(v.getDateHeureArrivee()) + " )";
		
		for (Section s: v.getTransport().getSections().values()) {
			s.accepte(this);
		}
	}

	@Override
	public void visiteMoyenTransport(MoyenTransport t) {
		texte = "";
		texte += t.getTransportID() + " ; ";
		texte += t.getCompagnie().getCompagnieID();
		
		if(!(t.getSections().values().isEmpty())) {
			for (Section s: t.getSections().values()) {
				s.accepte(this);
			}
		}
	}

	@Override
	public void visiteSection(Section s) {
		texte += " | " + s.getType() + s.getDispositionType();
		texte += " ( " + (s.getSize()-s.getNbObjetsDisponibles()) + "/" + s.getSize() + " ) ";
		texte += s.calculerPrix();
	}

	
	
	@Override
	public void visitePort(Port p) {
		texte = p.getPortID() + " ; " + p.getNomPort() + " ; " + p.getVille();
	}
	
	public String getTexte() {
		return this.texte;
	}

}
