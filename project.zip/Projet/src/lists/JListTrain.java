package lists;

import javax.swing.DefaultListModel;

import fabrique.FabriqueTrain;

public class JListTrain extends JListGeneral {
	
	public JListTrain() {
		this.fabrique = FabriqueTrain.getInstance();
		this.defaultListe = new DefaultListModel<String>();
	}
	
}