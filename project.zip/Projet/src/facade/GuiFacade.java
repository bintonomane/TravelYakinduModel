package facade;

import gui.AdminCompagniePanel;
import gui.AdminFrameAddButtonCreerSection;
import gui.AdminFrameAssignerPrix;
import gui.AdminFrameAssignerPrixCompagnie;
import gui.AdminFrameAddButtonAssignerPrix;
import gui.AdminFrameCompagnie;
import gui.AdminFramePort;
import gui.AdminFrameSectionAvion;
import gui.AdminFrameSectionPaquebot;
import gui.AdminFrameSectionTrain;
import gui.AdminFrameTransport;
import gui.AdminFrameVoyage;
import gui.AdminGUI;
import gui.AdminPanelTripSelected;
import gui.ButtonPanel;

public class GuiFacade {
	private AdminGUI adminGui;
	private AdminCompagniePanel adminCompagniePanel;
	private Object AdminFrameAddButtonAssignerPrix;
	private AdminFrameAddButtonCreerSection adminFrameAddButtonCreerSection;
	private AdminFrameAssignerPrix adminFrameAssignerPrix;
	private AdminFrameAssignerPrixCompagnie adminFrameAssignerPrixCompagnie;
	private AdminFrameCompagnie adminFrameCompagnie;
	private AdminFramePort adminFramePort;
	private AdminFrameSectionAvion adminFrameSectionAvion;
	private AdminFrameSectionPaquebot adminFrameSectionPaquebot;
	private AdminFrameSectionTrain adminFrameSectionTrain;
	private AdminFrameTransport adminFrameTransport;
	private AdminFrameVoyage adminFrameVoyage;
	private ButtonPanel buttonPanel;
	private AdminPanelTripSelected adminPanelTripSelected;
	private AdminFrameAddButtonAssignerPrix adminFrameAddButtonAssignerPrix;

	public GuiFacade() {
		adminGui = new AdminGUI();
		//adminFrameAddButtonAssignerPrix = AdminFrameAddButtonAssignerPrix();
		//adminCompagniePanel = new AdminCompagniePanel();
		adminFrameAddButtonCreerSection = new AdminFrameAddButtonCreerSection(adminCompagniePanel); 
		adminFrameAssignerPrix = new AdminFrameAssignerPrix();
		adminFrameAssignerPrixCompagnie = new AdminFrameAssignerPrixCompagnie();
		adminFrameCompagnie = new AdminFrameCompagnie();
		adminFramePort = new AdminFramePort();
		adminFrameSectionAvion = new AdminFrameSectionAvion();
		adminFrameSectionPaquebot = new AdminFrameSectionPaquebot();
		adminFrameSectionTrain = new AdminFrameSectionTrain();
		adminFrameTransport = new AdminFrameTransport();
		adminFrameVoyage = new AdminFrameVoyage();
		//adminPanelTripSelected = new AdminPanelTripSelected();
		buttonPanel = new ButtonPanel(); 
	}

	
}
