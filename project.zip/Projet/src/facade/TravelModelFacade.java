package facade;

public class TravelModelFacade {

}
