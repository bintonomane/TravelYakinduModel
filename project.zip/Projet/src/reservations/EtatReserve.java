package reservations;


public class EtatReserve implements Etat {

	@Override
	public boolean isDispo() {
		return false;
	}

	@Override
	public boolean isConfirme() {
		return false;
	}

	@Override
	public void next(ObjetAReserver context) {
		context.setEtat(new EtatConfirme());
	}

	@Override
	public void prev(ObjetAReserver context) {
		context.setEtat(new EtatDisponible());
	}

}