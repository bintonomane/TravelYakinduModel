package reservations;

import client.Client;

public class ReservationSiege extends Reservation {

	public ReservationSiege(Client client, ObjetAReserver objet) {
		super(client, objet);
		this.conditionModif = 24;
	}

}