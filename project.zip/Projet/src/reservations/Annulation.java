package reservations;
import java.util.Date;

public class Annulation {

	private Date date;
	private double montant;
	
	public Annulation(double montant) {
		this.montant = montant;
		this.date = new Date();
	}

}