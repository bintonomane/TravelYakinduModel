package commande;

public interface Commande {

	public void execute();

	public void unexecute();

}