package visitor;

import Entities.Compagnie;
import Entities.MoyenTransport;
import Entities.Port;
import Entities.Voyage;
import Entities.Section;

public interface Visiteur {

	void visiteVoyage(Voyage v);
	void visiteMoyenTransport(MoyenTransport t);
	void visiteSection(Section s);
	void visiteCompagnie(Compagnie c);
	void visitePort(Port p);

}