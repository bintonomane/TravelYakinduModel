package visitor;


public interface IVisitable {

	public void accepte(Visiteur v);

}