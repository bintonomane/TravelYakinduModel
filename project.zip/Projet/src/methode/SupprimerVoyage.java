package methode;

import Entities.Voyage;
import commande.Commande;
import fabrique.FabriqueEntiteVoyage;

public class SupprimerVoyage implements Commande {
	
	FabriqueEntiteVoyage fabrique;
	String voyageID;
	Voyage voyage;
	
	public SupprimerVoyage(FabriqueEntiteVoyage fabrique, String voyageID) {
		this.fabrique = fabrique;
		this.voyageID = voyageID;
		this.voyage = fabrique.getListeVoyages().get(voyageID);
	}

	public void execute() {
		fabrique.supprimerVoyage(voyageID);
	}

	public void unexecute() {
		fabrique.creerVoyage(voyage.getCompagnie(), voyage.getTransport(), voyage.getVoyageID(), voyage.getDateHeureDepart(), voyage.getDateHeureArrivee(), voyage.getPortDepart(), voyage.getPortArrivee());
	}

	
}