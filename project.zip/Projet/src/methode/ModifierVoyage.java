package methode;

import java.util.Date;

import Entities.Compagnie;
import Entities.MoyenTransport;
import Entities.Port;
import Entities.Voyage;
import commande.Commande;
import fabrique.FabriqueEntiteVoyage;

public class ModifierVoyage implements Commande {
	
	FabriqueEntiteVoyage fabrique;
	Compagnie compagnie, oldCompagnie;
	MoyenTransport transport, oldTransport;
	Voyage voyage;
	String voyageID = null, type = null;
	Date dateHeureDepart = null, dateHeureArrivee = null;
	Port portDepart, portArrive;
	String oldVoyageID = null;
	Date oldDateHeureDepart = null, oldDateHeureArrivee = null;
	Port oldPortDepart = null, oldPortArrive = null;
	
	public ModifierVoyage(FabriqueEntiteVoyage fabrique, Compagnie compagnie, MoyenTransport transport, Voyage voyage, String voyageID, Date dateHeureDepart, Date dateHeureArrivee, Port portDepart, Port portArrive) {
		this.fabrique = fabrique;
		this.compagnie = compagnie;
		this.transport = transport;
		this.voyage = voyage;
		this.voyageID = voyageID;
		this.dateHeureDepart = dateHeureDepart;
		this.dateHeureArrivee = dateHeureArrivee;
		this.portDepart = portDepart;
		this.portArrive = portArrive;
	}

	public void execute() {
		oldCompagnie = voyage.getCompagnie();
		oldTransport = voyage.getTransport();
		oldVoyageID = voyage.getVoyageID();
		oldDateHeureDepart = voyage.getDateHeureDepart();
		oldDateHeureArrivee = voyage.getDateHeureArrivee();
		oldPortDepart = voyage.getPortDepart();
		oldPortArrive = voyage.getPortArrivee();

		fabrique.supprimerVoyage(oldVoyageID);
		fabrique.creerVoyage(compagnie, transport, voyageID, dateHeureDepart, dateHeureArrivee, portDepart, portArrive);
	}

	public void unexecute() {
		fabrique.supprimerVoyage(voyageID);
		fabrique.creerVoyage(oldCompagnie, oldTransport, oldVoyageID, oldDateHeureDepart, oldDateHeureArrivee, oldPortDepart, oldPortArrive);
	}

	

}