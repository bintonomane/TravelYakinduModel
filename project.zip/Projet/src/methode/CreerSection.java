package methode;

import Entities.Avion;
import Entities.MoyenTransport;
import Entities.Paquebot;
import Entities.Train;
import commande.Commande;
import Entities.Disposition;

public class CreerSection implements Commande {
	
	MoyenTransport transport;
	int nbRang, nbRangE, nbRangF, nbCabinesI, nbCabinesO, nbCabinesS, nbCabinesF, nbCabinesD;
	Disposition disposition;
	char type;
	
	public CreerSection(MoyenTransport transport, char type, Disposition disposition, int nbRang) {
		this.transport = transport;
		this.type = type;
		this.disposition = disposition;
		this.nbRang = nbRang;
	}
	
	public CreerSection(MoyenTransport transport, int nbRangF, int nbRangE) {
		this.transport = transport;
		this.nbRangF = nbRangF;
		this.nbRangE = nbRangE;
	}
	
	public CreerSection(MoyenTransport transport, int nbCabinesI, int nbCabinesO, int nbCabinesS, int nbCabinesF, int nbCabinesD) {
		this.transport = transport;
		this.nbCabinesI = nbCabinesI;
		this.nbCabinesO = nbCabinesO;
		this.nbCabinesS = nbCabinesS;
		this.nbCabinesF = nbCabinesF;
		this.nbCabinesD = nbCabinesD;
	}

	public void execute() {
		if (transport instanceof Avion) {
			((Avion)transport).creerSection(type, disposition, nbRang);
		}
		if (transport instanceof Train) {
			((Train)transport).creerSection(nbRangF, nbRangE);
		}
		if (transport instanceof Paquebot) {
			((Paquebot)transport).creerSection(nbCabinesI, nbCabinesO, nbCabinesS, nbCabinesF, nbCabinesD);
		}
	}

	public void unexecute() {
		transport.supprimerSection(type);
	}

}