package methode;

import java.util.Date;

import Entities.Compagnie;
import Entities.MoyenTransport;
import Entities.Port;
import commande.Commande;
import fabrique.FabriqueEntiteVoyage;

public class CreerVoyage implements Commande{
	
	FabriqueEntiteVoyage fabrique;
	Compagnie compagnie;
	MoyenTransport transport;
	String voyageID;
	Date dateHeureDepart, dateHeureArrivee;
	Port portDepart, portArrivee;
	
	public CreerVoyage(FabriqueEntiteVoyage fabrique, Compagnie compagnie, MoyenTransport transport, String voyageID, Date dateHeureDepart, Date dateHeureArrivee, Port portDepart, Port portArrivee) {
		this.fabrique = fabrique;
		this.compagnie = compagnie;
		this.transport = transport;
		this.voyageID = voyageID;
		this.dateHeureDepart = dateHeureDepart;
		this.dateHeureArrivee = dateHeureArrivee;
		this.portDepart = portDepart;
		this.portArrivee = portArrivee;
	}

	public void execute() {
		fabrique.creerVoyage(compagnie, transport, voyageID, dateHeureDepart, dateHeureArrivee, portDepart, portArrivee);
	}

	public void unexecute() {
		fabrique.supprimerVoyage(voyageID);
	}


}