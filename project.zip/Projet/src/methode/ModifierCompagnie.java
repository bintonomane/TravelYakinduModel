package methode;

import Entities.Compagnie;
import commande.Commande;
import fabrique.FabriqueEntiteVoyage;

public class ModifierCompagnie implements Commande {
	
	FabriqueEntiteVoyage fabrique;
	Compagnie compagnie;
	String compagnieID = null, nomCompagnie = null;
	String oldCompagnieID = null, oldNomCompagnie = null;
	
	public ModifierCompagnie(FabriqueEntiteVoyage fabrique, Compagnie compagnie, String compagnieID, String nomCompagnie) {
		this.fabrique = fabrique;
		this.compagnie = compagnie;
		this.compagnieID = compagnieID;
		this.nomCompagnie = nomCompagnie;
	}

	public ModifierCompagnie() {
		// TODO Auto-generated constructor stub
	}

	public void execute() {
		oldCompagnieID = compagnie.getCompagnieID();
		oldNomCompagnie = compagnie.getNomCompagnie();
		
		fabrique.supprimerCompagnie(oldCompagnieID);
		fabrique.creerCompagnie(compagnieID, nomCompagnie);
	}

	public void unexecute() {
		fabrique.supprimerCompagnie(compagnieID);
		fabrique.creerCompagnie(oldCompagnieID, oldNomCompagnie);
	}


}