package gui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

import travelmodel.ITravelModelStatemachine.SCInterface;

@SuppressWarnings("serial")
public class AdminPanelTripSelected extends JFrame{

	    //create objects to add to JPanel
		private JButton btnCompagnie;  
	    private JButton btnVehicule; 
	    private JButton btnPort; 
	    private JButton btnVoyage;

	    public AdminPanelTripSelected(String title1, String title2, String title3, String title4) {
//	        super("");
	    	btnCompagnie = new JButton(title1);
	    	btnVehicule = new JButton(title2);
	    	btnPort = new JButton(title3);
	    	btnVoyage = new JButton(title4);
	        setLayout(new GridLayout(4,0));  
	        setBounds(450, 200, 400, 400);
	        setPreferredSize(new Dimension(300, 200));
	        add(btnCompagnie);
	        add(btnVehicule);
	        add(btnPort);
	        add(btnVoyage);
	        setSize(300,200);
	        setVisible(true);
	        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	  }
	
	    public JButton getBtnVoyage() {
			return btnVoyage;
		}
		public JButton getBtnCompagnie() {
			return btnCompagnie;
		}
		public JButton getBtnVehicule() {
			return btnVehicule;
		}
		public JButton getBtnPort() {
			return btnPort;
		}
		
		
}