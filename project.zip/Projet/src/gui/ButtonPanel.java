package gui;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class ButtonPanel extends JPanel{
 
	private JButton btnAssignerPrix;
	private JButton btnAssigner;
	private JButton btnUndo;
	JButton btnCreerSections;

	public ButtonPanel() {
	    btnAssignerPrix = new JButton("Assigner prix");
		setLayout(new GridLayout(1, 0, 0, 0));
		btnAssigner = new JButton("Assigner");
		btnAssigner.setBounds(95, 11, 59, 23);
		btnUndo = new JButton("Undo");
		btnUndo.setEnabled(false);
		btnCreerSections = new JButton("Creer sections");
	}
	
	public JButton getBtnAssignerPrix() {
		return btnAssignerPrix;
	}
	
	public JButton getBtnAssigner() {
		return btnAssigner;
	}
	
	public JButton getBtnUndo() {
		return btnUndo;
	}
	
	public JButton getBtnCreerSections() {
		return btnCreerSections;
	}
	
}
