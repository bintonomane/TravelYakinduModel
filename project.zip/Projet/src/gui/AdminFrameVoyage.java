package gui;
import java.awt.GridLayout;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import fabrique.FabriqueAerienne;
import fabrique.FabriqueCroisiere;
import fabrique.FabriqueEntiteVoyage;
import fabrique.FabriqueTrain;


public class AdminFrameVoyage extends JFrame {

	private JPanel contentPane;
	private JButton btn;
	private FabriqueEntiteVoyage fabrique;
	private FabriqueAerienne fabriqueAerienne = FabriqueAerienne.getInstance();
	private FabriqueTrain fabriqueTrain = FabriqueTrain.getInstance();
	private FabriqueCroisiere fabriqueCroisiere = FabriqueCroisiere.getInstance();
	private JTextField txtVoyageID;
	private JTextField txtDateHeureDepart;
	private JTextField txtDateHeureArrivee;
	private JComboBox<String> comboBoxTransport;
	private JComboBox<String> comboBoxPortDepart;
	private JComboBox<String> comboBoxPortArrive;
	
	private SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd:HH.mm");
	

	public AdminFrameVoyage() {
		
		setTitle("Creation de voyage");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(300, 275);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panelTransport = new JPanel();
		contentPane.add(panelTransport);
		
		JLabel lblTransport = new JLabel("Vehicule");
		lblTransport.setHorizontalAlignment(SwingConstants.CENTER);
		panelTransport.add(lblTransport);
		
		comboBoxTransport = new JComboBox<String>();
		panelTransport.add(comboBoxTransport);
		
		JPanel panelVoyageID = new JPanel();
		contentPane.add(panelVoyageID);
		
		JLabel lblVoyageID = new JLabel("Voyage ID");
		panelVoyageID.add(lblVoyageID);
		lblVoyageID.setHorizontalAlignment(SwingConstants.CENTER);
		
		txtVoyageID = new JTextField();
		panelVoyageID.add(txtVoyageID);
		txtVoyageID.setColumns(10);
		
		JPanel panelDateHeureDepart = new JPanel();
		contentPane.add(panelDateHeureDepart);
		
		JLabel lblDateHeureDepart = new JLabel("Date et heure de depart");
		lblDateHeureDepart.setHorizontalAlignment(SwingConstants.CENTER);
		panelDateHeureDepart.add(lblDateHeureDepart);
		
		txtDateHeureDepart = new JTextField();
		txtDateHeureDepart.setToolTipText("Format: yyyy.MM.dd:HH.mm");
		txtDateHeureDepart.setColumns(10);
		panelDateHeureDepart.add(txtDateHeureDepart);
		
		JPanel panelDateHeureArrivee = new JPanel();
		contentPane.add(panelDateHeureArrivee);
		
		JLabel lblDateHeureArrivee = new JLabel("Date et heure d'arrivee");
		lblDateHeureArrivee.setHorizontalAlignment(SwingConstants.CENTER);
		panelDateHeureArrivee.add(lblDateHeureArrivee);
		
		txtDateHeureArrivee = new JTextField();
		txtDateHeureArrivee.setToolTipText("Format: yyyy.MM.dd:HH.mm");
		txtDateHeureArrivee.setColumns(10);
		panelDateHeureArrivee.add(txtDateHeureArrivee);
		
		JPanel panelPortDepart = new JPanel();
		contentPane.add(panelPortDepart);
		
		JLabel lblPortDepart = new JLabel("Port de depart");
		lblPortDepart.setHorizontalAlignment(SwingConstants.CENTER);
		panelPortDepart.add(lblPortDepart);
		
		comboBoxPortDepart = new JComboBox<String>();
		panelPortDepart.add(comboBoxPortDepart);
		
		JPanel panelPortArrive = new JPanel();
		contentPane.add(panelPortArrive);
		
		JLabel lblPortArrive = new JLabel("Port d'arrive");
		lblPortArrive.setHorizontalAlignment(SwingConstants.CENTER);
		panelPortArrive.add(lblPortArrive);
		
		comboBoxPortArrive = new JComboBox<String>();
		panelPortArrive.add(comboBoxPortArrive);
		
		JPanel panelBoutton = new JPanel();
		contentPane.add(panelBoutton);
		
		btn = new JButton("Creer");
		btn.setBounds(95, 11, 59, 23);
		panelBoutton.add(btn);
	}
	
	public JTextField getTxtVoyageID() {
		return txtVoyageID;
	}

	public JTextField getTxtDateHeureDepart() {
		return txtDateHeureDepart;
	}

	public JTextField getTxtDateHeureArrivee() {
		return txtDateHeureArrivee;
	}

	public JComboBox<String> getComboBoxTransport() {
		return comboBoxTransport;
	}
	
	public JComboBox<String> getComboBoxPortDepart() {
		return comboBoxPortDepart;
	}
	
	public JComboBox<String> getComboBoxPortArrive() {
		return comboBoxPortArrive;
	}
	
	public Date getDateHeureDepart() {
		try {
			return df.parse(this.txtDateHeureDepart.getText());
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public Date getDateHeureArrivee() {
		try {
			return df.parse(this.txtDateHeureArrivee.getText());
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public JButton getBtn() {
		return this.btn;
	}
	
}
