package gui;

public class AdminFrameAssignerPrix {

}
