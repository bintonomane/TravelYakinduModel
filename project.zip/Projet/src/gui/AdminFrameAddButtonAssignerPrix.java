package gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


@SuppressWarnings("serial")
public class AdminFrameAddButtonAssignerPrix extends JFrame{
    private AdminCompagniePanel panelB;
    private ButtonPanel btnPanel;
	public AdminFrameAddButtonAssignerPrix(AdminCompagniePanel panel){
		
		panelB = panel;
		btnPanel = new ButtonPanel();
		panelB.add(btnPanel.getBtnAssignerPrix(), BorderLayout.SOUTH);		
	
	}
	
	public JButton getBtnAssigner() {
		return this.btnPanel.getBtnAssignerPrix();
	}
	
	public JButton getBtnAjouter() {
		return this.panelB.getBtnAjouter();
	}
	
	public JButton getBtnModifier() {
		return this.panelB.getBtnModifier();
	}
	
	public JButton getBtnSupprimer() {
		return this.panelB.getBtnSupprimer();
	}
	
	public JButton getBtnAnnuler() {
		return this.panelB.getBtnAnnuler();
	}
	
	public JButton getBtn() {
		return this.panelB.getBtnAjouter();
	}
}
