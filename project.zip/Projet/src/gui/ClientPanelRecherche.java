package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Entities.Port;
import Entities.Voyage;
import fabrique.FabriqueAerienne;
import fabrique.FabriqueCroisiere;
import fabrique.FabriqueEntiteVoyage;
import fabrique.FabriqueTrain;
import lists.JListAerienne;
import lists.JListCroisiere;
import lists.JListGeneral;
import lists.JListTrain;

public class ClientPanelRecherche extends JPanel {
	
	private JButton btnRechercher;
	private JListGeneral jlist;
	private FabriqueEntiteVoyage fabrique;
	private JComboBox<String> comboBoxPortDepart;
	private JComboBox<String> comboBoxPortArrive;
	private JComboBox<String> comboBoxDateDepart;
	private JComboBox<String> comboBoxSection;

	/**
	 * Create the panel.
	 */
	public ClientPanelRecherche(String typeVoyage) {
		
		setBounds(100, 100, 800, 600);
		setLayout(new BorderLayout(0, 0));
		
		JPanel panelChampsRecherche = new JPanel();
		add(panelChampsRecherche, BorderLayout.NORTH);
		panelChampsRecherche.setLayout(new GridLayout(0, 3, 0, 0));
		
		JPanel panelPortDepart = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panelPortDepart.getLayout();
		flowLayout.setAlignment(FlowLayout.RIGHT);
		panelChampsRecherche.add(panelPortDepart);
		
		JLabel lblPortDepart = new JLabel("Port de depart");
		panelPortDepart.add(lblPortDepart);
		
		comboBoxPortDepart = new JComboBox<String>();
		panelPortDepart.add(comboBoxPortDepart);
		
		JPanel panelPortArrive = new JPanel();
		FlowLayout flowLayout_1 = (FlowLayout) panelPortArrive.getLayout();
		flowLayout_1.setAlignment(FlowLayout.RIGHT);
		panelChampsRecherche.add(panelPortArrive);
		
		JLabel lblPortArrive = new JLabel("Port d'arrive");
		panelPortArrive.add(lblPortArrive);
		
		comboBoxPortArrive = new JComboBox<String>();
		panelPortArrive.add(comboBoxPortArrive);
		
		JPanel panelDateDepart = new JPanel();
		FlowLayout flowLayout_2 = (FlowLayout) panelDateDepart.getLayout();
		flowLayout_2.setAlignment(FlowLayout.RIGHT);
		panelChampsRecherche.add(panelDateDepart);
		
		JLabel lblDateDepart = new JLabel("Date de depart");
		panelDateDepart.add(lblDateDepart);
		
		comboBoxDateDepart = new JComboBox<String>();
		panelDateDepart.add(comboBoxDateDepart);
		
		JPanel panelSection = new JPanel();
		FlowLayout flowLayout_3 = (FlowLayout) panelSection.getLayout();
		flowLayout_3.setAlignment(FlowLayout.RIGHT);
		panelChampsRecherche.add(panelSection);
		
		JLabel lblSection = new JLabel("Classe");
		panelSection.add(lblSection);
		
		comboBoxSection = new JComboBox<String>();
		panelSection.add(comboBoxSection);
		
		JPanel emptyPanel = new JPanel();
		panelChampsRecherche.add(emptyPanel);
		
		JPanel panelBouton = new JPanel();
		FlowLayout flowLayout_4 = (FlowLayout) panelBouton.getLayout();
		flowLayout_4.setAlignment(FlowLayout.RIGHT);
		panelChampsRecherche.add(panelBouton);
		
		btnRechercher = new JButton("Rechercher");
		panelBouton.add(btnRechercher);
		
		
		switch(typeVoyage) {
		case "Aerienne":
			fabrique = FabriqueAerienne.getInstance();
			jlist = new JListAerienne();
			comboBoxSection.addItem("Premiere");
			comboBoxSection.addItem("Affaire");
			comboBoxSection.addItem("Economique Premium");
			comboBoxSection.addItem("Economique");
			break;
		case "Train":
			fabrique = FabriqueTrain.getInstance();
			jlist = new JListTrain();
			comboBoxSection.addItem("Premiere");
			comboBoxSection.addItem("Economique");
			break;
		case "Croisiere":
			fabrique = FabriqueCroisiere.getInstance();
			jlist = new JListCroisiere();
			comboBoxPortArrive.setEnabled(false);
			comboBoxSection.addItem("Interieure");
			comboBoxSection.addItem("Vue ocean");
			comboBoxSection.addItem("Suite");
			comboBoxSection.addItem("Famille");
			comboBoxSection.addItem("Famille Deluxe");
			break;
		}
		jlist.setVisible(true);
		add(jlist, BorderLayout.CENTER);
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.SOUTH);
		
		JButton btnReserver = new JButton("Reserver");
		btnReserver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int index = jlist.getSelectedIndex();
				if (index == -1) {
					JOptionPane.showMessageDialog(null, "Veuillez selectionner un voyage a reserver.");
				} else {
					
				}
			}
		});
		panel.add(btnReserver);
		
		for (Port p: fabrique.getListePorts().values()) {
			comboBoxPortDepart.addItem(p.getNomPort());
			comboBoxPortArrive.addItem(p.getNomPort());
		}
		
		final SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd:HH.mm");
		for (Voyage v: fabrique.getListeVoyages().values()) {
			comboBoxDateDepart.addItem(df.format(v.getDateHeureDepart()));
		}
		
		btnRechercher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nomPortDepart = (String)comboBoxPortDepart.getSelectedItem();
				String nomPortArrive = (String)comboBoxPortArrive.getSelectedItem();
				Port portDepart = null;
				Port portArrive = null;
				for (Port p: fabrique.getListePorts().values()) {
					if (p.getNomPort() == nomPortDepart) {
						portDepart = p;
					}
					if (p.getNomPort() == nomPortArrive) {
						portArrive = p;
					}
				}
				
				int indexDateDepart = comboBoxDateDepart.getSelectedIndex();
				Date dateDepart = ((Voyage)fabrique.getObjetParIndex(indexDateDepart, fabrique.getListeVoyages())).getDateHeureDepart();
				
				char sectionType = ' ';
				switch((String)comboBoxSection.getSelectedItem()) {
				case "Premiere":
					sectionType = 'F';
					break;
				case "Affaire":
					sectionType = 'A';
					break;
				case "Economique Premium":
					sectionType = 'P';
					break;
				case "Economique":
					sectionType = 'E';
					break;
				case "Interieure":
					sectionType = 'I';
					break;
				case "Vue ocean":
					sectionType = 'O';
					break;
				case "Suite":
					sectionType = 'S';
					break;
				case "Famille":
					sectionType = 'F';
					break;
				case "Famille Deluxe":
					sectionType = 'D';
					break;
				}
				ArrayList<Voyage> voyages = fabrique.rechercheVoyage(portDepart, portArrive, dateDepart, sectionType);
				DefaultListModel<String> defaultListe = new DefaultListModel<String>();
				defaultListe = fabrique.rechercheVoyageToString(voyages, sectionType);
				jlist.setDefaultListe(defaultListe);
			}
		});
	}

}
