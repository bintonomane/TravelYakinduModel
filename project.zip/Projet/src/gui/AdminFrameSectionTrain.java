package gui;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class AdminFrameSectionTrain extends JFrame {

	private JPanel contentPane;
	private JButton btn;
	private JTextField txtNbRangeesP;
	private JTextField txtNbRangeesE;

	public AdminFrameSectionTrain() {
		
		setTitle("Creation de sections de train");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(300, 180);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panelNbRangeesP = new JPanel();
		contentPane.add(panelNbRangeesP);
		
		JLabel lblNbRangeesP = new JLabel("Nombre de rangees PREMIERE");
		panelNbRangeesP.add(lblNbRangeesP);
		
		txtNbRangeesP = new JTextField();
		panelNbRangeesP.add(txtNbRangeesP);
		txtNbRangeesP.setColumns(10);
		
		JPanel panelNbRangeesE = new JPanel();
		contentPane.add(panelNbRangeesE);
		
		JLabel lblNbRangeesE = new JLabel("Nombre de rangees ECONOMIQUE");
		panelNbRangeesE.add(lblNbRangeesE);
		
		txtNbRangeesE = new JTextField();
		txtNbRangeesE.setColumns(10);
		panelNbRangeesE.add(txtNbRangeesE);
		
		JPanel panelBoutton = new JPanel();
		contentPane.add(panelBoutton);
		
		btn = new JButton("Creer");
		btn.setBounds(95, 11, 59, 23);
		panelBoutton.add(btn);
	}
	
	public JButton getBtn() {
		return this.btn;
	}

	public int getNbRangeesP() {
		return Integer.parseInt(this.txtNbRangeesP.getText());
	}
	
	public int getNbRangeesE() {
		return Integer.parseInt(this.txtNbRangeesE.getText());
	}
	
	
}
