package gui;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import lists.JListGeneral;


@SuppressWarnings("serial")
public class AdminFrameCompagnie extends JFrame {

	private JPanel contentPane;
	private JTextField txtCompagnieID;
	private JTextField txtNomCompagnie;
	private JButton btnCreer;
	
	public AdminFrameCompagnie() {
		setTitle("Creation de compagnie");
        setBounds(100, 100, 400, 280);
        setPreferredSize(new Dimension(300, 180));

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		this.setSize(300, 180);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panelCompagnieID = new JPanel();
		contentPane.add(panelCompagnieID);
		
		JLabel lblCompagnieID = new JLabel("Compagnie ID");
		
		panelCompagnieID.add(lblCompagnieID);
		lblCompagnieID.setHorizontalAlignment(SwingConstants.CENTER);
		
		txtCompagnieID = new JTextField();
		panelCompagnieID.add(txtCompagnieID);
		txtCompagnieID.setColumns(10);
		
		JPanel panelNomCompagnie = new JPanel();
		contentPane.add(panelNomCompagnie);
		
		JLabel lblNomCompagnie = new JLabel("Nom de la compagnie");

		panelNomCompagnie.add(lblNomCompagnie);
		lblNomCompagnie.setHorizontalAlignment(SwingConstants.CENTER);
		
		txtNomCompagnie = new JTextField();
		panelNomCompagnie.add(txtNomCompagnie);
		txtNomCompagnie.setColumns(10);
		
		JPanel panelBoutton = new JPanel();
		contentPane.add(panelBoutton);
		
		btnCreer = new JButton("Creer");
		btnCreer.setBounds(95, 11, 59, 23);
		panelBoutton.add(btnCreer);
		
		setVisible(true);
		
	}
	
	
	public JTextField getTxtCompagnieID() {
		return txtCompagnieID;
	}
	
	public JTextField getTxtNomCompagnie() {
		return txtNomCompagnie;
	}
	
	public JButton getBtnCreer() {		
		return btnCreer;
	}
	
}
