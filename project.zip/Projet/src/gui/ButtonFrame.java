package gui;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class ButtonFrame extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	private JButton admButton;
	private JButton cltButton ;
	
	private JPanel panel;

	public ButtonFrame() {
		createContents();
	}
	
	public void createContents() {
		panel = new JPanel();
		setBounds(100, 100, 450, 300);
		JPanel container = new JPanel(new BorderLayout());
		admButton = new JButton("Administrateur");
		cltButton = new JButton("Client");
		container.add(admButton, BorderLayout.WEST); 
		container.add(cltButton, BorderLayout.EAST); 
		panel.add(container, BorderLayout.PAGE_START);
		
		add(panel);
		setResizable(true);
		pack(); 
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 
		setVisible(true);
		
	}
	
	public JButton getAdmButton() {
		return admButton;
	}
	
	public JButton getCltButton() {
		return admButton;
	}
	 
}
