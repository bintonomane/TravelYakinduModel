package gui;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class AdminFrameAddButtonCreerSection extends JFrame{

	 private AdminCompagniePanel panelB;
	    private ButtonPanel btnPanel;
		public AdminFrameAddButtonCreerSection(AdminCompagniePanel panel){
			
			panelB = panel;
			btnPanel = new ButtonPanel();
			panelB.add(btnPanel.getBtnCreerSections(), BorderLayout.SOUTH);		
		
		}
		

		public JButton getBtnCreerSection() {
			return this.btnPanel.getBtnCreerSections();
		}
		
		public JButton getBtnAjouter() {
			return this.panelB.getBtnAjouter();
		}
		
		public JButton getBtnModifier() {
			return this.panelB.getBtnModifier();
		}
		
		public JButton getBtnSupprimer() {
			return this.panelB.getBtnSupprimer();
		}
		
		public JButton getBtnAnnuler() {
			return this.panelB.getBtnAnnuler();
		}
		
		public JButton getBtn() {
			return this.panelB.getBtnAjouter();
		}
	}
