package gui;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Entities.Confort;
import Entities.Disposition;
import Entities.Etroit;
import Entities.Large;
import Entities.Moyen;


public class AdminFrameSectionAvion extends JFrame {

	private JPanel contentPane;
	private JButton btn;
	private JComboBox<String> comboBoxType;
	private JComboBox<String> comboBoxDisposition;
	private JTextField txtNbRangees;

	public AdminFrameSectionAvion() {
		
		setTitle("Creation de sections d'avion");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(300, 180);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panelType = new JPanel();
		contentPane.add(panelType);
		
		JLabel lblType = new JLabel("Type");
		panelType.add(lblType);
		
		comboBoxType = new JComboBox<String>();
		comboBoxType.addItem("Premiere");
		comboBoxType.addItem("Affaire");
		comboBoxType.addItem("Economique Premium");
		comboBoxType.addItem("Economique");
		panelType.add(comboBoxType);
		
		JPanel panelDisposition = new JPanel();
		contentPane.add(panelDisposition);
		
		JLabel lblDisposition = new JLabel("Disposition");
		panelDisposition.add(lblDisposition);
		
		comboBoxDisposition = new JComboBox<String>();
		comboBoxDisposition.addItem("Etroit");
		comboBoxDisposition.addItem("Confort");
		comboBoxDisposition.addItem("Moyen");
		comboBoxDisposition.addItem("Large");
		panelDisposition.add(comboBoxDisposition);
		
		JPanel panelNbRangees = new JPanel();
		contentPane.add(panelNbRangees);
		
		JLabel lblNombreDeRangees = new JLabel("Nombre de rangees");
		panelNbRangees.add(lblNombreDeRangees);
		
		txtNbRangees = new JTextField();
		txtNbRangees.setText("0");
		panelNbRangees.add(txtNbRangees);
		txtNbRangees.setColumns(10);
		
		JPanel panelBoutton = new JPanel();
		contentPane.add(panelBoutton);
		
		btn = new JButton("Creer");
		btn.setBounds(95, 11, 59, 23);
		panelBoutton.add(btn);
	}
	
	public JButton getBtn() {
		return this.btn;
	}
	
	public Disposition getDisposition() {
		switch((String)comboBoxDisposition.getSelectedItem()) {
		case "Etroit":
			return new Etroit();
		case "Confort":
			return new Confort();
		case "Moyen":
			return new Moyen();
		case "Large":
			return new Large();
		default: throw new NullPointerException();
		}
	}
	
	public Character getSectionType() {
		switch((String)comboBoxType.getSelectedItem()) {
		case "Premiere":
			return 'F';
		case "Affaire":
			return 'A';
		case "Economique Premium":
			return 'P';
		case "Economique":
			return 'E';
		default: throw new NullPointerException();
		}
	}
	
	public int getNbRangees() {
		return Integer.parseInt(this.txtNbRangees.getText());
	}
	
	public void enleverSection(char c) {
		switch(c) {
		case 'F':
			comboBoxType.removeItem("Premiere");
			break;
		case 'A':
			comboBoxType.removeItem("Affaire");
			break;
		case 'P':
			comboBoxType.removeItem("Economique Premium");
			break;
		case 'E':
			comboBoxType.removeItem("Economique");
			break;
		}
	}
	
}
