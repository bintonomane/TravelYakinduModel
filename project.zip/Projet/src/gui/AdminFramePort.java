package gui;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class AdminFramePort extends JFrame {

	private JPanel contentPane;
	private JTextField txtPortID;
	private JTextField txtNomPort;
	private JTextField txtVille;
	private JButton btn;

	public AdminFramePort() {
		
		setTitle("Creation de port");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(300, 220);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panelPortID = new JPanel();
		contentPane.add(panelPortID);
		
		JLabel lblPortID = new JLabel("Port ID");
		panelPortID.add(lblPortID);
		lblPortID.setHorizontalAlignment(SwingConstants.CENTER);
		
		txtPortID = new JTextField();
		panelPortID.add(txtPortID);
		txtPortID.setColumns(10);
		
		JPanel panelNomPort = new JPanel();
		contentPane.add(panelNomPort);
		
		JLabel lblNomPort = new JLabel("Nom du port");
		panelNomPort.add(lblNomPort);
		lblNomPort.setHorizontalAlignment(SwingConstants.CENTER);
		
		txtNomPort = new JTextField();
		panelNomPort.add(txtNomPort);
		txtNomPort.setColumns(10);
		
		JPanel panelVille = new JPanel();
		contentPane.add(panelVille);
		
		JLabel lblVille = new JLabel("Ville");
		panelVille.add(lblVille);
		
		txtVille = new JTextField();
		panelVille.add(txtVille);
		txtVille.setColumns(10);
		
		JPanel panelBoutton = new JPanel();
		contentPane.add(panelBoutton);
		
		btn = new JButton("Creer");
		btn.setBounds(95, 11, 59, 23);
		panelBoutton.add(btn);
	}
	
	public JTextField getTxtPortID() {
		return this.txtPortID;
	}
	
	public JTextField getTxtNomPort() {
		return this.txtNomPort;
	}
	
	public JTextField getTxtVille() {
		return this.txtVille;
	}
	
	public JButton getBtn() {
		return this.btn;
	}
	
}
