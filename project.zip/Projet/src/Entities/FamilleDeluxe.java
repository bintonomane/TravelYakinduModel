package Entities;



public class FamilleDeluxe extends SectionAvecCabine {
	
	public FamilleDeluxe(Disposition disposition, int n) {
		super(disposition, n);
		this.ratio = 1.0;
		this.type = 'D';
		this.CAPACITE = 6;
	}

}