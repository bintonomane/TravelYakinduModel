package Entities;
import visitor.IVisitable;
import visitor.Visiteur;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import reservations.ObjetAReserver;
import Entities.Section;

public class Voyage  implements IVisitable, EntityTypes {

	private Port portDepart;
	private Port portArrivee;
	private Compagnie compagnie;
	private MoyenTransport transport;
	private String voyageID;
	private Date dateHeureDepart;
	private Date dateHeureArrivee;
	private String duree;
	private int nbSiegeDispo;
	
	public Voyage(Compagnie compagnie, MoyenTransport transport, String voyageID, Date dateHeureDepart, Date dateHeureArrivee, Port portDepart, Port portArrivee) {
		this.compagnie = compagnie;
		this.transport = transport;
		this.voyageID = voyageID;
		this.dateHeureDepart = dateHeureDepart;
		this.dateHeureArrivee = dateHeureArrivee;
		this.portDepart = portDepart;
		this.portArrivee = portArrivee;
		
		this.duree = getDuree();
		this.nbSiegeDispo = this.getObjetsDisponibles().size();
	}

	public Port getPortDepart() {
		return portDepart;
	}

	public void setPortDepart(Port portDepart) {
		this.portDepart = portDepart;
	}

	public Port getPortArrivee() {
		return portArrivee;
	}

	public void setPortArrivee(Port portArrivee) {
		this.portArrivee = portArrivee;
	}

	public String getVoyageID() {
		return voyageID;
	}

	public void setVoyageID(String voyageID) {
		this.voyageID = voyageID;
	}

	public Date getDateHeureDepart() {
		return dateHeureDepart;
	}

	public void setDateHeureDepart(Date dateHeureDepart) {
		this.dateHeureDepart = dateHeureDepart;
		duree = getDuree();
	}

	public Date getDateHeureArrivee() {
		return dateHeureArrivee;
	}

	public void setDateHeureArrivee(Date dateHeureArrivee) {
		this.dateHeureArrivee = dateHeureArrivee;
		duree = getDuree();
	}

	// Duree du voyage en heure
	public String getDuree() {
		long millisecondsInMinutes = 60 * 1000;
		long minutesInHours = 60;
		
		long diff = dateHeureArrivee.getTime() - dateHeureDepart.getTime();
		diff/=millisecondsInMinutes;
		int minutes = (int) diff % 60;
		diff/=minutesInHours;
		int hours = (int) diff;
		duree = (hours + ":" + minutes);

		return duree;
	}

	public double getPleinTarif() {
		return compagnie.getPleinTarif();
	}

	public boolean isDispo() {
		return (nbSiegeDispo > 0);
	}

	public Compagnie getCompagnie() {
		return this.compagnie;
	}
	
	public MoyenTransport getTransport() {
		return transport;
	}
	
	public Map<Character, ArrayList<ObjetAReserver>> getObjets() {
		Map<Character, ArrayList<ObjetAReserver>> map = new HashMap<Character, ArrayList<ObjetAReserver>>();
		for (Section s: transport.getSections().values()) {
			map.put(s.getType(), (ArrayList<ObjetAReserver>)s.getObjets().values());
		}
		return map;
	}
	
	public Map<Character, ArrayList<ObjetAReserver>> getObjetsDisponibles() {
		Map<Character, ArrayList<ObjetAReserver>> map = new HashMap<Character, ArrayList<ObjetAReserver>>();
		for (Section s: transport.getSections().values()) {
			map.put(s.getType(), s.getObjetsDisponibles());
		}
		return map;
	}
	
	/**
	 * 
	 * @param v
	 */
	public void accepte(Visiteur v) {
		v.visiteVoyage(this);
	}


}