package Entities;
import java.util.Date;

public class Itineraire extends Voyage {

	public Itineraire(Compagnie compagnie, MoyenTransport transport, String voyageID, Date dateHeureDepart, Date dateHeureArrivee, Port portDepart, Port portArrivee) {
		super(compagnie, transport, voyageID, dateHeureDepart, dateHeureArrivee, portDepart, portArrivee);
	}


}