package Entities;

import java.util.Map;

import Entities.Section;
import visitor.IVisitable;
import visitor.Visiteur;

public abstract class MoyenTransport implements IVisitable, EntityTypes {

	protected String transportID;
	protected Compagnie compagnie;
	
	public void setTransportID(String transportID) {
		this.transportID = transportID;
	}
	
	public String getTransportID() {
		return transportID;
	}
	
	public void setCompagnie(Compagnie compagnie) {
		this.compagnie = compagnie;
	}
	
	public Compagnie getCompagnie() {
		return compagnie;
	}

	public abstract void supprimerSection(char type);
	
	public abstract Map<Character, Section> getSections();
	
	public void accepte(Visiteur v) {
		v.visiteMoyenTransport(this);
	}
	

}