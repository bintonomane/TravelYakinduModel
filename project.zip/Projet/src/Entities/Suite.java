package Entities;



public class Suite extends SectionAvecCabine {
	
	public Suite(Disposition disposition, int n) {
		super(disposition, n);
		this.ratio = 0.9;
		this.type = 'S';
		this.CAPACITE = 5;
	}

}