package Entities;


public class Gare extends Port {

	public Gare(String portID, String nomPort, String ville) {
		super(portID, nomPort, ville);
	}
}