package Entities;


public class PortCroisiere extends Port {

	public PortCroisiere(String portID, String nomPort, String ville) {
		super(portID, nomPort, ville);
	}
}