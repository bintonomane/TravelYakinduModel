package Entities;
import java.util.HashMap;
import java.util.Map;

import Entities.Affaire;
import Entities.Disposition;
import Entities.Economique;
import Entities.EconomiquePremium;
import Entities.Premiere;
import Entities.Section;
import Entities.SectionAvecSiege;

public class Avion extends MoyenTransport {
	
	private Map<Character, SectionAvecSiege> sections = new HashMap<Character, SectionAvecSiege>();

	public Avion(String transportID, Compagnie compagnie) {
		this.transportID = transportID;
		this.compagnie = compagnie;
	}

	public void creerSection(char type, Disposition disposition, int nbRangee) {
		SectionAvecSiege section = null;
		double pleinTarif = compagnie.getPleinTarif();
		if ((getTotalNbRangee() + nbRangee) > 100) {
			System.out.println("La limite de 100 rangees est atteinte pour cet avion. La section ne peut donc pas etre cree.");
		} else {
			switch (type) {
			case 'F':
				section = new Premiere(disposition, nbRangee);
				sections.put(section.getType(), section);
				break;
			case 'A':
				section = new Affaire(disposition, nbRangee);
				sections.put(section.getType(), section);
				break;
			case 'P':
				section = new EconomiquePremium(disposition, nbRangee);
				sections.put(section.getType(), section);
				break;
			case 'E':
				section = new Economique(disposition, nbRangee);
				sections.put(section.getType(), section);
				break;
			default:
				throw new UnsupportedOperationException();
			}
			section.setPleinTarif(pleinTarif);
		}	
		
	}

	public Map<Character, Section> getSections() {
		Map<Character, Section> map = new HashMap<Character, Section>();
		for (SectionAvecSiege s: sections.values()) {
			map.put(s.getType(), (Section) s);
		}
		return map;
	}
	
	public int getTotalNbRangee() {
		int total = 0;
		for (SectionAvecSiege s: sections.values()) {
			total = total + s.getNbRang();
		}
		return total;
	}

	@Override
	public void supprimerSection(char type) {
		sections.remove(type);
	}



}