package Entities;
import java.util.Date;

public class Trajet extends Voyage {

	public Trajet(Compagnie compagnie, MoyenTransport transport, String voyageID, Date dateHeureDepart, Date dateHeureArrivee, Port portDepart, Port portArrivee) {
		super(compagnie, transport, voyageID, dateHeureDepart, dateHeureArrivee, portDepart, portArrivee);
	}

}