package Entities;

import reservations.EtatDisponible;
import reservations.ObjetAReserver;

public class Cabine extends ObjetAReserver {

	private static int lastID = 0;
	private int capacite;
	
	public Cabine(int capacite) {
		this.capacite = capacite;
		this.setEtat(new EtatDisponible());
		lastID++;
		objetID = "CAB"+lastID;
	}
	
	public int getCapacite() {
		return capacite;
	}

}