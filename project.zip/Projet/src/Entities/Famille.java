package Entities;



public class Famille extends SectionAvecCabine {
	
	public Famille(Disposition disposition, int n) {
		super(disposition, n);
		this.ratio = 0.9;
		this.type = 'F';
		this.CAPACITE = 6;
	}

}