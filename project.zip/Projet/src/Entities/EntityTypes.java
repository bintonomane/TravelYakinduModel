package Entities;

public interface EntityTypes {
	
}
