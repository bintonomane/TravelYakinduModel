package Entities;

import Entities.Cabine;

public abstract class SectionAvecCabine extends Section {
	
	protected int nbCabinesDefault = 5;
	protected int CAPACITE;
	protected int nbCabines;
	
	public SectionAvecCabine(Disposition disposition, int nbCabines) {
		super(disposition, nbCabines);
		this.disposition = null;
		this.nbCabines = nbCabines;
		creerObjets(null, nbCabines);
	}
	
	public char getDispositionType() {
		return ' ';
	}
	
	@Override
	public void creerObjets(Disposition disposition, int nbCabines) {
		for (int i=0; i<nbCabines; i++) {
			Cabine cabine = new Cabine(CAPACITE);
			objets.put(cabine.getObjetID(), cabine);
		}
	}
	
}