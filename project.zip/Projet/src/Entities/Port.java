package Entities;

import visitor.IVisitable;
import visitor.Visiteur;

public class Port  implements IVisitable, EntityTypes {

	private String portID, nomPort, ville;
	
	public Port(String portID, String nomPort, String ville) {
		this.portID = portID;
		this.nomPort = nomPort;
		this.ville = ville;
	}

	public String getPortID() {
		return portID;
	}

	public void setPortID(String portID) {
		this.portID = portID;
	}

	public String getNomPort() {
		return nomPort;
	}

	public void setNomPort(String nomPort) {
		this.nomPort = nomPort;
	}

	public String getVille() {
		return this.ville;
	}
	
	public void setVille(String newVille) {
		this.ville = newVille;
	}

	@Override
	public void accepte(Visiteur v) {
		v.visitePort(this);
	}

}