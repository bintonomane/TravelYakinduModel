package Entities;


public class Economique extends SectionAvecSiege {

	public Economique(Disposition disposition, int nbRang) {
		super(disposition, nbRang);
		this.ratio = 0.5;
		this.type = 'E';
	}
	
	@Override
	public double calculerPrix() {
		return ratio*pleinTarif;
	}

	

}