package Entities;
import visitor.IVisitable;
import visitor.Visiteur;

import java.util.ArrayList;

public abstract class Compagnie implements IVisitable, EntityTypes {

	private String compagnieID, nomCompagnie;
	private double pleinTarif;
	protected String type;
	private ArrayList<Voyage> voyages;
	
	public Compagnie(String compagnieID, String nomCompagnie) {
		this.compagnieID = compagnieID;
		this.nomCompagnie = nomCompagnie;
		this.pleinTarif = -1;
		voyages = new ArrayList<Voyage>();
		
	}

	public ArrayList<Voyage> getListeVoyages() {
		return voyages;
	}

	 
	public double getPleinTarif() {
		return this.pleinTarif;
	}
	
	public void setPleinTarif(double prix) {
		this.pleinTarif = prix;
	}

	public String getCompagnieID() {
		return this.compagnieID;
	}
	
	public void setCompagnieID(String compagnieID) {
		this.compagnieID = compagnieID;
	}
	
	public String getNomCompagnie() {
		return this.nomCompagnie;
	}
	
	public void setNomCompagnie(String nomCompagnie) {
		this.nomCompagnie = nomCompagnie;
	}
	
	public String getType() {
		return this.type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public void ajouterVoyage(Voyage v) {
		voyages.add(v);
	}
	
	@Override
	public void accepte(Visiteur v) {
		v.visiteCompagnie(this);
	}


}