package Entities;


public class CompagnieCroisiere extends Compagnie {

	public CompagnieCroisiere(String compagnieID, String nomCompagnie) {
		super(compagnieID, nomCompagnie);
	}

}