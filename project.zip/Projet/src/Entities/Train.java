package Entities;
import java.util.HashMap;
import java.util.Map;

import Entities.Disposition;
import Entities.Economique;
import Entities.Etroit;
import Entities.Premiere;
import Entities.Section;
import Entities.SectionAvecSiege;

public class Train extends MoyenTransport {
	
	private Map<Character, Section> sections = new HashMap<Character, Section>();

	public Train(String transportID, Compagnie compagnie) {
		this.transportID = transportID;
		this.compagnie = compagnie;
	}
	
	public void creerSection(int nbRangF, int nbRangE) {
		Disposition disposition = new Etroit();
		double pleinTarif = compagnie.getPleinTarif();
		
		SectionAvecSiege sectionF = new Premiere(disposition, nbRangF);
		sectionF.setPleinTarif(pleinTarif);
		sections.put(sectionF.getType(), sectionF);
		
		SectionAvecSiege sectionE = new Economique(disposition, nbRangE);
		sectionE.setPleinTarif(pleinTarif);
		sections.put(sectionE.getType(), sectionE);
	}

	public Map<Character, Section> getSections() {
		return sections;
	}

	@Override
	public void supprimerSection(char type) {
		sections.remove(type);
	}

}