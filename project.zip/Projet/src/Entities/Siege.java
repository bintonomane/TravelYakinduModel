package Entities;

import reservations.EtatDisponible;
import reservations.ObjetAReserver;

public class Siege extends ObjetAReserver {

	private int rangee;
	private char colonne;
	private Option option;
	private static int lastID = 0;
	
	public Siege(int rangee, char colonne, Option option) {
		if(colonne < 'A' || colonne > 'J'){
			 throw new IllegalArgumentException("La colonne doit se trouver entre A et J");			
		}
		if(rangee < 1 || rangee > 100){
			 throw new IllegalArgumentException("La rangee doit se trouver entre 1 et 100");			
		}
		
		this.rangee = rangee;
		this.colonne = colonne;
		this.option = option;
		this.setEtat(new EtatDisponible());
		lastID++;
		objetID = "SIE"+lastID;
	}
	
	public int getRangee() {
		return rangee;
	}
	
	public char getColonne() {
		return colonne;
	}
	
	public Option getOption() {
		return option;
	}

}