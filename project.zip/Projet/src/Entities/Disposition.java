package Entities;

public abstract class Disposition {
	
	protected char type;
	protected int nbCol;
	
	public int getNbColonnes() {
		return this.nbCol;
	}
	
	public char getType() {
		return this.type;
	}

}