package Entities;
import java.util.HashMap;
import java.util.Map;

import Entities.Disposition;
import Entities.Famille;
import Entities.FamilleDeluxe;
import Entities.Interieure;
import Entities.Section;
import Entities.SectionAvecCabine;
import Entities.Suite;
import Entities.VueSurOcean;

public class Paquebot extends MoyenTransport {
	
	private Map<Character, Section> sections = new HashMap<Character, Section>();

	public Paquebot(String transportID, Compagnie compagnie) {
		this.transportID = transportID;
		this.compagnie = compagnie;
	}

	public void creerSection(int nbCabinesI, int nbCabinesO, int nbCabinesS, int nbCabinesF, int nbCabinesD) {
		double pleinTarif = compagnie.getPleinTarif();
		Disposition disposition = null;
		
		SectionAvecCabine sectionI = new Interieure(disposition, nbCabinesI);
		sectionI.setPleinTarif(pleinTarif);
		sections.put(sectionI.getType(), sectionI);
		
		SectionAvecCabine sectionO = new VueSurOcean(disposition, nbCabinesO);
		sectionO.setPleinTarif(pleinTarif);
		sections.put(sectionO.getType(), sectionO);
		
		SectionAvecCabine sectionS = new Suite(disposition, nbCabinesS);
		sectionS.setPleinTarif(pleinTarif);
		sections.put(sectionS.getType(), sectionS);
		
		SectionAvecCabine sectionF = new Famille(disposition, nbCabinesF);
		sectionF.setPleinTarif(pleinTarif);
		sections.put(sectionF.getType(), sectionF);
		
		SectionAvecCabine sectionD = new FamilleDeluxe(disposition, nbCabinesD);
		sectionD.setPleinTarif(pleinTarif);
		sections.put(sectionD.getType(), sectionD);
	}

	public Map<Character, Section> getSections() {
		return sections;
	}

	@Override
	public void supprimerSection(char type) {
		sections.remove(type);
	}

}