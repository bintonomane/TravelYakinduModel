package Controller;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Observer;

import javax.swing.JOptionPane;

import Entities.Avion;
import Entities.Compagnie;
import Entities.Etroit;
import Entities.MoyenTransport;
import Entities.Paquebot;
import Entities.Port;
import Entities.Section;
import Entities.Train;
import Entities.Voyage;
import commande.Commande;
import fabrique.FabriqueAerienne;
import fabrique.FabriqueCroisiere;
import fabrique.FabriqueEntiteVoyage;
import fabrique.FabriqueTrain;
import gui.AdminCompagniePanel;
import gui.AdminFrameAddButtonAssignerPrix;
import gui.AdminFrameAddButtonCreerSection;
import gui.AdminFrameAssignerPrixCompagnie;
import gui.AdminFrameCompagnie;
import gui.AdminFramePort;
import gui.AdminFrameSectionAvion;
import gui.AdminFrameTransport;
import gui.AdminGUI;
import gui.AdminPanelTripSelected;
import invocator.Invocateur;
import lists.JListAerienne;
import lists.JListCroisiere;
import lists.JListGeneral;
import lists.JListTrain;
import methode.AssignerPrix;
import methode.CreerCompagnie;
import methode.CreerMoyenTransport;
import methode.CreerPort;
import methode.ModifierCompagnie;
import methode.ModifierMoyenTransport;
import methode.ModifierPort;
import methode.SupprimerCompagnie;
import methode.SupprimerMoyenTransport;
import methode.SupprimerPort;
import observer.Observateur;
import travelmodel.ITravelModelStatemachine.SCInterfaceOperationCallback;
import travelmodel.TravelModelStatemachine;
import travelmodel.TravelModelStatemachine.State;


public class Controller implements Observateur{
	private AdminPanelTripSelected trainVoyPanel;
	FabriqueEntiteVoyage fabrique;
	JListGeneral jlist;
	private FabriqueEntiteVoyage fabriqueAerienne;
	private FabriqueEntiteVoyage fabriqueTrain;
	private FabriqueEntiteVoyage fabriqueCroisiere;
	JListTrain listTrain = new JListTrain();
	JListCroisiere listCroisiere = new JListCroisiere();
	JListAerienne listAerienne = new JListAerienne();
	
	String title;
	String subTitle;
	private AdminPanelTripSelected paquebotVoyPanel;
	AdminPanelTripSelected avionVoyPanel;
	private static TravelModelStatemachine stateMachine;
	private AdminGUI gui;
	AdminFrameCompagnie compagnieFrame;
	protected Commande commande;
	Invocateur invocateur;
	AdminFrameAddButtonAssignerPrix panelAddButtonAssigner;
	AdminCompagniePanel compagniePanel;
	AdminCompagniePanel vehiculePanel;
	private Compagnie comp;
	private AdminFrameAssignerPrixCompagnie assignPanel;
	private String titleSelection;
	protected AdminCompagniePanel portPanel;
	protected AdminFrameAddButtonCreerSection panelAddButtonCreerSec;
	private AdminFramePort portFrame;
	private Port port;
	private AdminFrameSectionAvion sectionPanel;
	protected JListAerienne listeAerienne = new JListAerienne();
	protected JListTrain listeTrain = new JListTrain();
	protected JListCroisiere listeCroisiere = new JListCroisiere();
	protected int index;
	protected AdminFrameAssignerPrixCompagnie assignPricePanel;
	protected AdminFrameTransport vehiculeFrame;
	protected MoyenTransport transp;
 
	public static void main(String[] args) {
		Controller controleur = new Controller();
		controleur.createContents();
		controleur.setupStatemachine();
		controleur.run();
	}
	
	// Execution de la machine d'états
	private void run() {
		stateMachine.enter();
		stateMachine.runCycle();
		System.out.println(stateMachine.isActive());

	}
	
	//Mise en place du contenu de la GUI
	private void createContents() {
		 initialValues();
		 update();
		 gui = new AdminGUI();
		 gui.setVisible(true);
		 
	 	gui.getBtnVoyageAvion().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				stateMachine.getSCInterface().raiseVoyageAvionClicked();
				stateMachine.getSCInterface().raiseOperations();
				stateMachine.runCycle();
					
					System.out.println(" BtnVoyageAvion cliqué..... ");
						
			}
		});
		gui.getBtnVoyageBateau().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					 System.out.println(" BtnVoyagePaquebot cliqué ..... "); 
						stateMachine.getSCInterface().raiseVoyageBateauClicked();
						stateMachine.runCycle();
						
			}
		});	
		gui.getBtnVoyageTrain().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
						System.out.println(" BtnVoyageTrain cliqué ..... "); 

						stateMachine.getSCInterface().raiseVoyageTrainClicked();
						stateMachine.getSCInterface().raiseOperations();
						stateMachine.runCycle();
			}
		});
			
		
	}
	
	// Mise en place de la machine d'états
	void setupStatemachine() {
		stateMachine = new TravelModelStatemachine();
		stateMachine.getSCInterface().setSCInterfaceOperationCallback(new SCInterfaceOperationCallback() {
			@Override
//			public void voyageAvionPopuped() {
//				jlist = new JListAerienne(); 
//				fabrique = fabriqueAerienne;
//			    jlist = listAerienne;
//				title  = "Compagnie aérienne";
//				subTitle = "Avion";
//				stateMachine.getSCInterface().raiseOperationsAvion();
//				stateMachine.runCycle();
//				
//				//avionVoyPanelAdmin();
//
//			}
//
//			@Override
//			public void voyagePaquebotPopuped() {
//				fabrique = FabriqueCroisiere.getInstance();
//				jlist = new JListCroisiere(); 
//				fabrique = fabriqueCroisiere;
//			    jlist = listCroisiere;
//				title  = "Compagnie de croisière";
//				subTitle = "Paquebot";
//				stateMachine.getSCInterface().raiseOperationsPaquebot();
//				stateMachine.runCycle();
//				avionVoyPanel =  new AdminPanelTripSelected("Compagnie Croisière","Paquebot", "Port", "Itinéraire");
//				paquebotVoyPanelAdmin();
//			}
//
//			@Override
//			public void voyageTrainPopuped() {
//				fabrique = FabriqueTrain.getInstance();
//				jlist = new JListTrain(); 
//				fabrique = fabriqueTrain;
//			    jlist = listTrain;
//				title  = "Compagnie de train";
//				subTitle = "Train";
//				stateMachine.getSCInterface().raiseOperationsTrain();
//				stateMachine.runCycle();
//				avionVoyPanel =  new AdminPanelTripSelected("Compagnie de train","Train", "Gare", "Trajet");
//				trainVoyPanelAdmin();
//			}

//			@Override
//			public void popupSelection() {
//				
//				JOptionPane.showMessageDialog(panelAddButtonAssigner, titleSelection);				
//			}

//			@Override
//			public void create() {
//				
//				System.out.println("je suis dans le create");
//				commande = new CreerCompagnie(fabrique, compagnieFrame.getTxtCompagnieID().getText(), compagnieFrame.getTxtNomCompagnie().getText());
//				invocateur.setCommande(commande);
//				invocateur.pressExecuteButton(commande);
//				panelAddButtonAssigner.getBtnAnnuler().setEnabled(true);
//				stateMachine.getSCInterface().raiseCompagnyCreated();
//				stateMachine.runCycle();
//				compagnieFrame.dispose();
//
//			//	createCompagnie();
//				
//			}

//			@Override
//			public void modify() {
//				// TODO Auto-generated method stub
//				
//			}
//
//			@Override
//			public void delete() {
//				// TODO Auto-generated method stub
//				
//			}

//			@Override
//			public void assignPrice() {
//				// TODO Auto-generated method stub
//				
//			}

//			@Override
//			public void selectDeletion() {
//				// TODO Auto-generated method stub
//				
//			}

//			@Override
//			public void selectModification() {
//				// TODO Auto-generated method stub
//				
//			}
//
//			@Override
//			public void selectItem() {
//				// TODO Auto-generated method stub
//				
//			}

			public void createCompagnie() {
//						compagnieFrame.dispose();
			}

			@Override
			public void modifyCompagnie() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void deleteCompagnie() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void selectCompModification() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void selectCompDeletion() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void selectItemAssignPrice() {
				// TODO Auto-generated method stub
				
			}

			

			@Override
			public void createVehicule() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void modifyVehicule() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void deleteVehicule() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void selectVehicModification() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void selectVehicDeletion() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void selectItemCreateSection() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void createSection() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void createPort() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void modifyPort() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void deletePort() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void createVoyage() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void modifyVoyage() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void deleteVoyage() {
				// TODO Auto-generated method stub
				
			}	
			
			
			public void avionVoyPanelAdmin() {
				System.out.println("Je suis dans  avionVoyPanelAdmin..... "); 
				avionVoyPanel =  new AdminPanelTripSelected("Compagnie Aérienne","Avion", "Aéroport", "Vol");

				avionVoyPanel.getBtnCompagnie().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						if(stateMachine.getVoyageAvionTrigger()== true) {
							title = "Compagnie aérienne";
							subTitle = "Avion";
							jlist = listAerienne;
							fabrique = FabriqueAerienne.getInstance();
						}

						if(stateMachine.getVoyagePaquebotTrigger()==true) {
							title = "Compagnie de Croisière";
							subTitle = "Paquebot";
							jlist = listCroisiere;
							fabrique = FabriqueCroisiere.getInstance();
						}
						
						if(stateMachine.getVoyageTrainTrigger()==true) {
							title = "Compagnie de Train";
							subTitle = "Train";
							jlist = listTrain;
							fabrique = FabriqueTrain.getInstance();
						}
						
						compagniePanel = new AdminCompagniePanel(title, listAerienne, FabriqueAerienne.getInstance());		 		 		 

						panelAddButtonAssigner = new AdminFrameAddButtonAssignerPrix(compagniePanel);
						
						System.out.println("J'ai appuyer dans le listener du bouton compagnie aerienne..... ");
				//		stateMachine.getSCInterface().raiseOperations();
						stateMachine.runCycle();
						popupPanelCompagnie();
					}
				});
				
				avionVoyPanel.getBtnVehicule().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						if(stateMachine.getVoyageAvionTrigger()== true) {
							title = "Compagnie aérienne";
							subTitle = "Avion";
							jlist = listAerienne;
							fabrique = FabriqueAerienne.getInstance();
						}

						if(stateMachine.getVoyagePaquebotTrigger()==true) {
							title = "Compagnie de Croisière";
							subTitle = "Paquebot";
							jlist = listCroisiere;
							fabrique = FabriqueCroisiere.getInstance();
						}
						
						if(stateMachine.getVoyageTrainTrigger()==true) {
							title = "Compagnie de Train";
							subTitle = "Train";
							jlist = listTrain;
							fabrique = FabriqueTrain.getInstance();
						}	
						
						vehiculePanel= new AdminCompagniePanel(subTitle, listAerienne, FabriqueAerienne.getInstance());		 		 		 

						panelAddButtonCreerSec = new AdminFrameAddButtonCreerSection(vehiculePanel);
						
						System.out.println("J'ai appuyer dans le listener du bouton transport..... ");
				//		stateMachine.getSCInterface().raiseOperations();
						stateMachine.runCycle();
						popupPanelTransport();					}
				});
				avionVoyPanel.getBtnPort().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						System.out.println("J'ai appuyer dans le listener du bouton compagnie aerienne..... ");	
					}
				});
				avionVoyPanel.getBtnVoyage().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						System.out.println("J'ai appuyer dans le listener du bouton compagnie aerienne..... ");	
					}
				});
			}

			public void paquebotVoyPanelAdmin() {
				// TODO Auto-generated method stub
				
			}

			public void trainVoyPanelAdmin() {
				// TODO Auto-generated method stub
				
			}

			public void assignPrice() {
			
				// TODO Auto-generated method stub
				
			}
		});
		stateMachine.init();
}
	
	
	

	
	//Tests à faire aussi
	private void testStateMachine() {
		stateMachine.isActive();  
	}

	private void createPort() {
		System.out.println("je suis dans createCompagnie ..");

//		 fabrique = panelAddButtonAssigner.getFabriqueObjet();
//	     jlist = compagniePanel.getList();
//		 compagniePanel = new AdminCompagniePanel();
//		 fabrique = compagniePanel.getFabriqueObjet();
		commande = new CreerPort(fabrique, portFrame.getTxtPortID().getText(), portFrame.getTxtNomPort().getText(), portFrame.getTxtVille().getText());		
		invocateur.setCommande(commande);
		invocateur.pressExecuteButton(commande);
		panelAddButtonCreerSec.getBtnAnnuler().setEnabled(true);
	//	compagnieFrame.getBtnCreer().addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//			stateMachine.getSCInterface().raiseCompagnyCreated();
//			}
//		});
	}
	
	//Gestion des boutons du panel de compagnie avec les machines d'états
	public void popupPanelCompagnie() {
		panelAddButtonAssigner.getBtnAjouter().addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
				stateMachine.getSCInterface().raiseAddClickedCompagnie();
				stateMachine.runCycle();
				System.out.println(" je suis dans popupPanelCompagnie --------");
				compagnieFrame = new AdminFrameCompagnie();
				compagnieFrame.setTitle("Création de compagnie");
				compagnieFrame.getBtnCreer().setText("Créer");
				compagnieFrame.setVisible(true);
				System.out.println(" je suis avant getbtn creer  --------");

				compagnieFrame.getBtnCreer().addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						System.out.println(" je suis après getbtn creer  --------");
						// TODO Auto-generated method stub
						commande = new CreerCompagnie(fabrique, compagnieFrame.getTxtCompagnieID().getText(), compagnieFrame.getTxtNomCompagnie().getText());
						invocateur.setCommande(commande);
						invocateur.pressExecuteButton(commande);
						panelAddButtonAssigner.getBtnAnnuler().setEnabled(true);
						compagnieFrame.dispose();
						stateMachine.getSCInterface().raiseCompagnyCreated();
						stateMachine.runCycle();	
						compagnieFrame.dispose();
					}
					
				});
				
			}
			
		}); 
		
		panelAddButtonAssigner.getBtnModifier().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					stateMachine.setIndexList(jlist.getSelectedIndex());
					stateMachine.getSCInterface().raiseSelectModifyCompagnie();
					stateMachine.runCycle();
					if (stateMachine.getIndexList() == -1) {
						JOptionPane.showMessageDialog(compagnieFrame, "Veuillez sélectionner une "+title+" à modifier.");
						stateMachine.runCycle();
					}else {
						stateMachine.getSCInterface().raiseModifyClickedCompagnie();
						stateMachine.runCycle();
					
						System.out.println(" je suis dans popupPanelCompagnie --------");
						compagnieFrame = new AdminFrameCompagnie();
						compagnieFrame.setTitle("Modification de la compagnie");
						compagnieFrame.getBtnCreer().setText("Modifier");
						compagnieFrame.setVisible(true);
						index = jlist.getSelectedIndex();
						comp = (Compagnie)fabrique.getObjetParIndex(index, fabrique.getListeCompagnies());
						compagnieFrame.getTxtCompagnieID().setText(comp.getCompagnieID());
						compagnieFrame.getTxtNomCompagnie().setText(comp.getNomCompagnie());
						System.out.println(" je suis avant getbtn modifier  --------");

						compagnieFrame.getBtnCreer().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							System.out.println(" je suis après getbtn creer  --------");
							// TODO Auto-generated method stub
							commande = new ModifierCompagnie(fabrique, comp, compagnieFrame.getTxtCompagnieID().getText(), compagnieFrame.getTxtNomCompagnie().getText());							invocateur.setCommande(commande);
							invocateur.pressExecuteButton(commande);
							panelAddButtonAssigner.getBtnAnnuler().setEnabled(true);
							compagnieFrame.dispose();
							stateMachine.getSCInterface().raiseCompagnieModified();
							stateMachine.runCycle();	
							compagnieFrame.dispose();
						}
						
					});
					}
					
				}
				
			}); 
		
		panelAddButtonAssigner.getBtnSupprimer().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					stateMachine.setIndexList(jlist.getSelectedIndex());
					stateMachine.getSCInterface().raiseSelectDeleteCompagnie();
					stateMachine.runCycle();
					if (stateMachine.getIndexList() == -1) {
						JOptionPane.showMessageDialog(compagnieFrame, "Veuillez sélectionner une "+title+" à supprimer.");
						stateMachine.runCycle();
					}else {
						stateMachine.getSCInterface().raiseDeleteClickedCompagnie();
						stateMachine.runCycle();
					
						System.out.println(" je suis dans popupPanelCompagnie --------");
						comp = (Compagnie)fabrique.getObjetParIndex(stateMachine.getIndexList(), fabrique.getListeCompagnies());
						compagnieFrame.getTxtCompagnieID().setText(comp.getCompagnieID());
						compagnieFrame.getTxtNomCompagnie().setText(comp.getNomCompagnie());
						System.out.println(" je suis avant getbtn suuprimer  --------");

						compagnieFrame.getBtnCreer().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							System.out.println(" je suis après getbtn supprimer  --------");
							// TODO Auto-generated method stub
							commande = new ModifierCompagnie(fabrique, comp, compagnieFrame.getTxtCompagnieID().getText(), compagnieFrame.getTxtNomCompagnie().getText());							invocateur.setCommande(commande);
							invocateur.pressExecuteButton(commande);
							panelAddButtonAssigner.getBtnAnnuler().setEnabled(true);
							compagnieFrame.dispose();
							stateMachine.getSCInterface().raiseCompagnieDeleted();
							stateMachine.runCycle();	
							compagnieFrame.dispose();
						}
						
					});
				 }
					
				}
				
			});
		
		    panelAddButtonAssigner.getBtnAssigner().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					stateMachine.setIndexList(jlist.getSelectedIndex());
					stateMachine.getSCInterface().raiseSelectPriceAssign();
					stateMachine.runCycle();
					if (stateMachine.getIndexList() == -1) {
						JOptionPane.showMessageDialog(compagnieFrame, "Veuillez sélectionner une "+title+ " pour assigner un prix.");
						stateMachine.runCycle();
					}else {
						stateMachine.getSCInterface().raiseAssignPriceClicked();
						stateMachine.runCycle();
					
						System.out.println(" je suis dans popupPanelCompagnie --------");
						assignPricePanel = new AdminFrameAssignerPrixCompagnie();
						assignPricePanel.setVisible(true);
						index = jlist.getSelectedIndex();
						comp = (Compagnie)fabrique.getObjetParIndex(index, fabrique.getListeCompagnies());
						assignPricePanel.getLblCompagnieID().setText("CompagnieID: " + comp.getCompagnieID());
						assignPricePanel.getLblNomCompagnie().setText("Nom de la compagnie: " + comp.getNomCompagnie());
						
						
						
						System.out.println(" je suis avant getbtn assign ok  --------");
						assignPricePanel.getBtn().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							System.out.println(" je suis après getbtn assign ok  --------");
							// TODO Auto-generated method stub
							commande = new AssignerPrix(fabrique, comp, assignPricePanel.getPleinTarif());
							invocateur.pressExecuteButton(commande);
							panelAddButtonAssigner.getBtnAnnuler().setEnabled(true);
							stateMachine.getSCInterface().raisePriceAssigned();
							stateMachine.runCycle();	
							assignPricePanel.dispose();
						}
						
					});
				 }
					
				}
				
			});
		    
		    panelAddButtonAssigner.getBtnAnnuler().addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
						stateMachine.setIndexList(jlist.getSelectedIndex());
						stateMachine.getSCInterface().raiseSelectPriceAssign();
						stateMachine.runCycle();
						if (stateMachine.getIndexList() == -1) {
							JOptionPane.showMessageDialog(compagnieFrame, "Veuillez sélectionner une "+title+" pour assigner un prix.");
							stateMachine.runCycle();
						}else {
							if (invocateur.getCommande() == null) {
								JOptionPane.showMessageDialog(null, "Aucune action à été effectuee précedement.");
							} else {
								invocateur.pressUnexecuteButton();
								panelAddButtonAssigner.getBtnAnnuler().setEnabled(false);
								stateMachine.getSCInterface().raiseCancelOperationCompagnie();
								stateMachine.runCycle();
								
							}
						}
				}
				
			});
		
	}
	

	//Gestion des boutons du panel des vehicules avec les machines d'états
		public void popupPanelTransport() {
			panelAddButtonCreerSec.getBtnAjouter().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					stateMachine.getSCInterface().raiseAddClickedVehicule();
					stateMachine.runCycle();
					System.out.println(" je suis dans popupPanelCompagnie --------");
					vehiculeFrame = new AdminFrameTransport();
					vehiculeFrame.setTitle("Création de "+subTitle);
					vehiculeFrame.getBtn().setText("Créer");
					vehiculeFrame.setVisible(true);
					System.out.println(" je suis avant getbtn creer  --------");
					for (Compagnie c: fabrique.getListeCompagnies().values()) {
						vehiculeFrame.getComboBoxCompagnie().addItem(c.getNomCompagnie());
					}
					vehiculeFrame.getBtn().addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							System.out.println(" je suis après getbtn creer  --------");
							// TODO Auto-generated method stub
							comp = (Compagnie)fabrique.getObjetParIndex(vehiculeFrame.getComboBoxCompagnie().getSelectedIndex(), fabrique.getListeCompagnies());
							commande = new CreerMoyenTransport(fabrique, vehiculeFrame.getTxtTransportID().getText(), comp);
							invocateur.setCommande(commande);
							invocateur.pressExecuteButton(commande);
							panelAddButtonCreerSec.getBtnAnnuler().setEnabled(true);
							compagnieFrame.dispose();
							stateMachine.getSCInterface().raiseVehiculeCreated();
							stateMachine.runCycle();	
							vehiculeFrame.dispose();
						}
						
					});
					
				}
				
			}); 
			
			panelAddButtonCreerSec.getBtnModifier().addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
						stateMachine.setIndexList(jlist.getSelectedIndex());
						stateMachine.getSCInterface().raiseSelectModifyVehicule();
						stateMachine.runCycle();
						if (stateMachine.getIndexList() == -1) {
							JOptionPane.showMessageDialog(vehiculeFrame, "Veuillez sélectionner un "+subTitle +" à modifier.");
							stateMachine.runCycle();
						}else {
							stateMachine.getSCInterface().raiseModifyClickedCompagnie();
							stateMachine.runCycle();
						
							System.out.println(" je suis dans popupPanelCompagnie --------");
							vehiculeFrame = new AdminFrameTransport();
							vehiculeFrame.setTitle("Modification du véhicule");
							vehiculeFrame.getBtn().setText("Modifier");
							vehiculeFrame.setVisible(true);
							index = jlist.getSelectedIndex();
							for (Compagnie comp: fabrique.getListeCompagnies().values()) {
								vehiculeFrame.getComboBoxCompagnie().addItem(comp.getNomCompagnie());
							}
							
							transp = (MoyenTransport)fabrique.getObjetParIndex(index, fabrique.getListeTransports());
							vehiculeFrame.getTxtTransportID().setText(transp.getTransportID());
							vehiculeFrame.getComboBoxCompagnie().setSelectedItem(transp.getCompagnie().getNomCompagnie());
							
			
							System.out.println(" je suis avant getbtn modifier  --------");

							vehiculeFrame.getBtn().addActionListener(new ActionListener() {

							@Override
							public void actionPerformed(ActionEvent e) {
								System.out.println(" je suis après getbtn creer  --------");
								vehiculeFrame.setVisible(true);
								Compagnie c = (Compagnie)fabrique.getObjetParIndex(vehiculeFrame.getComboBoxCompagnie().getSelectedIndex(), fabrique.getListeCompagnies());
								commande = new ModifierMoyenTransport(fabrique, transp, vehiculeFrame.getTxtTransportID().getText(), c);
								invocateur.setCommande(commande);
								invocateur.pressExecuteButton(commande);
								panelAddButtonCreerSec.getBtnAnnuler().setEnabled(true);
								stateMachine.getSCInterface().raiseVehiculeModified();
								stateMachine.runCycle();	
								vehiculeFrame.dispose();
							}
							
						});
						}
						
					}
					
				}); 
			
			panelAddButtonCreerSec.getBtnSupprimer().addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
						stateMachine.setIndexList(jlist.getSelectedIndex());
						stateMachine.getSCInterface().raiseSelectDeleteVehicule();
						stateMachine.runCycle();
						if (stateMachine.getIndexList() == -1) {
							JOptionPane.showMessageDialog(vehiculeFrame, "Veuillez sélectionner un " + subTitle +" à supprimer.");
							stateMachine.runCycle();
						}else {
							stateMachine.getSCInterface().raiseDeleteClickedVehicule();
							stateMachine.runCycle();
						
							System.out.println(" je suis dans popupPanelVehicule --------");
						
							index = stateMachine.getIndexList();
							transp = (MoyenTransport)fabrique.getObjetParIndex(index, fabrique.getListeTransports());
							int answer = JOptionPane.showConfirmDialog(panelAddButtonCreerSec, "Etes-vous sur de vouloir supprimer le vehicule " + transp.getTransportID() + "de la compagnie " + transp.getCompagnie().getNomCompagnie() + " ?");
							
							if (answer == JOptionPane.YES_OPTION) {
								commande = new SupprimerMoyenTransport(fabrique, transp.getTransportID());
								invocateur.setCommande(commande);
								invocateur.pressExecuteButton(commande);
								panelAddButtonCreerSec.getBtnAnnuler().setEnabled(true);
								stateMachine.getSCInterface().raiseVehiculeDeleted();
								stateMachine.runCycle();
							}
							
					 }
						
					}
					
				});
			
			panelAddButtonCreerSec.getBtnCreerSection().addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
						stateMachine.setIndexList(jlist.getSelectedIndex());
				//		stateMachine.getSCInterface().raiseSelect();
						stateMachine.runCycle();
						if (stateMachine.getIndexList() == -1) {
							JOptionPane.showMessageDialog(compagnieFrame, "Veuillez sélectionner une compagnie pour assigner un prix.");
							stateMachine.runCycle();
						}else {
							stateMachine.getSCInterface().raiseAssignPriceClicked();
							stateMachine.runCycle();
						
							System.out.println(" je suis dans popupPanelCompagnie --------");
							assignPricePanel = new AdminFrameAssignerPrixCompagnie();
							assignPricePanel.setVisible(true);
							index = jlist.getSelectedIndex();
							comp = (Compagnie)fabrique.getObjetParIndex(index, fabrique.getListeCompagnies());
							assignPricePanel.getLblCompagnieID().setText("CompagnieID: " + comp.getCompagnieID());
							assignPricePanel.getLblNomCompagnie().setText("Nom de la compagnie: " + comp.getNomCompagnie());
							
							
							
							System.out.println(" je suis avant getbtn assign ok  --------");
							assignPricePanel.getBtn().addActionListener(new ActionListener() {

							@Override
							public void actionPerformed(ActionEvent e) {
								System.out.println(" je suis après getbtn assign ok  --------");
								// TODO Auto-generated method stub
								commande = new AssignerPrix(fabrique, comp, assignPricePanel.getPleinTarif());
								invocateur.pressExecuteButton(commande);
								panelAddButtonAssigner.getBtnAnnuler().setEnabled(true);
								stateMachine.getSCInterface().raisePriceAssigned();
								stateMachine.runCycle();	
								assignPricePanel.dispose();
							}
							
						});
					 }
						
					}
					
				});
			    
			    panelAddButtonAssigner.getBtnAnnuler().addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
							stateMachine.setIndexList(jlist.getSelectedIndex());
							stateMachine.getSCInterface().raiseSelectPriceAssign();
							stateMachine.runCycle();
							if (stateMachine.getIndexList() == -1) {
								JOptionPane.showMessageDialog(compagnieFrame, "Veuillez sélectionner une compagnie pour assigner un prix.");
								stateMachine.runCycle();
							}else {
								if (invocateur.getCommande() == null) {
									JOptionPane.showMessageDialog(null, "Aucune action à été effectuee précedement.");
								} else {
									invocateur.pressUnexecuteButton();
									panelAddButtonAssigner.getBtnAnnuler().setEnabled(false);
									stateMachine.getSCInterface().raiseCancelOperationCompagnie();
									stateMachine.runCycle();
									
								}
							}
					}
					
				});
			
		}
	
	
	private void assignationPrix() {
		System.out.println("J'ai appuyer sur le bouton assigner.... "); 

		assignPanel = new AdminFrameAssignerPrixCompagnie();
		assignPanel.setVisible(true);
		
		comp = (Compagnie)fabrique.getObjetParIndex(stateMachine.getIndexList(), fabrique.getListeCompagnies());
		assignPanel.getLblCompagnieID().setText("CompagnieID: " + comp.getCompagnieID());
		assignPanel.getLblNomCompagnie().setText("Nom de la compagnie: " + comp.getNomCompagnie());
		assignPanel.getBtn().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				stateMachine.getSCInterface().raiseAssignPriceClicked();
				stateMachine.runCycle();
				prixAssigner();
			}
			
		});
	}
	
	protected void prixAssigner() {
		commande = new AssignerPrix(fabrique, comp, assignPanel.getPleinTarif());
		invocateur.setCommande(commande);
		invocateur.pressExecuteButton(commande);
		panelAddButtonAssigner.getBtnAjouter().setEnabled(true);
		
		assignPanel.dispose();		
	}

	
	private void undoOperationCompagnie() {
		stateMachine.runCycle();
		invocateur.pressUnexecuteButton();
		panelAddButtonAssigner.getBtnAnnuler().setEnabled(false);
	}

	private void undoOperationPort() {
		stateMachine.runCycle();
		invocateur.pressUnexecuteButton();
		panelAddButtonCreerSec.getBtnAnnuler().setEnabled(false);
	}
	
	private void portSupprime() {
		System.out.println("J'ai appuyer sur le bouton compagniePanel.... "); 
				
		port = (Port)fabrique.getObjetParIndex(stateMachine.getIndexList(), fabrique.getListePorts());
		int answer = JOptionPane.showConfirmDialog(portFrame, "Etes-vous sur de vouloir supprimer le port " + port.getNomPort() + "(" + port.getPortID() +") ?");
		if (answer == JOptionPane.YES_OPTION) {
			stateMachine.getSCInterface().raisePortDeleted();
			stateMachine.runCycle();
			deletePort();

		}	
	}
	
	
	private void compagnieSupprimee() {
		System.out.println("J'ai appuyer sur le bouton compagniePanel.... "); 
				
				comp = (Compagnie)fabrique.getObjetParIndex(stateMachine.getIndexList(), fabrique.getListeCompagnies());
				int answer = JOptionPane.showConfirmDialog(panelAddButtonAssigner, "Etes-vous sur de vouloir supprimer la compagnie " + comp.getNomCompagnie() + "(" + comp.getCompagnieID() +") ?");
				if (answer == JOptionPane.YES_OPTION) {
					stateMachine.getSCInterface().raiseCompagnieDeleted();
					stateMachine.runCycle();
					deleteCompanie();

				}	
			}

	private void deleteCompanie() {
		commande = new SupprimerCompagnie(fabrique, comp.getCompagnieID());
		invocateur.setCommande(commande);
		invocateur.pressExecuteButton(commande);
		panelAddButtonAssigner.getBtnAnnuler().setEnabled(true);		
	}
	
	private void deletePort() {
		commande = new SupprimerPort(fabrique, port.getPortID());
		invocateur.setCommande(commande);
		invocateur.pressExecuteButton(commande);
		panelAddButtonCreerSec.getBtnAnnuler().setEnabled(true);		
	}
	
	private void portSelectione() {
		
		portFrame = new AdminFramePort();
		portFrame.setVisible(true);
		portFrame.setTitle("Modification de port");
		portFrame.getBtn().setText("Modifier");
		
		port = (Port)fabrique.getObjetParIndex(stateMachine.getIndexList(), fabrique.getListePorts());
		
		portFrame.getTxtPortID().setText(port.getPortID());
		portFrame.getTxtNomPort().setText(port.getNomPort());
		portFrame.getTxtVille().setText(port.getVille());
		
		portFrame.getBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				stateMachine.getSCInterface().raisePortModified();
				stateMachine.runCycle();	
				modifyPort();
			}
			 
		 });
	}


		
	protected void modifyPort() {
		commande = new ModifierPort(fabrique, port, portFrame.getTxtPortID().getText(), portFrame.getTxtNomPort().getText(), portFrame.getTxtVille().getText());		invocateur.setCommande(commande);
		invocateur.pressExecuteButton(commande);
		panelAddButtonCreerSec.getBtnAnnuler().setEnabled(true);
		
		portFrame.dispose();		
	}
	
	
	protected void modifyCompagnie() {
		commande = new ModifierCompagnie(fabrique, comp, compagnieFrame.getTxtCompagnieID().getText(), compagnieFrame.getTxtNomCompagnie().getText());
		invocateur.setCommande(commande);
		invocateur.pressExecuteButton(commande);
		panelAddButtonAssigner.getBtnAnnuler().setEnabled(true);
		
		compagnieFrame.dispose();		
	}

	private void portPanelDisplay() {
		
		System.out.println("J'ai appuyer dans portPanelDisplay.... "); 
		
		portFrame = new AdminFramePort();
		portFrame.setVisible(true);
		portFrame.getBtn().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				stateMachine.getSCInterface().raisePortCreated();
				stateMachine.runCycle();	
				createPort();
			}
			 
		 });
	
	}
	

	
	
public void paquebotVoyPanelAdmin2(){
	 paquebotVoyPanel =  new AdminPanelTripSelected("Compagnie de Croisiere","Paquebot", "Port", "Croisiere");
	 paquebotVoyPanel.setVisible(true);
//	 fabrique = FabriqueAerienne.getInstance();
	 jlist = listCroisiere;
	 title  = "Compagnie de croisière";
	 subTitle = "Paquebot";
	 paquebotVoyPanel.getBtnCompagnie().addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {	
			 	System.out.println("Coucou la compagnie..... "); 
				stateMachine.getSCInterface().raiseOperations();
				stateMachine.runCycle();
		}
	 }); 
	 paquebotVoyPanel.getBtnPort().addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {	
				System.out.println("Coucou la port..... "); 
				stateMachine.runCycle();
		}
	 }); 
	 paquebotVoyPanel.getBtnVehicule().addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			 	System.out.println("Coucou la vehicule..... "); 
				stateMachine.runCycle();
		}
	}); 
}
	public void trainVoyPanelAdmin2(){
		 trainVoyPanel =  new AdminPanelTripSelected("Compagnie de Train","Train", "Gare", "Itinéraire");
		 trainVoyPanel.setVisible(true);
		 fabrique = fabriqueAerienne;
	     jlist = listTrain;
		 title  = "Compagnie de train";
		 subTitle = "Train";
		 trainVoyPanel.getBtnCompagnie().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					 System.out.println("Coucou la train..... "); 
					 stateMachine.getSCInterface().raiseOperations();
					 stateMachine.runCycle();	
		//			 displayCompagnieFrame();
					 
			}
			 
		 }); 
		 trainVoyPanel.getBtnPort().addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					     System.out.println("Coucou la port ..... "); 
						 stateMachine.getSCInterface().raiseAddClickedPort();
						 stateMachine.runCycle();						
				}
					 
			 });
			 trainVoyPanel.getBtnVehicule().addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						     System.out.println("Coucou la vehicule..... "); 
							 stateMachine.getSCInterface().raiseAddClickedVehicule();
							 stateMachine.runCycle();						
					}
						 
				 });
	}
	
	@Override
	public void update() {
		FabriqueEntiteVoyage fabriques[] = {fabriqueAerienne, fabriqueTrain, fabriqueCroisiere};

		JListGeneral jlistsC[] = {listAerienne, listTrain, listCroisiere};
		for (int i=0; i<3; i++) {
			jlistsC[i].getDefaultListe().clear();
			for (Compagnie c: fabriques[i].getListeCompagnies().values()) {
				c.accepte(jlistsC[i]);
				jlistsC[i].getDefaultListe().addElement(jlistsC[i].getTexte());
				jlistsC[i].getDefaultListe().addElement(jlistsC[i].getTexte());
				jlistsC[i].setModel(jlistsC[i].getDefaultListe());
				jlistsC[i].repaint();
			}
		}	 

	
		JListGeneral jlistsT[] = {listAerienne, listTrain, listCroisiere};
		
		for (int i=0; i<3; i++) {
			jlistsT[i].getDefaultListe().clear();
			for (MoyenTransport t: fabriques[i].getListeTransports().values()) {
				t.accepte(jlistsT[i]);
				jlistsT[i].getDefaultListe().addElement(jlistsT[i].getTexte());
				jlistsT[i].setModel(jlistsT[i].getDefaultListe());
			}
		}
	
	

		JListGeneral jlistsP[] = {listAerienne, listTrain, listCroisiere};
		for (int i=0; i<3; i++) {
			jlistsP[i].getDefaultListe().clear();
			for (Port p: fabriques[i].getListePorts().values()) {
				p.accepte(jlistsP[i]);
				jlistsP[i].getDefaultListe().addElement(jlistsP[i].getTexte());
				jlistsP[i].setModel(jlistsP[i].getDefaultListe());
			}
		}
	

		JListGeneral jlistsV[] = {listAerienne, listTrain, listCroisiere};
		for (int i=0; i<3; i++) {
			jlistsV[i].getDefaultListe().clear();
			for (Voyage v: fabriques[i].getListeVoyages().values()) {
				v.accepte(jlistsV[i]);
				jlistsV[i].getDefaultListe().addElement(jlistsV[i].getTexte());
				jlistsV[i].setModel(jlistsV[i].getDefaultListe());
			}
		}		
	}
	
	
	protected void initialValues() {
		invocateur  = Invocateur.getInstance();
		fabriqueAerienne = FabriqueAerienne.getInstance();
		fabriqueTrain = FabriqueTrain.getInstance();
		fabriqueCroisiere = FabriqueCroisiere.getInstance();
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd:HH.mm");
		// 6 Dates
		Date d1=null, d2=null, d3=null, d4=null, d5=null, d6=null;
		try {
			d1 = df.parse("2016.12.24:23.30");
			d2 = df.parse("2017.01.05:11.30");
			d3 = df.parse("2017.02.28:10.00");
			d4 = df.parse("2017.03.05:20.00");
			d5 = df.parse("2017.03.10:14.00");
			d6 = df.parse("2017.03.15:08.00");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// 6 compagnies
		Compagnie c1 = fabriqueAerienne.creerCompagnie("AIR01", "Nom compagnie aerienne");
		Compagnie c2 = fabriqueTrain.creerCompagnie("TRAIN01", "Nom compagnie train");
		Compagnie c3 = fabriqueCroisiere.creerCompagnie("CROIS01", "Nom compagnie croisiere");
		Compagnie c4 = fabriqueAerienne.creerCompagnie("AIRNDSlnf01", "Nom compagnie aerienne1");
		Compagnie c5 = fabriqueTrain.creerCompagnie("TRAIjndsNN01", "Nom compagnie train1");
		Compagnie c6 = fabriqueCroisiere.creerCompagnie("CRNsèlkndOIS01", "Nom compagnie croisiere1");
		
		// Assignation de prix aux 6 compagnies
		fabriqueAerienne.assignerPrix(c1, 342);
		fabriqueTrain.assignerPrix(c2, 151);
		fabriqueCroisiere.assignerPrix(c3, 1352);
		fabriqueAerienne.assignerPrix(c4, 342);
		fabriqueTrain.assignerPrix(c5, 151);
		fabriqueCroisiere.assignerPrix(c6, 1352);
		
		// 6 vehicules
		MoyenTransport t1 = fabriqueAerienne.creerTransport("AVIONID01", c1);
		MoyenTransport t2 = fabriqueTrain.creerTransport("TRAINID01", c2);
		MoyenTransport t3 = fabriqueCroisiere.creerTransport("PAQUID01", c3);
		MoyenTransport t4 = fabriqueAerienne.creerTransport("AVIOtnèdlksnfèyD01", c4);
		MoyenTransport t5 = fabriqueTrain.creerTransport("TRAINjndsJFNhdoh1", c5);
		MoyenTransport t6 = fabriqueCroisiere.creerTransport("PAQkln;fNVUID01", c6);
		
		// Creation de section pour les 6 types de vehicules
		((Avion)t1).creerSection('F', new Etroit(), 15);
		((Train)t2).creerSection(12, 42);
		((Paquebot)t3).creerSection(2, 5, 10, 3, 20);
		((Avion)t4).creerSection('F', new Etroit(), 15);
		((Train)t5).creerSection(12, 42);
		((Paquebot)t6).creerSection(2, 5, 10, 3, 20);
		
		// 5 Ports
		Port p0 = fabriqueAerienne.creerPort("AEROID00", "Aeroport 0", "Montreal");
		Port p1 = fabriqueAerienne.creerPort("AEROID01", "Aeroport 1", "Tokyo");
		Port p2 = fabriqueTrain.creerPort("GAREIndsèLNÈD01", "Gare 1", "Seoul");
		Port p3 = fabriqueTrain.creerPort("GARELNsdèlnID02", "Gare 2", "Tokyo");
		Port p4 = fabriqueCroisiere.creerPort("POlnslNRTID01", "Port Croisiere 1", "New York");
		
		fabriqueAerienne.creerVoyage(c1, t1, "VOLID01", d1, d2, p0, p1);
		fabriqueTrain.creerVoyage(c2, t2, "TRAJID01", d3, d4, p2, p3);
		fabriqueCroisiere.creerVoyage(c3, t3, "ITINID01", d5, d6, p4, p4);		
		fabriqueAerienne.creerVoyage(c4, t4, "VOLIJNFÉ,DNÉNS;JND01", d1, d2, p0, p1);
		fabriqueTrain.creerVoyage(c5, t5, "TRAJ;JLKSNLDKNNNFID01", d3, d4, p2, p3);
		fabriqueCroisiere.creerVoyage(c6, t6, "ITILDS;NN;JNFJNID01", d5, d6, p4, p4);
		
		
	}

	

	

	
}
