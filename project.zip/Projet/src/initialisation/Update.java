package initialisation;

import Entities.Compagnie;
import Entities.MoyenTransport;
import Entities.Port;
import Entities.Voyage;
import fabrique.FabriqueAerienne;
import fabrique.FabriqueCroisiere;
import fabrique.FabriqueEntiteVoyage;
import fabrique.FabriqueTrain;
import lists.JListCroisiere;
import lists.JListAerienne;
import lists.JListGeneral;
import lists.JListTrain;

public class Update {
	 
	private FabriqueEntiteVoyage fabriqueAerienne;
	private FabriqueEntiteVoyage fabriqueTrain;
	private FabriqueEntiteVoyage fabriqueCroisiere;
	private JListAerienne listeObjetsAerienne;
	private JListTrain listeObjetsTrain;
	private JListCroisiere listeObjetsCroisiere;

	
	public Update() {
		 System.out.println("Je suis dans update() du adminframe!!");
		 fabriqueAerienne = FabriqueAerienne.getInstance();
		 fabriqueTrain = FabriqueTrain.getInstance();
	     fabriqueCroisiere = FabriqueCroisiere.getInstance();
		 listeObjetsAerienne = new JListAerienne();
         listeObjetsTrain = new JListTrain();
 		 listeObjetsCroisiere = new JListCroisiere();
 		 

		FabriqueEntiteVoyage fabriques[] = {fabriqueAerienne, fabriqueTrain, fabriqueCroisiere};

		System.out.println("J'ai commencé avec compagnie!!");

		JListGeneral jlistsC[] = {listeObjetsAerienne, listeObjetsTrain, listeObjetsCroisiere};
		for (int i=0; i<3; i++) {
			jlistsC[i].getDefaultListe().clear();
			for (Compagnie c: fabriques[i].getListeCompagnies().values()) {
				c.accepte(jlistsC[i]);
				jlistsC[i].getDefaultListe().addElement(jlistsC[i].getTexte());
				jlistsC[i].setModel(jlistsC[i].getDefaultListe());
			}
		}
		System.out.println("J'ai fini avec compagnie!!");

		System.out.println("J'ai commencé avec transport !!");

		
		JListGeneral jlistsT[] = {listeObjetsAerienne, listeObjetsTrain, listeObjetsCroisiere};
		for (int i=0; i<3; i++) {
			jlistsT[i].getDefaultListe().clear();
			for (MoyenTransport t: fabriques[i].getListeTransports().values()) {
				t.accepte(jlistsT[i]);
				jlistsT[i].getDefaultListe().addElement(jlistsT[i].getTexte());
				jlistsT[i].setModel(jlistsT[i].getDefaultListe());
			}
		}
		System.out.println("J'ai fini avec transport !!");

		
		System.out.println("J'ai commencé avec Port!!");
		JListGeneral jlistsP[] = {listeObjetsAerienne, listeObjetsTrain, listeObjetsCroisiere};
		for (int i=0; i<3; i++) {
			jlistsP[i].getDefaultListe().clear();
			for (Port p: fabriques[i].getListePorts().values()) {
				p.accepte(jlistsP[i]);
				jlistsP[i].getDefaultListe().addElement(jlistsP[i].getTexte());
				jlistsP[i].setModel(jlistsP[i].getDefaultListe());
			}
		}
		System.out.println("J'ai fini avec port!!");

		
		System.out.println("J'ai commencé avec voyage!!");
		JListGeneral jlistsV[] = {listeObjetsAerienne, listeObjetsTrain, listeObjetsCroisiere};
		for (int i=0; i<3; i++) {
			jlistsV[i].getDefaultListe().clear();
			for (Voyage v: fabriques[i].getListeVoyages().values()) {
				v.accepte(jlistsV[i]);
				jlistsV[i].getDefaultListe().addElement(jlistsV[i].getTexte());
				jlistsV[i].setModel(jlistsV[i].getDefaultListe());
			}
		}
		System.out.println("J'ai fini avec port!!");

		
	}
	public FabriqueEntiteVoyage getFabriqueAerienne() {
		return fabriqueAerienne;
	}
	public void setFabriqueAerienne(FabriqueEntiteVoyage fabriqueAerienne) {
		this.fabriqueAerienne = fabriqueAerienne;
	}
	public FabriqueEntiteVoyage getFabriqueTrain() {
		return fabriqueTrain;
	}
	public void setFabriqueTrain(FabriqueEntiteVoyage fabriqueTrain) {
		this.fabriqueTrain = fabriqueTrain;
	}
	public FabriqueEntiteVoyage getFabriqueCroisiere() {
		return fabriqueCroisiere;
	}
	public void setFabriqueCroisiere(FabriqueEntiteVoyage fabriqueCroisiere) {
		this.fabriqueCroisiere = fabriqueCroisiere;
	}
	public JListAerienne getListeObjetsAerienne() {
		return listeObjetsAerienne;
	}
	public void setListeObjetsAerienne(JListAerienne listeObjetsAerienne) {
		this.listeObjetsAerienne = listeObjetsAerienne;
	}
	public JListTrain getListeObjetsTrain() {
		return listeObjetsTrain;
	}
	public void setListeObjetsTrain(JListTrain listeObjetsTrain) {
		this.listeObjetsTrain = listeObjetsTrain;
	}
	public JListCroisiere getListeObjetsCroisiere() {
		return listeObjetsCroisiere;
	}
	public void setListeObjetsCroisiere(JListCroisiere listeObjetsCroisiere) {
		this.listeObjetsCroisiere = listeObjetsCroisiere;
	}
	public JListGeneral getlisteObjetsAerienne() {
		return this.listeObjetsAerienne;
	}
	
	public JListGeneral getlisteObjetsTrain() {
		return this.listeObjetsTrain;
	}
	
	public JListGeneral getlisteObjetsCroisiere() {
		return this.listeObjetsCroisiere;
	}
//	public JListGeneral getlisteObjets() {
//	switch(tabbedPane.getSelectedIndex()) {
//	case 0:
//		return this.listeObjetsAerienne;
//	case 1:
//		return this.listeObjetsTrain;
//	case 2:
//		return this.listeObjetsCroisiere;
//	default: throw new NullPointerException();
//	}
//}
//
//public FabriqueEntiteVoyage getFabrique() {
//	switch(tabbedPane.getSelectedIndex()) {
//	case 0:
//		return (FabriqueEntiteVoyage)this.fabriqueAerienne;
//	case 1:
//		return (FabriqueEntiteVoyage)this.fabriqueTrain;
//	case 2:
//		return (FabriqueEntiteVoyage)this.fabriqueCroisiere;
//	default: throw new NullPointerException();
//	}
//}
	
	
}
