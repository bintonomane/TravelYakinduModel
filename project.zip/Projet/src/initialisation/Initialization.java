package initialisation;

import java.awt.Component;

import javax.swing.JFrame;

import fabrique.FabriqueAerienne;
import fabrique.FabriqueEntiteVoyage;
import gui.AdminFrameCompagnie;
import invocator.Invocateur;
import lists.JListAerienne;
import lists.JListGeneral;
import methode.CreerCompagnie;
import observer.Observateur;


@SuppressWarnings("serial")
public class Initialization extends JFrame implements Observateur{
	
	private JListGeneral jlist;

	private FabriqueEntiteVoyage fabrique;
	private JListAerienne listeObjetsAerienne;

	private FabriqueAerienne fabriqueVoyageAerien;
//	private JListAerienne jlist;

	

	private CreerCompagnie commande;
	private AdminFrameCompagnie frame = new AdminFrameCompagnie();

	private Invocateur invocateur;

	private FabriqueAerienne fabriqueAerienne;
	
	
	
	private void initiator() {
		invocateur = Invocateur.getInstance();
		invocateur.attacher(this);
	}
	
	@Override
	public void update() {
		initiator();
		new Update();	
	}
	

	

	
}
